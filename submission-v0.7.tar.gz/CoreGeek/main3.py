#!/usr/bin/env python3
"""SDK-compatible import/callback/app entry and standard-library CLI service."""
import sys


def _emit(message):
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.write(message + "\n")
            stream.flush()
        except Exception:
            pass


if __name__ == "__main__":
    _emit("boot stage=python_enter python=" + ".".join(str(n) for n in sys.version_info[:3]) + " entry=main3")
else:
    _emit("boot stage=module_import entry=main3")

import main as _entry


def callback(raw):
    return _entry.callback(raw)


def __getattr__(name):
    if name == "app":
        return _entry.app
    raise AttributeError("module 'main3' has no attribute " + repr(name))


def main():
    return _entry.main()


if __name__ == "__main__":
    sys.exit(main())
