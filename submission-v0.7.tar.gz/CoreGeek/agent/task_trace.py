"""Task-only diagnostic text with hard per-record and per-task character budgets."""
import hashlib
import json
import logging


LOG = logging.getLogger("futurewar")


class TaskTrace:
    MAX_RECORD = 8000
    MAX_BODY = 64000

    def __init__(self):
        self.used = 0

    def emit(self, token, round_no, event, fields=None, **bodies):
        try:
            data = dict(fields or {})
            data.update(task_token=token, round=round_no, event=event)
            remaining = max(0, self.MAX_BODY - self.used)
            # The sum of body text budgets also leaves room for JSON escaping/metadata.
            cap = min(5000, remaining)
            for name, value in bodies.items():
                value = str(value)
                count = min(len(value), cap)
                excerpt = value if count == len(value) else value[:count * 3 // 4] + value[-count // 4:] if count else ""
                data[name] = excerpt
                data[name + "_chars"] = len(value)
                data[name + "_signature"] = hashlib.sha256(value.encode("utf-8")).hexdigest()[:20]
                data[name + "_truncated"] = count < len(value)
                cap -= count
            data["body_budget_exhausted"] = self.used >= self.MAX_BODY
            wire = json.dumps(data, ensure_ascii=False, separators=(",", ":"))
            # Unusual control characters can make JSON much longer than its body.
            while len("task_trace " + wire) > self.MAX_RECORD:
                key = max(bodies, key=lambda k: len(data[k]), default=None)
                if key is None or not data[key]:
                    data = {"task_token": token, "round": round_no, "event": event,
                            "record_truncated": True, "body_budget_exhausted": self.used >= self.MAX_BODY}
                    wire = json.dumps(data, separators=(",", ":"))
                    break
                data[key] = data[key][:len(data[key]) // 2]
                data[key + "_truncated"] = True
                wire = json.dumps(data, ensure_ascii=False, separators=(",", ":"))
            self.used += sum(len(data.get(k, "")) for k in bodies)
            LOG.info("task_trace %s", wire)
        except Exception:
            # Diagnostics never affect the game decision.
            pass
