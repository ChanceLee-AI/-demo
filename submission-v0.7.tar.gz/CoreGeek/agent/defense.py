"""Persistent gunner assignments and conservative, unobstructed threat estimates."""
import itertools

from .world import dist, pos


def number(value, default=0):
    try:
        return max(0, float(value))
    except (TypeError, ValueError):
        return float(default)


def exposure(w, cell):
    """Potential next-turn damage, not a claim that every robot will attack.

    Buildings do not reduce this estimate: no undocumented shielding is assumed.
    A robot one step outside attack range contributes half its attack power.
    """
    total = 0.0
    defaults = {"smallRobot": 5, "middleRobot": 10, "largeRobot": 20, "bossRobot": 40}
    for robot in w.robots:
        if robot.get("abnormalState") == "dizzy":
            continue
        reach = number(robot.get("attackRange"), 3)
        power = number(robot.get("attackPower"), defaults.get(robot.get("roleType"), 10))
        distance = dist(robot, cell)
        if distance <= reach:
            total += power
        elif distance <= reach + 1:
            total += power * 0.5
    return total


def coverage(w, gun):
    kind = gun.get("roleType")
    level = max(1, min(3, int(number(gun.get("level"), 1))))
    ranges = {"railgun": (6, 8, 10), "rocket": (10, 15, 1000), "gatling": (3, 5, 7)}
    reach = number(gun.get("attackRange"), ranges[kind][level - 1])
    power = number(gun.get("attackPower"), 10 * level if kind == "railgun" else 20 if kind == "rocket" else 10)
    targets = sum(min(number(robot.get("health"), 1), power)
                  for robot in w.robots if dist(gun, robot) <= reach)
    return targets / (1 + number(gun.get("cooldown")))


class DefensePlanner:
    def __init__(self):
        self.assignments = {}
        self.blocked = {}
        self.refuges = {}
        self.round = None
        self.migrations = {}
        self.holds = set()
        self.move_reasons = {}
        self.risk = {}

    def _publish(self, w):
        w.defense_assignments = {rid: dict(value) for rid, value in self.assignments.items()}
        w.defense_refuges = dict(self.refuges)
        w.defense_holds = set(self.holds)
        w.defense_move_reasons = dict(self.move_reasons)
        w.defense_risk = {rid: dict(value) for rid, value in self.risk.items()}

    @staticmethod
    def _key(assignment):
        return assignment["weapon_id"], tuple(assignment["pos"])

    @staticmethod
    def _day_placement(w, cell, reachable):
        """Layout is a daytime preference, never a reason to interrupt fire."""
        if w.night:
            return 0
        inner = getattr(w, "defense_inner", set()) or set()
        planned = getattr(w, "wall_planned", set()) or set()
        if not inner and not planned:
            return 0
        if cell in planned:
            return 3
        if not inner:
            return 0
        if cell in inner:
            # A temporarily occupied interior can clear through the existing
            # yielding logic. Binding a future wall instead blocks completion.
            return 0 if reachable else 2
        # A brief blockage at an outer fallback keeps the existing three-turn
        # tolerance. It must not create churn between equivalent outer cells.
        return 1

    def _remember_targets(self, w):
        retained = {}
        for rid, assignment in self.assignments.items():
            key = self._key(assignment)
            old = self.migrations.get(rid)
            state = dict(old) if old and old["key"] == key else {
                "key": key, "arrived": None,
                "day_layout": bool(not w.night and
                                   (getattr(w, "defense_inner", None) or getattr(w, "wall_planned", None)) and
                                   self._day_placement(w, assignment["pos"], True) == 0),
            }
            if pos(w.own[rid]) == assignment["pos"] and state["arrived"] is None:
                state["arrived"] = w.round
            retained[rid] = state
        self.migrations = retained

    @staticmethod
    def _exchange(keys, previous):
        """Never solve a night assignment by swapping two existing gunners."""
        chosen = dict(keys)
        for rid, gid in keys:
            old = previous.get(rid)
            if not old or old["weapon_id"] == gid:
                continue
            for other, before in previous.items():
                if other != rid and before["weapon_id"] == gid and chosen.get(other) == old["weapon_id"]:
                    return True
        return False

    def prepare(self, w):
        if self.round == w.round:
            self._publish(w)
            return
        self.round = w.round
        previous = self.assignments
        self.holds, self.move_reasons = set(), {}
        self.risk = {}
        people, guns = list(w.people), list(w.weapons)
        by_gun = {str(gun["id"]): gun for gun in guns}
        fixed, fixed_cells, fixed_guns, old_routes = {}, set(), set(), {}
        # A short-lived actor blockage may clear; repeated blockage loses its
        # retained-position preference and triggers a different slot assignment.
        for person in people:
            rid = str(person["id"])
            old = previous.get(rid)
            route = w.route(person, {old["pos"]}) if old and old["weapon_id"] in by_gun else None
            old_routes[rid] = route
            self.blocked[rid] = self.blocked.get(rid, 0) + 1 if route and route.status == "blocked" else 0
        # Preserve a working gunner before optimizing any still-free stations.
        # This is a constraint, not a small score bonus that another gunner's
        # slightly better exposure could outweigh.
        for person in people:
            rid, current = str(person["id"]), pos(person)
            old = previous.get(rid)
            gun = by_gun.get(old["weapon_id"]) if old else None
            if not gun or old["weapon_id"] in fixed_guns:
                continue
            health = max(1, number(person.get("health"), 1))
            cells = w.adjacent(gun)
            route = old_routes[rid]
            metadata = self.migrations.get(rid)
            tracked = bool(metadata and metadata["key"] == self._key(old))
            arriving = tracked and metadata["arrived"] is None and current != old["pos"]
            protected = tracked and metadata["arrived"] is not None and w.round < metadata["arrived"] + 3
            target_valid = (old["pos"] in cells and self.blocked.get(rid, 0) < 3
                            and route is not None and route.status != "unreachable")
            first = route.steps[0] if route and route.steps else current
            target_safe = exposure(w, old["pos"]) < health and exposure(w, first) < health
            # A previous outer target may predate the construction layout. Its
            # migration/arrival lock must not permanently outrank a now-usable
            # inner stand. With no better safe option the ordinary retention
            # score below still keeps the usable outer station.
            day_retarget = not w.night and self._day_placement(w, old["pos"], bool(route and route.reachable)) > 0
            candidate, reason = None, None
            if (w.night and arriving and metadata.get("day_layout") and
                    current in cells and exposure(w, current) < health):
                # A daytime inner-layout trip must stop when this gun can
                # already fire safely. Night danger migrations keep their lock.
                candidate = {"weapon_id": old["weapon_id"], "pos": current}
            elif arriving and target_valid and target_safe and not day_retarget:
                candidate, reason = dict(old), "continue_migration"
            elif w.night and current in cells and exposure(w, current) < health:
                candidate = {"weapon_id": old["weapon_id"], "pos": current}
            elif (protected or w.night) and target_valid and target_safe and not day_retarget:
                candidate = dict(old)
                reason = "continue_migration" if tracked else "return"
            elif w.night and current in cells and exposure(w, current) >= health:
                # Only the endangered gunner moves; try a safe one-step square
                # around the same gun before considering any released gun.
                nearby = [cell for cell in w.neighbors(current)
                          if cell in cells and cell not in w.occupied | fixed_cells
                          and cell not in w.move_avoid.get(rid, set())
                          and exposure(w, cell) < health]
                if nearby:
                    target = min(nearby, key=lambda cell: (exposure(w, cell), cell))
                    candidate = {"weapon_id": old["weapon_id"], "pos": target}
                    reason = "lethal_reposition"
            if candidate and candidate["pos"] not in fixed_cells:
                fixed[rid] = candidate
                fixed_cells.add(candidate["pos"])
                fixed_guns.add(candidate["weapon_id"])
                if candidate["pos"] == current:
                    self.holds.add(rid)
                else:
                    self.move_reasons[rid] = reason
        options = {}
        for person in people:
            rid, current = str(person["id"]), pos(person)
            if rid in fixed:
                continue
            health = max(1, number(person.get("health"), 1))
            for gun in guns:
                gid = str(gun["id"])
                if gid in fixed_guns:
                    continue
                choices = []
                for cell in sorted(w.adjacent(gun)):
                    if w.expired():
                        break
                    if cell in fixed_cells or cell in w.occupied and cell != current:
                        continue
                    old = previous.get(rid)
                    same = bool(old and old["weapon_id"] == gid and old["pos"] == cell)
                    if same and self.blocked.get(rid, 0) >= 3:
                        continue
                    route = w.route(person, {cell}, reserved=w.move_avoid.get(rid, set()))
                    if route.distance is None:
                        continue
                    first = route.steps[0] if route.steps else current
                    immediate, future = exposure(w, first), exposure(w, cell)
                    # A route's first step changes as actors travel. Using that
                    # transient exposure in the aggregate assignment score can
                    # make two safe gunners exchange guns and reverse forever.
                    # Keep it in the lethal-step guard, but compare sustained
                    # exposure at the destination before retaining assignments.
                    damage = future
                    # Daytime layout preference precedes retention; at night its
                    # constant zero preserves the established combat ordering.
                    score = (int(max(immediate, future) >= health), damage,
                             self._day_placement(w, cell, route.reachable), -coverage(w, gun),
                             -int(same), route.distance + (2 if not route.reachable else 0))
                    choices.append((score, cell))
                if choices:
                    options[(rid, gid)] = sorted(choices)
            if w.night:
                # New/invalidated bindings also prefer an already usable control
                # position. A cold gun or empty target set does not require travel.
                stationary = {key: [choice for choice in choices if choice[1] == current and choice[0][0] == 0]
                              for key, choices in options.items() if key[0] == rid}
                if any(stationary.values()):
                    for key in list(options):
                        if key[0] == rid:
                            if stationary[key]:
                                options[key] = stationary[key]
                            else:
                                del options[key]
                elif (previous.get(rid) and (rid, previous[rid]["weapon_id"]) in options
                      and any(choice[0][0] == 0 for choice in options[(rid, previous[rid]["weapon_id"])])):
                    # Repair a released station around its old gun first. Other
                    # working gunners remain fixed and cannot be displaced.
                    old_key = (rid, previous[rid]["weapon_id"])
                    for key in list(options):
                        if key[0] == rid and key != old_key:
                            del options[key]
        best, best_key = {}, (0, 0, 0, 0, 0, 0, 0)
        # At most three people, three guns and eight cells per gun. Enumerating
        # these small assignments avoids greedy collisions between control cells.
        remaining_people = [p for p in people if str(p["id"]) not in fixed]
        remaining_guns = [g for g in guns if str(g["id"]) not in fixed_guns]
        for size in range(min(len(remaining_people), len(remaining_guns)), 0, -1):
            for selected in itertools.combinations(remaining_people, size):
                for ordered_guns in itertools.permutations(remaining_guns, size):
                    keys = [(str(p["id"]), str(g["id"])) for p, g in zip(selected, ordered_guns)]
                    if any(key not in options for key in keys):
                        continue
                    if w.night and self._exchange(keys, previous):
                        continue
                    for choices in itertools.product(*(options[key] for key in keys)):
                        if w.expired():
                            break
                        cells = [choice[1] for choice in choices]
                        if len(set(cells)) != size:
                            continue
                        sums = tuple(sum(choice[0][i] for choice in choices) for i in range(6))
                        score = (sums[0], -size) + sums[1:]
                        if score < best_key:
                            best_key = score
                            best = {rid: {"weapon_id": gid, "pos": cell}
                                    for (rid, gid), cell in zip(keys, cells)}
            if w.expired():
                break
        if not best and not fixed and w.expired():
            # Keep known assignments when planning runs out of its CPU budget.
            best = {rid: dict(value) for rid, value in previous.items()
                    if rid in w.own and value["weapon_id"] in by_gun
                    and value["pos"] in w.adjacent(by_gun[value["weapon_id"]])
                    and exposure(w, value["pos"]) < number(w.own[rid].get("health"), 1)}
        best.update(fixed)
        self.assignments = best
        for person in people:
            rid = str(person["id"])
            assigned = best.get(rid)
            if not assigned:
                continue
            if assigned["pos"] == pos(person):
                self.holds.add(rid)
            elif rid not in self.move_reasons:
                old = previous.get(rid)
                self.move_reasons[rid] = ("blocked_retarget" if self.blocked.get(rid, 0) >= 3 else
                                          "return" if old and old == assigned else "reassignment")
        self.refuges = {}
        reserved = {value["pos"] for value in best.values()}
        for person in people:
            rid, current = str(person["id"]), pos(person)
            if rid in best or not w.robots:
                continue
            choices = []
            # An unassigned endangered gunner retreats locally; it must not be
            # pulled back toward an unsafe gun by the ordinary base fallback.
            for x in range(max(0, current[0] - 3), min(w.width, current[0] + 4)):
                for y in range(max(0, current[1] - 3), min(w.height, current[1] + 4)):
                    cell = (x, y)
                    if w.expired() or cell in reserved or cell in w.occupied and cell != current:
                        continue
                    route = w.route(person, {cell}, reserved=reserved)
                    if not route.reachable:
                        continue
                    first = route.steps[0] if route.steps else current
                    immediate, future = exposure(w, first), exposure(w, cell)
                    score = (max(immediate, future) >= number(person.get("health"), 1),
                             immediate + future * 0.5, route.distance, cell)
                    choices.append((score, cell))
            target = min(choices)[1] if choices else current
            self.refuges[rid] = target
            reserved.add(target)
            if target != current:
                self.move_reasons[rid] = "refuge"
        # Remaining on the same square does not reduce exposure. If no safer
        # executable retreat was selected, keep using an available adjacent gun
        # rather than spending every night turn idle at its control station.
        if w.night:
            assigned_guns = {value["weapon_id"] for value in best.values()}
            for person in people:
                rid, current = str(person["id"]), pos(person)
                if rid in best or self.refuges.get(rid) != current:
                    continue
                candidates = [gun for gun in guns if str(gun["id"]) not in assigned_guns
                              and current in w.adjacent(gun)]
                if not candidates:
                    continue
                old_gid = (previous.get(rid) or {}).get("weapon_id")
                gun = min(candidates, key=lambda g: (str(g["id"]) != old_gid,
                                                     -coverage(w, g), str(g["id"])))
                gid = str(gun["id"])
                best[rid] = {"weapon_id": gid, "pos": current}
                assigned_guns.add(gid)
                self.holds.add(rid)
                self.refuges.pop(rid, None)
                self.move_reasons.pop(rid, None)
                self.risk[rid] = {"reason": "stay_and_operate_no_better_retreat"}
        for person in people:
            rid = str(person["id"])
            row = self.risk.setdefault(rid, {"reason": self.move_reasons.get(rid, "hold")})
            row.update(hp=number(person.get("health")), estimated_damage=exposure(w, pos(person)),
                       stand=list(best[rid]["pos"]) if rid in best else None,
                       refuge=list(self.refuges[rid]) if rid in self.refuges else None)
        self._remember_targets(w)
        self._publish(w)
