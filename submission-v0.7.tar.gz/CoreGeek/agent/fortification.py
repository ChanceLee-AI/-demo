"""Two-worker material batches and a persistent, observed perimeter build plan."""
from collections import Counter

from .economy import mine_key
from .world import action, dist, pos


BATCH_SIZE = 6


class FortificationPlanner:
    def __init__(self):
        self.plans = {}
        self.known_targets = set()
        self.report = {}
        self.completed_once = False
        self.repair_batch = None
        self.progress = {}
        self.stalled = {}
        self.avoid_stands = {}

    def _reserve_material(self, w, remaining, preferred=()):
        budget = len(remaining)
        preferred = set(preferred)
        reservations = {}
        for worker in sorted(w.workers, key=lambda role: (str(role["id"]) not in preferred, str(role["id"]))):
            amount = min(self._stock(worker), budget)
            reservations[str(worker["id"])] = amount
            budget -= amount
        w.reserved_stone = reservations
        return reservations

    @staticmethod
    def _stock(worker):
        return Counter(worker.get("backpack") or []).get("stone", 0)

    def reserve(self, w, construction):
        """Reserve existing material, including at night and on a paused workday."""
        targets = set(getattr(w, "wall_targets", ()))
        if targets:
            self.known_targets = targets
        standing = {pos(role) for role in w.own.values() if role.get("roleType") == "wall"}
        remaining = self.known_targets - standing
        if self.known_targets and not remaining:
            self.completed_once = True
            self.repair_batch = None
        disabled = ("wall" in construction.disabled_kinds | getattr(construction, "paused_kinds", set())
                    or "build" in getattr(w, "disabled_actions", set()))
        if not w.station or disabled:
            remaining = set()
        reservations = self._reserve_material(w, remaining, (self.repair_batch or {}).get("workers", ()))
        if not remaining:
            self.plans.clear()
        live = {str(worker["id"]) for worker in w.workers}
        self.plans = {rid: plan for rid, plan in self.plans.items() if rid in live}
        reselections = (list(self.report.get("route_reselections", ()))
                        if self.report.get("round") == w.round else [])
        for worker in w.workers:
            rid, plan = str(worker["id"]), self.plans.get(str(worker["id"]), {})
            marker = (pos(worker), self._stock(worker))
            before = self.progress.get(rid)
            if before and before[0] == w.round:
                continue
            travelling = plan.get("stand") is not None and pos(worker) != plan["stand"]
            unchanged = before and before[0] + 1 == w.round and before[1] == marker
            self.stalled[rid] = self.stalled.get(rid, 0) + 1 if travelling and unchanged else 0
            if self.stalled[rid] >= 3:
                old_stand = plan.pop("stand", None)
                if old_stand is not None:
                    self.avoid_stands[rid] = (old_stand, w.round + 4)
                    reselections.append({"role_id": rid, "reason": "three_rounds_no_progress",
                                         "old_stand": list(old_stand)})
                self.stalled[rid] = 0
            self.progress[rid] = (w.round, marker)
        self.progress = {rid: value for rid, value in self.progress.items() if rid in live}
        self.stalled = {rid: value for rid, value in self.stalled.items() if rid in live}
        self.avoid_stands = {rid: value for rid, value in self.avoid_stands.items()
                             if rid in live and value[1] > w.round}
        self.report = {"round": w.round, "target_count": len(self.known_targets),
                       "standing": len(self.known_targets & standing), "remaining": len(remaining),
                       "reserved_stone": dict(reservations), "workers": {},
                       "completed_once": self.completed_once, "route_reselections": reselections,
                       "reason": "disabled" if disabled else "complete" if not remaining else "pending"}
        w.wall_work = self.report

    @staticmethod
    def _home_goals(w, worker):
        rid = str(worker["id"])
        assigned = w.defense_assignments.get(rid)
        if assigned:
            return {tuple(assigned["pos"])}
        if rid in w.defense_refuges:
            return {tuple(w.defense_refuges[rid])}
        objects = w.weapons or ([w.station] if w.station else [])
        return {cell for obj in objects for cell in w.adjacent(obj)}

    def _tour(self, w, worker, start, targets, count, add_walls=()):
        """Short greedy delivery tour; each prefix includes its own safe return."""
        layout = w.wall_layout
        available, future = set(targets), set(add_walls)
        current, elapsed, first = pos(start), 0, None
        options = []
        order = {cell: index for index, cell in enumerate(layout.targets)}
        for _ in range(min(BATCH_SIZE, count, len(available))):
            if w.expired():
                break
            choices = []
            for cell in sorted(available, key=lambda cell: order.get(cell, len(order))):
                if w.expired():
                    break
                if cell == current or cell in w.static | future:
                    continue
                # The target becomes a wall only after arriving at its control
                # square. All candidates share the same pre-build static graph.
                route = layout.route(w, current, w.adjacent(cell) - future - {cell}, add_walls=future)
                if route.reachable:
                    choices.append((route.total_distance, order.get(cell, len(order)), cell, route))
            if not choices:
                break
            _, _, cell, route = min(choices, key=lambda item: item[:2])
            elapsed += route.total_distance + 1
            current = route.goal
            future.add(cell)
            available.remove(cell)
            if first is None:
                first = cell
            home = layout.route(w, current, self._home_goals(w, worker), add_walls=future)
            if home.reachable:
                options.append({"count": len(future) - len(set(add_walls)), "turns": elapsed + home.total_distance,
                                "first": first, "home_turns": home.total_distance})
        return options

    def _note(self, economy, worker, reason, **details):
        rid = str(worker["id"])
        self.report["workers"][rid] = dict(reason=reason, **details)
        economy.note(rid, "wall", reason, **details)

    def _build(self, w, commands, worker, targets, construction, economy, move, claimed, additions, stands):
        rid, current = str(worker["id"]), pos(worker)
        old = self.plans.get(rid, {})
        destinations = {pos(cell) for command in commands.values() if command.get("action") == "move"
                        for cell in command.get("targetPos", [])}
        candidates = [cell for cell in targets if cell not in claimed | additions | destinations
                      and cell not in w.occupied and not construction.avoided("wall", cell, w)]
        order = {cell: index for index, cell in enumerate(w.wall_layout.targets)}
        choices = []
        failures = Counter()
        for cell in candidates:
            if w.expired():
                break
            goals = w.adjacent(cell) - additions - stands - {cell}
            avoid = self.avoid_stands.get(rid)
            if avoid and avoid[1] > w.round and len(goals) > 1:
                goals -= {avoid[0]}
            route = w.route(worker, goals, reserved=additions | destinations)
            if not route.reachable and route.status != "budget_exhausted":
                route = w.plan_route(worker, worker, goals, add_walls=additions)
            if cell == old.get("target") and old.get("stand") in goals:
                retained = w.route(worker, {old["stand"]}, reserved=additions | destinations)
                if retained.reachable:
                    route = retained
            if route.reachable and not (route.distance and "move" in getattr(w, "disabled_actions", set())):
                choices.append((cell != old.get("target"), route.total_distance, order.get(cell, len(order)), cell, goals, route))
            elif not route.reachable:
                failures["wall:" + route.status] += 1
        for _, _, _, cell, goals, route in sorted(choices, key=lambda item: item[:3]):
            if w.expired():
                break
            if not w.wall_layout.safe(w, additions | {cell}, commands):
                failures["wall:unsafe_construction"] += 1
                continue
            home = w.plan_return_route(worker, route.goal, add_walls=additions | {cell})
            if not home.reachable or route.total_distance + 1 + home.total_distance + w.return_margin > w.daylight_left:
                failures["home:" + (home.status if not home.reachable else "time_insufficient")] += 1
                continue
            self.plans[rid] = {"mode": "build", "target": cell, "stand": route.goal}
            claimed.add(cell)
            stands.add(route.goal)
            if dist(worker, cell) <= 1:
                commands[rid] = action("build", cell, name="wall")
                additions.add(cell)
                self._note(economy, worker, "build_wall", target=list(cell), home_turns=home.total_distance)
                return True
            if move(w, commands, worker, {route.goal}):
                self._note(economy, worker, "deliver_material", target=list(cell), home_turns=home.total_distance,
                           route_status=route.planning_status)
                return True
            self._note(economy, worker, "wall_route_blocked", target=list(cell))
            return True
        self.plans.pop(rid, None)
        if w.expired():
            failures["planning:budget_exhausted"] += 1
        self._note(economy, worker, "no_safe_wall_window", route_failures=dict(failures))
        return False

    def _repair_workers(self, w, workers, targets, usable, economy):
        """A small repair batch uses one feasible owner; initial fortifying uses both."""
        if not self.completed_once:
            self.report["repair_mode"] = "initial_parallel"
            return workers
        batch = self.repair_batch
        if batch is None or not set(batch["targets"]).intersection(targets):
            batch = self.repair_batch = {"targets": set(targets), "mode": "single" if len(targets) <= 3 else "parallel",
                                        "workers": ()}
        if batch["mode"] == "parallel" or len(targets) > 3:
            batch["mode"] = "parallel"
            self.report["repair_mode"] = "parallel"
            return workers
        needed = len(targets)
        shared_missing = max(0, needed - sum(self._stock(worker) for worker in w.workers))
        feasible = []
        for worker in workers:
            if w.expired():
                break
            rid, stock = str(worker["id"]), self._stock(worker)
            required = max(0, needed - stock)
            # Never pretend another worker's stone belongs to this candidate,
            # nor gather duplicates of material already owned by the team.
            if required > shared_missing or required > max(0, worker.get("backPackCapability", 100) - len(worker.get("backpack", []))):
                continue
            choices = []
            if not required:
                choices.append((worker, 0, 0, None))
            else:
                for key, mine in usable.items():
                    if economy.mines.get(key, 0) < required:
                        continue
                    goals = w.adjacent(mine)
                    avoid = self.avoid_stands.get(rid)
                    if avoid and avoid[1] > w.round and len(goals) > 1:
                        goals -= {avoid[0]}
                    previous = self.plans.get(rid, {})
                    if previous.get("mine") == key and previous.get("stand") in goals:
                        goals = {previous["stand"]}
                    route = w.plan_route(worker, worker, goals)
                    if route.reachable and not (route.distance and "move" in getattr(w, "disabled_actions", set())):
                        choices.append((route.goal, route.total_distance, required,
                                        {"mode": "mine", "mine": key, "stand": route.goal, "batch_goal": needed}))
            for start, travel, collect, hint in choices:
                tour = next((tour for tour in self._tour(w, worker, start, targets, needed) if tour["count"] == needed), None)
                if not tour:
                    continue
                if tour["turns"] > needed and "move" in getattr(w, "disabled_actions", set()):
                    continue
                turns = travel + collect + tour["turns"]
                if turns + w.return_margin <= w.daylight_left:
                    previous = self.plans.get(rid, {})
                    changed_mine = bool(hint and previous.get("mode") == "mine" and hint["mine"] != previous.get("mine"))
                    feasible.append((rid not in batch["workers"], changed_mine, turns, rid, worker, hint))
        if not feasible:
            batch["workers"] = ()
            self.report["repair_mode"] = "cooperative_fallback"
            self.report["repair_reason"] = "no_single_complete_trip"
            return workers
        _, _, turns, rid, selected, hint = min(feasible, key=lambda choice: choice[:4])
        batch["workers"] = (rid,)
        self.report.update(repair_mode="single", repair_worker=rid, repair_total_turns=turns)
        for other in workers:
            if str(other["id"]) != rid:
                self.plans.pop(str(other["id"]), None)
        if hint:
            self.plans[rid] = hint
        reservations = self._reserve_material(w, targets, (rid,))
        self.report["reserved_stone"] = dict(reservations)
        return [selected]

    def step(self, w, commands, workers, economy, construction, move, closed):
        """Return only workers committed to feasible wall work this round."""
        w.wall_mine_reservations = {}
        if w.night or not workers:
            return set()
        layout = getattr(w, "wall_layout", None)
        if not layout or not layout.ready or not construction.available("wall", w):
            self.report["reason"] = "layout_unavailable" if not layout or not layout.ready else "construction_paused"
            return set()
        standing = {pos(role) for role in w.own.values() if role.get("roleType") == "wall"}
        targets = set(layout.targets) - standing
        if not targets:
            self.report["reason"] = "complete"
            self.plans.clear()
            return set()
        targets = {cell for cell in targets if not construction.avoided("wall", cell, w)}
        if not targets:
            self.report["reason"] = "construction_paused"
            return set()
        self.report["reason"] = "fortifying"
        workers = sorted(workers, key=lambda worker: (self.plans.get(str(worker["id"]), {}).get("mode") != "mine", str(worker["id"])))
        stocks = {str(worker["id"]): self._stock(worker) for worker in w.workers}
        deficit = max(0, len(targets) - sum(stocks.values()))
        committed, claimed, additions, stands = set(), set(), set(), set()
        mine_reserved = Counter()
        # Mining reservations include all remaining yields in a worker's current
        # batch. They are promises, not decrements of observed mine inventory.
        usable = {mine_key(zone): zone for zone in w.zones if zone.get("neutralType") == "stone"
                  and economy.mines.get(mine_key(zone), 0) > 0
                  and economy.blocked_until.get(mine_key(zone), 0) <= w.round}
        if closed("stone", w.day) or "collect" in getattr(w, "disabled_actions", set()):
            usable = {}
        workers = self._repair_workers(w, workers, targets, usable, economy)
        for index, worker in enumerate(workers):
            if w.expired():
                break
            rid, stock = str(worker["id"]), stocks[str(worker["id"])]
            old = self.plans.get(rid, {})
            old_mine = old.get("mine")
            keep_batch = old.get("mode") == "mine" and old_mine in usable and stock < old.get("batch_goal", 0)
            if stock and not keep_batch:
                if self._build(w, commands, worker, targets, construction, economy, move, claimed, additions, stands):
                    committed.add(rid)
                continue
            if deficit <= 0 or not usable:
                if stock and self._build(w, commands, worker, targets, construction, economy, move, claimed, additions, stands):
                    committed.add(rid)
                else:
                    self.plans.pop(rid, None)
                    self._note(economy, worker, "materials_allocated" if deficit <= 0 else "no_stone_mine")
                continue
            capacity = max(0, worker.get("backPackCapability", 100) - len(worker.get("backpack", [])))
            new_goal = min(BATCH_SIZE, stock + (deficit + len(workers) - index - 1) // (len(workers) - index))
            quota = min(capacity, deficit, max(0, (old.get("batch_goal", stock) if keep_batch else new_goal) - stock))
            candidates = sorted(usable.items(), key=lambda pair: (pair[0] != old_mine if keep_batch else False,
                                                                 dist(worker, pair[1]), pair[0]))
            selected = None
            failures = Counter()
            for key, mine in candidates:
                if w.expired():
                    break
                harvest = min(quota, max(0, economy.mines.get(key, 0) - mine_reserved[key]))
                if harvest <= 0:
                    continue
                goals = w.adjacent(mine) - stands - additions
                avoid = self.avoid_stands.get(rid)
                if avoid and avoid[1] > w.round and len(goals) > 1:
                    goals -= {avoid[0]}
                route = w.route(worker, goals, reserved=additions)
                if not route.reachable and route.status != "budget_exhausted":
                    route = w.plan_route(worker, worker, goals, add_walls=additions)
                if not route.reachable or route.distance and "move" in getattr(w, "disabled_actions", set()):
                    failures["mine:" + (route.status if not route.reachable else "move_disabled")] += 1
                    continue
                # Preserve the collection square as well as the mine, avoiding
                # two workers oscillating between opposite preferred stands.
                previous_stand = old.get("stand")
                if key == old_mine and previous_stand in goals:
                    retained = w.route(worker, {previous_stand}, reserved=additions)
                    if retained.reachable:
                        route = retained
                tours = self._tour(w, worker, route.goal, targets - claimed, stock + harvest, additions)
                for amount in range(harvest, 0, -1):
                    delivery = next((tour for tour in tours if tour["count"] == stock + amount), None)
                    if delivery and route.total_distance + amount + delivery["turns"] + w.return_margin <= w.daylight_left:
                        selected = key, mine, route, amount, delivery
                        break
                if selected:
                    break
                failures["wall_trip:time_insufficient" if tours else "wall_trip:unreachable"] += 1
            if selected is None:
                if stock and self._build(w, commands, worker, targets, construction, economy, move, claimed, additions, stands):
                    committed.add(rid)
                else:
                    self.plans.pop(rid, None)
                    if w.expired():
                        failures["planning:budget_exhausted"] += 1
                    self._note(economy, worker, "no_material_round_trip", route_failures=dict(failures))
                continue
            key, mine, route, amount, delivery = selected
            total_turns = route.total_distance + amount + delivery["turns"]
            stands.add(route.goal)
            mine_reserved[key] += amount
            deficit -= amount
            self.plans[rid] = {"mode": "mine", "mine": key, "stand": route.goal,
                               "batch_goal": stock + amount}
            if route.distance == 0:
                commands[rid] = action("collect", pos(mine))
                self._note(economy, worker, "collect_material", batch_goal=stock + amount,
                           remaining_collect=amount, mine=list(pos(mine)), home_turns=delivery["home_turns"],
                           total_turns=total_turns, estimated_finish_round=w.round + total_turns - 1,
                           return_margin=w.return_margin)
                committed.add(rid)
            elif move(w, commands, worker, {route.goal}):
                self._note(economy, worker, "seek_material", batch_goal=stock + amount,
                           remaining_collect=amount, mine=list(pos(mine)), home_turns=delivery["home_turns"],
                           total_turns=total_turns, estimated_finish_round=w.round + total_turns - 1,
                           return_margin=w.return_margin)
                committed.add(rid)
            else:
                self._note(economy, worker, "material_route_blocked", mine=list(pos(mine)))
                committed.add(rid)
        w.wall_mine_reservations = dict(mine_reserved)
        return committed
