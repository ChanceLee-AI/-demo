"""Shared decision state for script, callback, Flask, and plain WSGI entries.

Flask is optional and imported only when an SDK application is requested.
This module never starts a listener or runs model/sandbox commands.
"""
import json
import sys
import threading


MAX_REQUEST_BYTES = 8 * 1024 * 1024
_runtime = None
_runtime_lock = threading.Lock()
_app = None
_app_lock = threading.Lock()
_callback_sequence = 0
_sequence_lock = threading.Lock()


def _emit(message):
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.write(message + "\n")
            stream.flush()
        except Exception:
            pass


def _empty_response():
    return {"roleCommandMap": {}, "prompt": "", "executeCmd": ""}


class Runtime:
    def __init__(self):
        from .engine import Engine
        self.engine = Engine()
        self.decision_lock = threading.Lock()


def get_runtime():
    """Initialize exactly one Engine and decision lock per Python process."""
    global _runtime
    with _runtime_lock:
        if _runtime is None:
            _runtime = Runtime()
        return _runtime


def _strict_response(value):
    if not isinstance(value, dict):
        raise ValueError("response_not_object")
    result = {key: value.get(key) for key in ("roleCommandMap", "prompt", "executeCmd")}
    if (not isinstance(result["roleCommandMap"], dict)
            or not isinstance(result["prompt"], str)
            or not isinstance(result["executeCmd"], str)):
        raise ValueError("response_shape")
    # Isolate a callback caller's mutations from the Engine's cached response.
    return json.loads(json.dumps(result, ensure_ascii=False, allow_nan=False))


def callback(raw):
    global _callback_sequence
    with _sequence_lock:
        _callback_sequence += 1
        sequence = _callback_sequence
    if sequence <= 3:
        _emit("callback seq=%s stage=received" % sequence)
    runtime, acquired = None, False
    phase = "agent_import"
    try:
        runtime = get_runtime()
        phase = "decision_lock"
        acquired = runtime.decision_lock.acquire(timeout=1.0)
        if not acquired:
            _emit("callback seq=%s stage=failed reason=busy" % sequence)
            return _empty_response()
        phase = "decision"
        response = _strict_response(runtime.engine.handle(raw))
        if sequence <= 3:
            _emit("callback seq=%s stage=decided actions=%s" % (sequence, len(response["roleCommandMap"])))
        return response
    except Exception as exc:
        _emit("callback seq=%s stage=failed phase=%s error=%s" % (sequence, phase, type(exc).__name__))
        return _empty_response()
    finally:
        if acquired:
            runtime.decision_lock.release()


def _health():
    from . import VERSION
    return {"status": "ok", "version": VERSION}


def _parse_body(body):
    return json.loads(body.decode("utf-8-sig"),
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError("nonfinite")))


class WSGIApp:
    """Fallback for WSGI hosts that do not provide Flask; no socket is opened."""
    def __call__(self, environ, start_response):
        method = environ.get("REQUEST_METHOD", "GET").upper()
        status = "200 OK"
        if method == "GET":
            response = _health()
        elif method == "POST":
            try:
                length = environ.get("CONTENT_LENGTH", "")
                if (not isinstance(length, str) or not length
                        or len(length) > 10 or any(c not in "0123456789" for c in length)):
                    raise ValueError("content_length_invalid")
                size = int(length)
                if not 0 < size <= MAX_REQUEST_BYTES:
                    raise ValueError("content_length_out_of_bounds")
                body = environ["wsgi.input"].read(size)
                if len(body) != size:
                    raise ValueError("body_incomplete")
                response = callback(_parse_body(body))
            except Exception as exc:
                _emit("sdk_request stage=failed phase=read_parse error=" + type(exc).__name__)
                response = _empty_response()
        else:
            status, response = "405 Method Not Allowed", _empty_response()
        encoded = json.dumps(response, ensure_ascii=False, allow_nan=False, separators=(",", ":")).encode("utf-8")
        start_response(status, [("Content-Type", "application/json; charset=utf-8"),
                                ("Content-Length", str(len(encoded)))])
        return [encoded]


def _create_app():
    try:
        from flask import Flask, request, jsonify
    except ImportError:
        _emit("entry stage=app backend=wsgi")
        return WSGIApp()
    app = Flask(__name__)
    app.config["MAX_CONTENT_LENGTH"] = MAX_REQUEST_BYTES

    @app.route("/", defaults={"path": ""}, methods=["GET", "POST"])
    @app.route("/<path:path>", methods=["GET", "POST"])
    def process_request(path):
        if request.method == "GET":
            return jsonify(_health())
        try:
            # Match the provided SDK's Flask input/output boundary.
            raw = request.get_json()
            result = callback(raw)
        except Exception as exc:
            _emit("sdk_request stage=failed phase=read_parse error=" + type(exc).__name__)
            result = _empty_response()
        return jsonify(result)

    _emit("entry stage=app backend=flask")
    return app


def get_app():
    """Return one lazy WSGI app shared by both public entry modules."""
    global _app
    with _app_lock:
        if _app is None:
            _app = _create_app()
        return _app
