"""Build bounded file-reading commands for the judge's sandbox, never run them here."""
import hashlib
import json
import posixpath
import re
import shlex


MARKER = "__TASK_FILE_LOOKUP__"
# This source is sent to the sandbox. It deliberately has no project imports.
LOOKUP_SOURCE = r'''
import collections, json, os, stat, sys, time
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
q = json.loads(sys.argv[1])
started = time.monotonic()
meta = {"nonce": q["nonce"], "requested": q["file"], "cwd": os.getcwd(),
        "status": "not_found", "candidates": [], "roots": [], "truncated": False,
        "directories": 0, "entries": 0, "permission_denied": 0}
content = ""
seen = set()
candidates = set()
exhausted = False
def expired():
    return time.monotonic() - started >= 2.0
def regular(path):
    try:
        return stat.S_ISREG(os.stat(path).st_mode)
    except PermissionError:
        meta["permission_denied"] += 1
    except OSError:
        pass
    return False
direct = os.path.abspath(os.path.expanduser(q["file"]))
if regular(direct):
    candidates.add(direct)
else:
    roots = [os.getcwd(), os.path.expanduser("~")] + q["roots"]
    queue = collections.deque()
    for value in roots:
        path = os.path.abspath(os.path.expanduser(value))
        if regular(path):
            path = os.path.dirname(path)
        # Never recursively search the filesystem root or follow directory links.
        if path == os.path.dirname(path) or os.path.islink(path) or path in meta["roots"]:
            continue
        meta["roots"].append(path)
        queue.append((path, 0))
    name = os.path.basename(q["file"])
    while queue:
        if expired() or meta["directories"] >= 128 or meta["entries"] >= 2048:
            exhausted = True
            break
        directory, depth = queue.popleft()
        if directory in seen:
            continue
        seen.add(directory)
        meta["directories"] += 1
        try:
            with os.scandir(directory) as entries:
                for entry in entries:
                    if expired() or meta["entries"] >= 2048:
                        exhausted = True
                        break
                    meta["entries"] += 1
                    if entry.name == name and entry.is_file(follow_symlinks=False):
                        candidates.add(os.path.abspath(entry.path))
                    if depth < 3 and entry.is_dir(follow_symlinks=False):
                        queue.append((entry.path, depth + 1))
        except PermissionError:
            meta["permission_denied"] += 1
        except OSError:
            pass
        if exhausted:
            break
meta["candidates"] = sorted(candidates)[:8]
if len(candidates) > 1:
    meta["status"] = "ambiguous"
elif exhausted:
    # An incomplete search cannot prove that a single matching basename is unique.
    meta["status"] = "search_budget_exhausted"
elif len(candidates) == 1:
    path = next(iter(candidates))
    try:
        if expired():
            meta["status"] = "search_budget_exhausted"
        else:
            with open(path, encoding="utf-8", errors="replace") as handle:
                content = handle.read(12001)
            meta["truncated"] = len(content) > 12000
            content = content[:12000]
            meta["status"], meta["resolved"] = "resolved", path
    except (OSError, ValueError) as exc:
        meta["status"], meta["error"] = "read_error", type(exc).__name__
elif meta["permission_denied"]:
    meta["status"] = "permission_denied"
meta["elapsed_ms"] = round((time.monotonic() - started) * 1000)
# Bound metadata independently, including unexpectedly long HOME/cwd values.
for key in ("requested", "cwd", "resolved"):
    if key in meta:
        meta[key] = meta[key][:1024]
meta["roots"] = [p[:160] for p in meta["roots"][:12]]
meta["candidates"] = [p[:160] for p in meta["candidates"][:8]]
header = "__TASK_FILE_LOOKUP__" + json.dumps(meta, ensure_ascii=False, separators=(",", ":"))
if len(header) > 3900:
    meta["roots"], meta["candidates"] = [], []
    meta["metadata_truncated"] = True
    header = "__TASK_FILE_LOOKUP__" + json.dumps(meta, ensure_ascii=False, separators=(",", ":"))
sys.stdout.write(header + "\n" + content[:max(0, 15999 - len(header))])
sys.exit(0 if meta["status"] == "resolved" else 2)
'''


def _texts(task):
    texts = [task["text"]]
    for observation in task.get("observations", []):
        text = observation["result"]["output"]
        # Our own lookup metadata is not new external evidence authorizing a retry.
        if text.startswith(MARKER):
            text = text.partition("\n")[2]
        texts.append(text)
    return texts


def evidence_roots(task):
    """Only paths actually present in the task or returned evidence, not model guesses."""
    roots = set()
    for text in _texts(task):
        # Quoted paths preserve spaces; the second branch handles plain Unix paths.
        matches = list(re.finditer(r'''["'`](/[^"'`\r\n]{1,1024})["'`]''', text))
        quoted = [m.group(1) for m in matches]
        plain = [m.group(1) for m in re.finditer(r'''(?<![\w/])(/[^\s"'`<>;,，。；:：\[\]{}()]{1,1024})''', text)
                 if not any(q.start() <= m.start() < q.end() for q in matches)]
        for path in quoted + plain:
            path = posixpath.normpath(path)
            if path.startswith("/") and path != "/" and len(path) <= 1024:
                roots.add(path)
    selected, remaining = [], 2048
    for path in sorted(roots):
        if len(path) <= min(512, remaining):
            selected.append(path)
            remaining -= len(path)
        if len(selected) == 16:
            break
    return selected


def _expands(command):
    """Only literal shell words are eligible; preserve quoting/expansion semantics."""
    quote, escaped = None, False
    for char in command:
        if escaped:
            escaped = False
            continue
        if quote == "'":
            if char == "'":
                quote = None
            continue
        if char == "\\":
            escaped = True
        elif char == quote:
            quote = None
        elif quote is None and char in "\"'":
            quote = char
        elif char in "$`" or quote is None and char in "~*?[{}#":
            return True
    return False


def prepare_read(command, task):
    """Return a sandbox command and its lookup request, or the original command."""
    if "\n" in command or "\r" in command or _expands(command):
        return command, None
    try:
        lexer = shlex.shlex(command, posix=True, punctuation_chars=True)
        lexer.whitespace_split, lexer.commenters = True, ""
        parts = list(lexer)
    except ValueError:
        return command, None
    if parts[:2] == ["cat", "--"]:
        parts = ["cat"] + parts[2:]
    if (len(parts) != 2 or parts[0] != "cat" or parts[1].startswith("-")
            or len(parts[1]) > 1024 or "\x00" in parts[1]):
        return command, None
    name = posixpath.basename(parts[1])
    if name in ("", ".", "..") or not any(name in text for text in _texts(task)):
        return command, None
    request = {"file": parts[1], "roots": evidence_roots(task)}
    # Merely guessing a different prefix for the same basename is not new evidence.
    request["evidence_key"] = hashlib.sha256(
        json.dumps([name, request["roots"]], sort_keys=True).encode()).hexdigest()[:20]
    signature = hashlib.sha256(json.dumps(request, sort_keys=True).encode()).hexdigest()[:20]
    request["nonce"] = signature
    encoded = json.dumps(request, ensure_ascii=False, separators=(",", ":"))
    # Python selection is in the sandbox; no shell interpolation of filenames or source.
    arguments = " -c " + shlex.quote(LOOKUP_SOURCE) + " " + shlex.quote(encoded)
    wrapped = 'task_python=$(command -v python3 || command -v python); "$task_python"' + arguments
    if len(wrapped) > 12000 or len(wrapped.encode("utf-8")) > 24000:
        return command, None
    return wrapped, request


def lookup_result(output, request):
    if not request or not output.startswith(MARKER):
        return None
    try:
        value = json.loads(output.split("\n", 1)[0][len(MARKER):])
    except (ValueError, TypeError):
        return None
    if (not isinstance(value, dict) or value.get("nonce") != request["nonce"]
            or value.get("requested") != request["file"]):
        return None
    return value
