"""Reconcile sent builds without allowing a failed wall to disable all towers."""
import re
from collections import Counter

from .validation import ACTIONS
from .world import WEAPONS, pos


KINDS = frozenset(WEAPONS + ("wall",))
KIND_WORDS = {"wall": ("wall", "围墙"), "gatling": ("gatling", "加特林"),
              "railgun": ("railgun", "电磁"), "rocket": ("rocket", "火箭")}


def _word(text, word):
    return re.search(r"(?<![A-Za-z])" + re.escape(word) + r"(?![A-Za-z])", text, re.I) is not None


class ConstructionTracker:
    """One match's per-worker feedback and per-kind construction circuit breakers.

    Explicit instruction rejections disable a kind for the match. Ambiguous
    rejections pause only the kinds still under suspicion, also for the match.
    Ordinary failed cells and failure budgets expire on the next game day.
    """
    def __init__(self):
        self.pending = {}
        self.disabled_kinds = set()
        self.paused_kinds = set()
        self.events = []
        self.stats = Counter()
        self._round = None
        self._observed_round = None
        self._day = None
        self._failures = Counter()
        self._avoided = set()
        self._unconfirmed = Counter()
        self._outcomes = {}
        self._rejections = set()

    def _advance(self, w):
        if self._round is not None and w.round < self._round:
            return False
        if self._round != w.round:
            self._round = w.round
            self.events = []
            self._outcomes = {}
            self._rejections = set()
        if self._day != w.day:
            self._day = w.day
            self._failures.clear()
            self._avoided.clear()
            self._unconfirmed.clear()
        return True

    @staticmethod
    def _present(w, kind, cell):
        return any(role.get("roleType") == kind and pos(role) == cell
                   for role in w.own.values())

    @staticmethod
    def _result(w, rid):
        results = w.raw.get("lastRoundRoleActionResults")
        if not isinstance(results, dict):
            return None
        if rid in results:
            return results[rid]
        try:
            return results.get(int(rid))
        except (TypeError, ValueError):
            return None

    def _event(self, w, event, record=None, **extra):
        record = record or {}
        item = {"event": event, "round": w.round, "role": record.get("role"),
                "kind": record.get("kind"), "pos": record.get("pos")}
        item.update(extra)
        self.events.append(item)
        self.stats[event] += 1

    def observe(self, w):
        if not self._advance(w) or self._observed_round == w.round:
            return
        self._observed_round = w.round
        for rid, record in list(self.pending.items()):
            if record["round"] >= w.round:
                continue
            del self.pending[rid]
            kind, cell = record["kind"], record["pos"]
            consecutive = record["round"] + 1 == w.round
            feedback = self._result(w, rid) if consecutive else None
            present = self._present(w, kind, cell)
            if present and not record["prior_present"]:
                event = "build_success"
                self._unconfirmed.pop((kind, cell), None)
            elif not consecutive:
                event = "build_stale"
            elif feedback is False:
                event = "build_failed"
                self._failures[kind] += 1
                self._avoided.add((kind, cell))
            else:
                # A legal flag is not evidence that a building survived, and a
                # missing flag is not evidence of an illegal instruction.
                event = "build_unconfirmed"
                self._unconfirmed[(kind, cell)] += 1
                if self._unconfirmed[(kind, cell)] >= 2:
                    self._avoided.add((kind, cell))
            self._outcomes[rid] = {"record": record, "event": event}
            self._event(w, event, record, feedback=feedback)

    def record(self, w, commands):
        """Replace provisional entries with this round's final sent commands."""
        self.observe(w)
        if self._round != w.round:
            return
        pending = {}
        for identifier, command in commands.items():
            rid = str(identifier)
            if not isinstance(command, dict) or command.get("action") != "build":
                continue
            kind, targets = command.get("name"), command.get("targetPos")
            if (not isinstance(kind, str) or kind not in KINDS
                    or not isinstance(targets, list) or len(targets) != 1):
                continue
            try:
                cell = pos(targets[0])
            except (KeyError, TypeError, ValueError, IndexError):
                continue
            pending[rid] = {"round": w.round, "role": rid, "kind": kind, "pos": cell,
                            "prior_present": self._present(w, kind, cell)}
        self.pending = pending

    def failures_today(self, kind=None):
        if kind is None:
            return sum(self._failures.values())
        return self._failures[kind] if isinstance(kind, str) else 0

    def available(self, kind, w):
        self.observe(w)
        limit = 4 if kind == "wall" else 12
        return (isinstance(kind, str) and kind in KINDS and kind not in self.disabled_kinds | self.paused_kinds
                and "build" not in getattr(w, "disabled_actions", set())
                and self._failures[kind] < limit)

    def avoided(self, kind, cell, w):
        self.observe(w)
        if not isinstance(kind, str) or kind not in KINDS:
            return True
        return (kind, pos(cell)) in self._avoided

    def reject(self, w, prior_commands, description):
        """Attribute one code-4 error using only the immediately preceding response.

        Descriptions are evidence, never commands. Positive state/legality rules
        out a build; explicit role/action/kind evidence narrows the remaining
        candidates. Conflicting or generic evidence only pauses suspects.
        """
        self.observe(w)
        if self._round != w.round:
            return
        prior = {str(rid): command for rid, command in prior_commands.items()
                 if isinstance(command, dict) and isinstance(command.get("action"), str)}
        text = str(description)[:2048]
        signature = (text, tuple(sorted((rid, command.get("action"), str(command.get("name")),
                                         repr(command.get("targetPos"))) for rid, command in prior.items())))
        if signature in self._rejections:
            return
        self._rejections.add(signature)
        named = {verb for verb in ACTIONS if _word(text, verb)}
        if "建造" in text:
            named.add("build")
        kinds = {kind for kind, words in KIND_WORDS.items() if any(_word(text, word) for word in words)}
        ids = {rid for rid in prior
               if re.search(r"(?<![A-Za-z0-9_])" + re.escape(rid) + r"(?![A-Za-z0-9_])", text)}
        selected = {rid: prior[rid] for rid in ids} if ids else dict(prior)
        contradictory = False
        if named:
            narrowed = {rid: command for rid, command in selected.items() if command["action"] in named}
            if narrowed:
                selected = narrowed
            elif ids:
                # Conflicting labels cannot establish a permanent rejection.
                contradictory = True
                selected.update({rid: command for rid, command in prior.items() if command["action"] in named})
            else:
                return
        if kinds:
            narrowed = {rid: command for rid, command in selected.items()
                        if command["action"] == "build" and isinstance(command.get("name"), str)
                        and command["name"] in kinds}
            if narrowed:
                selected = narrowed
            elif ids or named:
                contradictory = True
            else:
                return
        remaining = {}
        for rid, command in selected.items():
            if self._result(w, rid) is True:
                continue
            if command["action"] == "build":
                outcome = self._outcomes.get(rid)
                if outcome and outcome["event"] == "build_success":
                    continue
                targets = command.get("targetPos")
                if not outcome and isinstance(targets, list) and len(targets) == 1:
                    try:
                        if self._present(w, command.get("name"), pos(targets[0])):
                            continue
                    except (KeyError, TypeError, ValueError, IndexError):
                        pass
            remaining[rid] = command
        suspected = {command.get("name") for command in remaining.values()
                     if command["action"] == "build" and isinstance(command.get("name"), str)
                     and command["name"] in KINDS}
        if not suspected:
            return
        only_builds = all(command["action"] == "build" for command in remaining.values())
        attributed = bool(ids or named or kinds) and only_builds and len(suspected) == 1 and not contradictory
        target = self.disabled_kinds if attributed else self.paused_kinds
        event = "build_disabled" if attributed else "build_paused"
        for kind in sorted(suspected):
            if kind in self.disabled_kinds or kind in target:
                continue
            target.add(kind)
            entries = [(rid, command) for rid, command in remaining.items()
                       if command["action"] == "build" and command.get("name") == kind]
            record = {"kind": kind}
            if len(entries) == 1:
                record["role"] = entries[0][0]
                targets = entries[0][1].get("targetPos")
                if isinstance(targets, list) and len(targets) == 1:
                    try:
                        record["pos"] = pos(targets[0])
                    except (KeyError, TypeError, ValueError, IndexError):
                        pass
            self._event(w, event, record, reason="attributed" if attributed else "unattributed")
