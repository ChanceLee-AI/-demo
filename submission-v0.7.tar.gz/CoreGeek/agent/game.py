"""Deterministic economy and defence. No network or sandbox execution occurs here."""
import itertools
from collections import Counter

from .world import action, dist, pos
from .defense import DefensePlanner, exposure
from .economy import EconomyPlanner
from .construction import ConstructionTracker
from .fortification import FortificationPlanner
from .layout import FortLayout
from .medical import MedicalPlanner


MINERALS = ("stone", "iron", "copper")
WEAPONS = ("railgun", "rocket", "gatling")
BUILD_ORDER = ("gatling", "railgun", "rocket")


def level(unit):
    try:
        return max(1, min(3, int(str(unit.get("level", 1)).replace("level", ""))))
    except (ValueError, TypeError):
        return 1


def ray_cells(start, end):
    """Cells crossed by the centre-to-centre segment, excluding the origin.

    A line merely touching a cell corner does not enter that cell. Keeping this
    discretisation isolated makes it easy to adapt to a judge's ray convention.
    """
    x, y = pos(start)
    ex, ey = pos(end)
    dx, dy = ex - x, ey - y
    sx, sy = (1 if dx > 0 else -1), (1 if dy > 0 else -1)
    tx = 0.5 / abs(dx) if dx else float("inf")
    ty = 0.5 / abs(dy) if dy else float("inf")
    ix = 1.0 / abs(dx) if dx else float("inf")
    iy = 1.0 / abs(dy) if dy else float("inf")
    cells = []
    while (x, y) != (ex, ey):
        if abs(tx - ty) < 1e-10:
            x, y, tx, ty = x + sx, y + sy, tx + ix, ty + iy
        elif tx < ty:
            x, tx = x + sx, tx + ix
        else:
            y, ty = y + sy, ty + iy
        cells.append((x, y))
    return cells


def same_cone(origin, targets):
    """Every pair of gatling directions must form an angle of at most 90 deg."""
    ox, oy = pos(origin)
    vectors = [(x - ox, y - oy) for x, y in targets]
    return all(ax * bx + ay * by >= 0
               for (ax, ay), (bx, by) in itertools.combinations(vectors, 2))


def _used(commands):
    return set(str(k) for k in commands) | {
        str(c["controllerId"]) for c in commands.values() if c.get("controllerId") is not None
    }


class GameAgent:
    def __init__(self):
        self.build_pending = None
        self.build_invalid = {kind: set() for kind in WEAPONS + ("wall",)}
        self.build_success = []
        self.build_disabled = False
        self.build_day = None
        self.build_failures = 0
        self.build_goal = None
        self.upgrade_plan = None
        self.last_shot = {}
        self.market_advice = {}
        self.held_roles = set()
        self.stats = Counter()
        self.last_moves = {}
        self.move_failures = {}
        self.move_avoid = {}
        self.yield_goals = {}
        self.observed_round = None
        self.defense = DefensePlanner()
        self.economy = EconomyPlanner()
        self.construction = ConstructionTracker()
        self.layout = FortLayout()
        self.fortification = FortificationPlanner()
        self.construction_observed_round = None
        self.economy_context = self.economy.context
        self.medical = MedicalPlanner()

    def record_actions(self, w, commands):
        """Record only sent moves; Engine can overwrite provisional module output."""
        self.economy.record(w, commands)
        self.construction.record(w, commands)
        self.build_pending = next((dict(pending) for pending in self.construction.pending.values()
                                   if pending["kind"] != "wall"), None)
        self.last_moves = {}
        for rid, command in commands.items():
            role = w.own.get(str(rid))
            if role and command.get("action") == "move" and command.get("targetPos"):
                self.last_moves[str(rid)] = (w.round, pos(role), pos(command["targetPos"][0]))

    def prepare_world(self, w):
        """Process real action feedback once and share temporary reroutes with tasks."""
        if self.observed_round != w.round:
            self.observed_round = w.round
            results = w.raw.get("lastRoundRoleActionResults") or {}
            for rid, (previous_round, start, target) in self.last_moves.items():
                role = w.own.get(rid)
                key = (start, target)
                old_key, failures = self.move_failures.get(rid, (None, 0))
                failed = (previous_round + 1 == w.round and role and pos(role) == start
                          and results.get(rid, results.get(role["id"])) is False)
                if failed:
                    failures = failures + 1 if old_key == key else 1
                    self.move_failures[rid] = (key, failures)
                    if failures >= 2:
                        self.move_avoid.setdefault(rid, {})[target] = w.round + 4
                        self.stats["move_reroutes"] += 1
                else:
                    self.move_failures.pop(rid, None)
            for rid in list(self.move_failures):
                if rid not in self.last_moves:
                    self.move_failures.pop(rid, None)
        w.move_avoid = {rid: {cell for cell, until in cells.items() if until > w.round}
                        for rid, cells in self.move_avoid.items()}
        self.yield_goals = {rid: plan for rid, plan in self.yield_goals.items()
                            if rid in w.own and not w.night and plan["day"] == w.day and plan["until"] > w.round}
        self.construction.observe(w)
        self._observe(w)
        self.layout.prepare(w)
        self.defense.prepare(w)
        self.economy.observe(w)
        self.fortification.reserve(w, self.construction)
        self.economy_context = self.economy.context
        w.economy_context = self.economy_context
        reserve = max(0, 3 - len(w.weapons)) * 25
        if w.station and level(w.station) == 1:
            all_roles = (w.raw.get("teamOur") or {}).get("roles", [])
            held = any("StationUpgradeVoucher1" in (role.get("backpack") or [])
                       for role in all_roles if isinstance(role, dict))
            if not held:
                reserve += w.shop.get("StationUpgradeVoucher1", 100)
        w.defense_reserve = reserve
        self.medical.prepare(w)
        # Tasks run before Game.step; share the already calculated emergency
        # voucher protection without counting the ordinary base reserve twice.
        w.defense_reserve = max(reserve, self.medical.context.get("cash_guard", 0))

    def step(self, w, commands, deadline=None):
        """Add actions, preserving actions and controllers already assigned by tasks."""
        self.prepare_world(w)
        self.held_roles = {str(rid) for rid in getattr(w, "held_roles", set())}
        if w.expired():
            return
        budget = w.gold
        for c in commands.values():
            if c.get("action") == "buy":
                budget -= w.shop.get(c.get("name"), 0) * c.get("num", 1)
            elif c.get("action") == "build" and c.get("name") in WEAPONS:
                budget -= 25
        budget = max(0, budget)
        if w.night:
            for worker in w.workers:
                self.economy.note(worker["id"], "defense", "night")
            self._emergency_base_upgrade(w, commands)
            self.medical.use_owned(w, commands, self.held_roles)
            self._defend(w, commands)
            self._yield_idle(w, commands)
            self.record_actions(w, commands)
            return
        self._emergency_base_upgrade(w, commands, emergency_only=False)
        self.medical.use_owned(w, commands, self.held_roles)
        # Return decisions precede new journeys, so economic work cannot strand a gunner.
        returning = []
        for person in w.people:
            if str(person["id"]) in _used(commands) | self.held_roles:
                continue
            home = w.plan_return_route(person, person)
            if home.distance is not None and w.daylight_left <= home.total_distance + w.return_margin:
                returning.append(person)
                self.economy.note(person["id"], "return", "return_deadline", home_turns=home.total_distance)
        self._defend(w, commands, returning)
        used = _used(commands) | self.held_roles | {str(p["id"]) for p in returning}
        available = [p for p in w.workers if str(p["id"]) not in used]
        # Replace missing weapons first. Existing guns are never overwritten to
        # change their kind; the three-slot baseline applies to new construction.
        if available and len(w.weapons) < 3 and not w.expired():
            builder = next((p for p in available if self.build_goal and str(p["id"]) == self.build_goal[0]), None)
            builder = builder or min(available, key=lambda p: dist(p, w.station) if w.station else 0)
            spent = self._build(w, commands, builder, budget)
            budget -= max(0, spent)
            if str(builder["id"]) in commands:
                self.economy.note(builder["id"], "build", "initial_defenses")
                available = [p for p in available if p is not builder]
        medical_used, medical_spent = self.medical.purchase(
            w, commands, budget, self.held_roles | {str(p["id"]) for p in returning}, self._put_move)
        budget -= medical_spent
        for rid in medical_used:
            self.economy.note(rid, "medical", "funded_self_purchase",
                              medical_turns=self.medical.plan["turns"])
        available = [p for p in available if str(p["id"]) not in medical_used]
        # Once all guns are observed, both workers prioritize the perimeter.
        # Only workers with feasible wall work are claimed; the rest can trade.
        if len(w.weapons) >= 3 and available and not w.expired():
            wall_workers = self.fortification.step(w, commands, available, self.economy,
                                                  self.construction, self._put_move, self._mine_closed)
            available = [p for p in available if str(p["id"]) not in wall_workers]
        upgrader = None
        if available and not w.expired():
            upgrader, spent = self._upgrade(w, commands, available, budget)
            budget -= spent
            if upgrader is not None:
                available = [p for p in available if str(p["id"]) != upgrader]
        # The two workers share inventory, deadlines and the estimated yield of
        # each visible mine. An in-flight purchase has already reserved its cash.
        goal = None if upgrader is not None else self._economic_goal(w, budget)
        self.economy.step(w, commands, available, budget, goal, self._mine_closed, self._put_move, self._defend)
        # A task-free pioneer waits near the defences rather than obstructing trade.
        if w.pioneer and str(w.pioneer["id"]) not in _used(commands) | self.held_roles | medical_used:
            self._defend(w, commands, [w.pioneer])
        self._yield_idle(w, commands)
        self.record_actions(w, commands)

    def _yield_idle(self, w, commands):
        """Clear requested transit cells only with actors that have no useful action."""
        if "move" in getattr(w, "disabled_actions", set()):
            return
        used = _used(commands) | self.held_roles
        destinations = {pos(p) for c in commands.values() if c.get("action") in ("move", "build")
                        for p in c.get("targetPos", [])}
        by_cell = {pos(p): p for p in w.people}
        for requester, route in getattr(w, "blocked_routes", []):
            if w.expired():
                break
            if requester in used:
                continue
            for cell in route:
                blocker = by_cell.get(cell)
                if not blocker or str(blocker["id"]) == requester:
                    continue
                rid = str(blocker["id"])
                if rid in used:
                    continue
                avoided = set(w.move_avoid.get(rid, set()))
                options = [p for p in w.neighbors(cell) if p not in w.occupied | destinations | avoided | set(route)]
                if w.night:
                    controlled = [g for g in w.weapons if w.near(blocker, g)]
                    if controlled:
                        options = [p for p in options if any(w.near(p, g) for g in controlled)]
                yield_plan, travel = None, 1
                if not options:
                    if w.night:
                        continue
                    # A narrow completed perimeter can require stepping along
                    # the requested corridor before reaching a passing place.
                    # Only idle daytime actors may make this bounded detour.
                    x, y = cell
                    passing = {(xx, yy) for xx in range(x - 3, x + 4) for yy in range(y - 3, y + 4)
                               if w.in_bounds((xx, yy)) and (xx, yy) not in w.occupied | destinations | avoided | set(route)}
                    detour = w.route(blocker, passing, reserved=destinations | avoided)
                    if not detour.steps or len(detour.steps) > 3:
                        continue
                    target = detour.steps[0]
                    travel = len(detour.steps) + 2  # includes the passing-place hold
                    yield_plan = {"goal": detour.goal, "day": w.day,
                                  "until": w.round + 6, "arrived": None}
                else:
                    target = min(options, key=lambda p: (dist(p, w.station) if w.station else 0, p))
                if not w.night:
                    home = w.plan_return_route(blocker, yield_plan["goal"] if yield_plan else target)
                    if not home.reachable or travel + home.total_distance + w.return_margin > w.daylight_left:
                        continue
                if yield_plan:
                    self.yield_goals[rid] = yield_plan
                commands[rid] = action("move", target)
                used.add(rid)
                destinations.add(target)
                self.stats["yield_moves"] += 1
                break

    def _observe(self, w):
        """Legacy diagnostic fields mirror the shared tracker, never count twice."""
        self.construction.observe(w)
        if self.construction_observed_round == w.round:
            return
        self.construction_observed_round = w.round
        self.build_day = w.day
        self.build_failures = self.construction.failures_today()
        self.build_disabled = all(kind in self.construction.disabled_kinds for kind in BUILD_ORDER)
        for event in self.construction.events:
            if event.get("event") == "build_success":
                self.build_success.append(tuple(event["pos"]))
            if event.get("kind") != "wall" and event.get("event") in ("build_success", "build_failed", "build_stale"):
                self.build_goal = None
        for key in ("build_success", "build_failed"):
            self.stats[key] = self.construction.stats[key]
        self.build_pending = next((dict(pending) for pending in self.construction.pending.values()
                                   if pending["kind"] != "wall"), None)

    def _put_move(self, w, commands, role, goals):
        command = w.move_toward(role, goals, commands)
        if command:
            commands[str(role["id"])] = command
            return True
        return False

    def _build(self, w, commands, worker, budget):
        if ("build" in getattr(w, "disabled_actions", set())
                or not w.station or self.build_pending or w.daylight_left < 6):
            return 0
        counts = Counter(p.get("roleType") for p in w.weapons)
        desired = Counter(BUILD_ORDER)
        kind = next((k for k in BUILD_ORDER if counts[k] < desired[k]
                     and self.construction.available(k, w)), None)
        if len(w.weapons) >= 3:
            kind = None
        if kind and budget < 25:
            return 0
        if not kind:
            return 0
        goal = self.build_goal
        if (not goal or goal[0] != str(worker["id"]) or goal[1] != kind
                or goal[2] in w.occupied or self.construction.avoided(kind, goal[2], w)):
            goal = None
            candidates = self._build_candidates(w, worker, kind)
            for candidate in candidates:
                if w.expired():
                    break
                goals = w.adjacent({"pos": {"x": candidate[0], "y": candidate[1]}})
                route = w.route(worker, goals)
                home = w.return_route(route.goal, ignore_people={str(worker["id"])}) if route.reachable else None
                if home and home.reachable and route.distance + home.distance + w.return_margin + 1 <= w.daylight_left:
                    goal = (str(worker["id"]), kind, candidate)
                    break
            self.build_goal = goal
        if not goal:
            return 0
        candidate = goal[2]
        if dist(worker, candidate) <= 1:
            commands[str(worker["id"])] = action("build", candidate, name=kind)
            return 25
        self._put_move(w, commands, worker, w.adjacent(candidate))
        return 0

    def _build_candidates(self, w, worker, kind):
        if not w.station:
            return []
        if kind == "wall":
            cells = self.layout.targets
            preferred = None
        else:
            cells = self.layout.weapon_sites(w)
            ring = sorted(self.layout.ring(w, 1))
            index = BUILD_ORDER.index(kind)
            preferred = ring[index] if len(ring) > index else None
        candidates = [cell for cell in cells if cell not in w.occupied
                      and not self.construction.avoided(kind, cell, w)]
        if kind != "wall":
            checked = []
            for cell in candidates:
                proposal = {"roleType": kind, "pos": {"x": cell[0], "y": cell[1]}}
                matched = self._has_inner_control_slots(w, w.weapons + [proposal], {cell})
                connected = self.layout.prospective_weapon_safe(w, cell)
                if matched and connected:
                    checked.append(cell)
                elif cell == preferred:
                    getattr(w, "wall_work", {})["weapon_site_fallback"] = {
                        "kind": kind, "preferred": list(cell),
                        "reason": "no_distinct_inner_controls" if not matched else "inner_controls_disconnected"}
                    self.stats["weapon_site_fallback"] += 1
            candidates = checked
        return sorted(candidates, key=lambda cell: (cell != preferred, cell))

    @staticmethod
    def _has_inner_control_slots(w, guns, extra_occupied=()):
        """A complete ring needs one different inner control cell per gun."""
        inner = set(FortLayout.ring(w, 1)) - w.static - set(extra_occupied)
        choices = sorted([{cell for cell in inner if dist(cell, gun) <= 1} for gun in guns], key=len)
        def match(index, used):
            if index == len(choices):
                return True
            return any(match(index + 1, used | {cell}) for cell in choices[index] - used)
        return match(0, set())

    def _wall_keeps_paths(self, w, candidate):
        self.layout.prepare(w)
        return self.layout.safe(w, {candidate})

    def _upgrade_candidates(self, w):
        station = w.station
        weapons = sorted([p for p in w.weapons if level(p) < 3],
                         key=lambda p: (level(p), p.get("roleType") != "rocket", str(p["id"])))
        candidates = []
        if station and level(station) < 3:
            max_health = 1500 * level(station)
            if station.get("health", max_health) < max_health / 2:
                candidates.append(station)
        if station and level(station) == 1:
            candidates.append(station)
        candidates += [p for p in weapons if level(p) == 1]
        candidates += [p for p in weapons if level(p) == 2]
        if station and level(station) == 2:
            candidates.append(station)
        seen = set()
        unique = []
        for target in candidates:
            if str(target["id"]) not in seen:
                seen.add(str(target["id"]))
                prefix = "Station" if target.get("roleType") == "station" else "Weapon"
                unique.append((target, prefix + "UpgradeVoucher" + str(level(target))))
        return unique

    def _emergency_base_upgrade(self, w, commands, emergency_only=True):
        station = w.station
        if (not station or level(station) >= 3 or "use" in getattr(w, "disabled_actions", set())
                or (emergency_only or level(station) != 1)
                and station.get("health", 1500 * level(station)) >= 750 * level(station)):
            return
        name = "StationUpgradeVoucher" + str(level(station))
        available = [person for person in w.people
                     if str(person["id"]) not in _used(commands) | self.held_roles
                     and name in person.get("backpack", []) and w.near(person, station)]
        if available:
            carrier = min(available, key=lambda person: (exposure(w, pos(person)), str(person["id"])))
            commands[str(carrier["id"])] = action("use", pos(station), name=name)
            self.stats["emergency_base_upgrades"] += 1

    def _upgrade(self, w, commands, workers, budget):
        disabled = getattr(w, "disabled_actions", set())
        if "use" in disabled:
            self.upgrade_plan = None
            return None, 0
        candidates = self._upgrade_candidates(w)
        status = self.economy_context.setdefault("upgrade", {})
        # Existing vouchers take precedence, including those retained after a death.
        for target, name in candidates:
            carriers = [p for p in workers if name in p.get("backpack", [])]
            for carrier in sorted(carriers, key=lambda p: dist(p, target)):
                outbound = w.plan_route(carrier, carrier, w.adjacent(target))
                if not outbound.reachable:
                    self._put_move(w, commands, carrier, w.adjacent(target))
                    continue
                home = w.plan_return_route(carrier, outbound.goal)
                if not home.reachable or outbound.total_distance + home.total_distance + 1 + w.return_margin > w.daylight_left:
                    continue
                if w.near(carrier, target):
                    commands[str(carrier["id"])] = action("use", pos(target), name=name)
                else:
                    if not self._put_move(w, commands, carrier, w.adjacent(target)):
                        continue
                self.upgrade_plan = None
                self.economy.note(carrier["id"], "upgrade", "use_owned_voucher", home_turns=home.total_distance,
                                  upgrade_turns=outbound.total_distance + home.total_distance + 1)
                status.update(target_id=str(target["id"]), voucher=name, reason="owned_voucher",
                              worker_id=str(carrier["id"]))
                return str(carrier["id"]), 0
        if "buy" in disabled:
            self.upgrade_plan = None
            return None, 0
        # Reserve the first three guns' construction cost unless the base is critical.
        critical = (w.station and w.station.get("health", 1500) < 750 * level(w.station))
        reserve = 0 if critical else max(0, 3 - len(w.weapons)) * 25
        old_plan, self.upgrade_plan = self.upgrade_plan, None
        all_roles = (w.raw.get("teamOur") or {}).get("roles", [])
        for target, name in candidates:
            if w.expired():
                break
            price = w.shop.get(name, 100 if level(target) == 1 else 150)
            if any(name in (p.get("backpack") or []) for p in all_roles if isinstance(p, dict)):
                continue
            if price > budget - reserve:
                status.update(target_id=str(target["id"]), voucher=name, price=price, reserve=reserve,
                              cash_gap=max(0, price + reserve - budget), reason="insufficient_observed_cash")
                return None, 0
            feasible = []
            for worker in workers:
                if len(worker.get("backpack", [])) >= worker.get("backPackCapability", 100):
                    continue
                trip = self.economy.upgrade_trip(w, worker, worker, target)
                if trip and trip["turns"] + w.return_margin <= w.daylight_left:
                    candidate = (str(worker["id"]), str(target["id"]), name)
                    feasible.append((candidate != old_plan, trip["turns"], str(worker["id"]), worker, trip))
            if not feasible:
                status.update(target_id=str(target["id"]), voucher=name, price=price,
                              reserve=reserve, cash_gap=0, reason="upgrade_route_or_time")
                return None, 0
            _, _, rid, role, trip = min(feasible, key=lambda choice: choice[:3])
            self.upgrade_plan = (rid, str(target["id"]), name)
            if w.near(role, trip["shop"]):
                commands[rid] = action("buy", name=name, num=1)
            elif not self._put_move(w, commands, role, w.adjacent(trip["shop"])):
                self.upgrade_plan = None
                continue
            self.economy.note(rid, "upgrade", "buy_with_observed_cash", upgrade_turns=trip["turns"],
                              home_turns=trip["home_turns"])
            status.update(target_id=str(target["id"]), voucher=name, price=price, reserve=reserve,
                          cash_gap=0, reason="funded_in_transit", worker_id=rid, trip_turns=trip["turns"])
            return rid, price
        return None, 0

    def _economic_goal(self, w, budget):
        disabled = getattr(w, "disabled_actions", set())
        if "buy" in disabled or "use" in disabled:
            return None
        all_roles = (w.raw.get("teamOur") or {}).get("roles", [])
        critical = w.station and w.station.get("health", 1500) < 750 * level(w.station)
        reserve = 0 if critical else 25 * max(0, 3 - len(w.weapons))
        for target, name in self._upgrade_candidates(w):
            if any(name in (p.get("backpack") or []) for p in all_roles if isinstance(p, dict)):
                continue
            return {"target": target, "name": name, "price": w.shop.get(name, 100 if level(target) == 1 else 150),
                    "reserve": reserve}
        return None

    def _economy(self, w, commands, worker):
        # Kept for direct callers; normal step plans both workers together.
        self.economy.observe(w)
        self.economy_context = self.economy.context
        self.economy.step(w, commands, [worker], w.gold, self._economic_goal(w, w.gold),
                          self._mine_closed, self._put_move, self._defend)

    def _mine_closed(self, mineral, day):
        if isinstance(self.market_advice, list):
            forecasts = [f for f in self.market_advice if isinstance(f, dict) and f.get("mineral") == mineral]
        elif isinstance(self.market_advice, dict):
            forecasts = self.market_advice.get(mineral, {})
            if isinstance(forecasts, dict):
                forecasts = [forecasts]
        else:
            forecasts = []
        for forecast in forecasts:
            if not isinstance(forecast, dict):
                continue
            if day in forecast.get("unavailable_days", []):
                return True
            try:
                first, last = int(forecast.get("from_day", 1)), int(forecast.get("to_day", 10))
                if forecast.get("collectible") is False and first <= day <= last:
                    return True
            except (TypeError, ValueError):
                continue
        return False

    def _continue_yield(self, w, person, commands):
        """Finish an idle daytime detour before returning to the obstructing slot."""
        rid = str(person["id"])
        plan = self.yield_goals.get(rid)
        if not plan:
            return False
        home = w.return_route(person)
        if (w.night or plan["day"] != w.day or w.round >= plan["until"]
                or home.distance is not None and w.daylight_left <= home.distance + w.return_margin):
            self.yield_goals.pop(rid, None)
            return False
        if pos(person) == plan["goal"]:
            if plan["arrived"] is None:
                plan["arrived"] = w.round
            if w.round < plan["arrived"] + 2:
                return True
            self.yield_goals.pop(rid, None)
            return False
        if self._put_move(w, commands, person, {plan["goal"]}):
            return True
        self.yield_goals.pop(rid, None)
        return False

    def _defend(self, w, commands, selected=None):
        if not hasattr(w, "defense_status"):
            w.defense_status = {}
        used = _used(commands) | self.held_roles
        people = [p for p in w.people if str(p["id"]) not in used]
        if selected is not None:
            allowed = {str(p["id"]) for p in selected}
            people = [p for p in people if str(p["id"]) in allowed]
        guns = {str(g["id"]): g for g in w.weapons if str(g["id"]) not in commands}
        pairs = []
        unmatched = []
        for person in people:
            if self._continue_yield(w, person, commands):
                continue
            assignment = w.defense_assignments.get(str(person["id"]))
            gun = guns.get(assignment["weapon_id"]) if assignment else None
            if gun:
                pairs.append((person, gun, assignment["pos"]))
            else:
                unmatched.append(person)
        health = {str(r["id"]): max(0, r.get("health", 1)) for r in w.robots}
        pairs.sort(key=lambda pair: pair[1].get("roleType") == "rocket")
        for person, gun, stand in pairs:
            rid, gid = str(person["id"]), str(gun["id"])
            # The planner locks working operators. Only an explicit return or
            # danger migration can spend their role action instead of firing.
            held = rid in getattr(w, "defense_holds", set())
            reason = getattr(w, "defense_move_reasons", {}).get(rid)
            moving = not held and pos(person) != stand and (not w.night or reason is not None)
            if moving:
                if self._put_move(w, commands, person, {stand}):
                    w.defense_status[gid] = reason or "return"
                    continue
                w.defense_status[gid] = "move_blocked"
            if w.near(person, gun):
                if w.night and "attack" not in getattr(w, "disabled_actions", set()):
                    targets, damage = self._aim(w, gun, health)
                    if targets:
                        commands[gid] = {"action": "attack", "controllerId": rid,
                                         "targetPos": [{"x": x, "y": y} for x, y in targets]}
                        self.last_shot[gid] = w.round
                        self.stats["attacks"] += 1
                        w.defense_status[gid] = "attack_sent"
                        for robot_id, amount in damage.items():
                            health[robot_id] = max(0, health.get(robot_id, 0) - amount)
                    else:
                        w.defense_status[gid] = "no_effective_target"
                elif w.night:
                    w.defense_status[gid] = "attack_disabled"
        for person in unmatched:
            refuge = w.defense_refuges.get(str(person["id"]))
            if refuge is not None:
                if pos(person) != refuge:
                    self._put_move(w, commands, person, {refuge})
                continue
            if w.station:
                if guns:
                    # Register a genuine blocked transit request for idle yielding.
                    closest = min(guns.values(), key=lambda g: dist(person, g))
                    self._put_move(w, commands, person, w.adjacent(closest))
                    if str(person["id"]) in commands:
                        continue
                self._put_move(w, commands, person, w.adjacent(w.station))

    def _aim(self, w, gun, predicted):
        kind, lvl, gid = gun.get("roleType"), level(gun), str(gun["id"])
        if gun.get("cooldown", 0) > 0:
            return [], {}
        if kind == "rocket" and "cooldown" not in gun and w.round - self.last_shot.get(gid, -100) <= 3:
            return [], {}
        default_range = {"railgun": (6, 8, 10), "gatling": (3, 5, 7), "rocket": (10, 15, 1000)}
        reach = gun.get("attackRange", default_range[kind][lvl - 1])
        power = gun.get("attackPower", 10 * lvl if kind == "railgun" else 20 if kind == "rocket" else 10)
        if power <= 0 or reach <= 0:
            return [], {}
        robots_by_pos = {pos(r): r for r in w.robots}
        weights = {}
        for robot in w.robots:
            base_distance = min((dist(robot, c) for c in w.footprint(w.station)), default=20) if w.station else 20
            near_person = min((dist(robot, p) for p in w.people), default=20)
            weight = 1 + 8.0 / (base_distance + 1) + 2.0 / (near_person + 1)
            if robot.get("targetTeam") and robot["targetTeam"] != w.team_type:
                weight *= 0.25
            if robot.get("abnormalState") == "dizzy":
                weight *= 0.8
            weights[str(robot["id"])] = weight
        def value(damage, hp):
            total = 0.0
            for rid, amount in damage.items():
                remaining = hp.get(rid, 0)
                total += min(remaining, amount) * weights.get(rid, 1)
                if remaining > 0 and amount >= remaining:
                    total += 10 * weights.get(rid, 1)
            return total
        if kind == "rocket":
            candidates = set()
            for robot in w.robots:
                x, y = pos(robot)
                for dx in (-1, 0, 1):
                    for dy in (-1, 0, 1):
                        cell = x + dx, y + dy
                        if 0 <= cell[0] < w.width and 0 <= cell[1] < w.height and dist(gun, cell) <= reach:
                            candidates.add(cell)
            effects = {}
            for cell in sorted(candidates):
                damage = {}
                x, y = cell
                for dx in (-1, 0, 1):
                    for dy in (-1, 0, 1):
                        robot = robots_by_pos.get((x + dx, y + dy))
                        if robot:
                            damage[str(robot["id"])] = power if dx == dy == 0 else power / 2
                effects[cell] = damage
            chosen, combined, hp = [], Counter(), dict(predicted)
            for _ in range(lvl):
                if not effects or w.expired():
                    break
                target = max(effects, key=lambda c: value(effects[c], hp))
                if value(effects[target], hp) <= 0 and not chosen:
                    return [], {}
                chosen.append(target)
                combined.update(effects[target])
                for rid, amount in effects[target].items():
                    hp[rid] = max(0, hp.get(rid, 0) - amount)
            # The protocol requires one target per level; padding is a legal overlap.
            while chosen and len(chosen) < lvl:
                chosen.append(chosen[-1])
                combined.update(effects[chosen[-1]])
            return chosen, dict(combined)
        effects = {}
        for robot in w.robots:
            target = pos(robot)
            if dist(gun, target) > reach:
                continue
            damage, energy = {}, power
            for cell in ray_cells(pos(gun), target):
                hit = robots_by_pos.get(cell)
                if hit:
                    rid = str(hit["id"])
                    amount = min(energy, hit.get("health", 1)) if kind == "railgun" else power
                    damage[rid] = amount
                    energy -= amount
                    if kind == "gatling" or energy <= 0:
                        break
            effects[target] = damage
        if not effects:
            return [], {}
        if kind == "railgun":
            target = max(effects, key=lambda c: value(effects[c], predicted))
            return ([target], effects[target]) if value(effects[target], predicted) > 0 else ([], {})
        chosen, combined, hp = [], Counter(), dict(predicted)
        for _ in range(lvl):
            eligible = [c for c in effects if same_cone(gun, chosen + [c])]
            if not eligible:
                break
            target = max(eligible, key=lambda c: value(effects[c], hp))
            if not chosen and value(effects[target], hp) <= 0:
                return [], {}
            chosen.append(target)
            combined.update(effects[target])
            for rid, amount in effects[target].items():
                hp[rid] = max(0, hp.get(rid, 0) - amount)
        return chosen, dict(combined)
