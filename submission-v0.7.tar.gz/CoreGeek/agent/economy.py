"""Two-worker, observation-based income plans; forecasts never become spendable gold."""
import itertools
from collections import Counter

from .world import action, dist, pos


MINERALS = ("stone", "iron", "copper")


def _reservation(mapping, key):
    try:
        return max(0, int((mapping or {}).get(key, 0)))
    except (TypeError, ValueError, OverflowError):
        return 0


def sellable_inventory(w, worker):
    """Observed mineral stock less this worker's reserved construction stone."""
    backpack = Counter(worker.get("backpack") or [])
    stock = Counter({kind: backpack[kind] for kind in MINERALS if backpack[kind]})
    reserved = _reservation(getattr(w, "reserved_stone", {}), str(worker["id"]))
    stock["stone"] = max(0, stock["stone"] - reserved)
    return stock


def mine_key(zone):
    return (zone["neutralType"],) + pos(zone)


class EconomyPlanner:
    def __init__(self):
        self.last_round = None
        self.last_gold = None
        self.pending = {}
        self.mines = {}
        self.blocked_until = {}
        self.plans = {}
        self.context = {}
        self.progress = {}
        self.stalled = {}
        self.avoid_stands = {}

    def observe(self, w):
        if self.last_round == w.round:
            return
        visible = {mine_key(z) for z in w.zones if z.get("neutralType") in MINERALS}
        # Ten is an initial upper estimate, not knowledge of other miners' work.
        self.mines = {key: self.mines.get(key, 10) for key in visible}
        self.blocked_until = {key: until for key, until in self.blocked_until.items()
                              if key in visible and until > w.round}
        events = []
        for worker in w.workers:
            rid = str(worker["id"])
            before = self.progress.get(rid)
            marker = (pos(worker), tuple(sorted(Counter(worker.get("backpack") or []).items())))
            plan = self.plans.get(rid, {})
            travelling = plan.get("stand") is not None and pos(worker) != plan["stand"]
            unchanged = before and before[0] + 1 == w.round and before[1] == marker
            self.stalled[rid] = self.stalled.get(rid, 0) + 1 if travelling and unchanged else 0
            if self.stalled[rid] >= 3:
                old_stand = plan.pop("stand", None)
                if old_stand is not None:
                    self.avoid_stands[rid] = (old_stand, w.round + 4)
                    events.append({"event": "economic_route_reselect", "role_id": rid,
                                   "blocked_stand": list(old_stand), "stalled_rounds": self.stalled[rid]})
                self.stalled[rid] = 0
            self.progress[rid] = (w.round, marker)
        alive = {str(worker["id"]) for worker in w.workers}
        self.progress = {rid: value for rid, value in self.progress.items() if rid in alive}
        self.stalled = {rid: value for rid, value in self.stalled.items() if rid in alive}
        self.avoid_stands = {rid: value for rid, value in self.avoid_stands.items()
                             if rid in alive and value[1] > w.round}
        results = w.raw.get("lastRoundRoleActionResults") or {}
        results = {str(k): value for k, value in results.items()} if isinstance(results, dict) else {}
        for rid, previous in self.pending.items():
            if previous["round"] + 1 != w.round:
                continue
            role = w.own.get(rid)
            if not role:
                self.plans.pop(rid, None)
                continue
            stock = Counter(role.get("backpack", []))
            delta = {kind: stock[kind] - previous["stock"].get(kind, 0)
                     for kind in MINERALS if stock[kind] != previous["stock"].get(kind, 0)}
            verb = previous["action"]
            if verb in ("collect", "sell", "buy", "use"):
                event = {"role_id": rid, "action": verb, "feedback": results.get(rid), "stock_delta": delta}
                if previous.get("name"):
                    event["name"] = previous["name"]
                events.append(event)
            if verb == "collect":
                key = previous["mine"]
                gained = max(0, delta.get(key[0], 0))
                if key in self.mines:
                    self.mines[key] = max(0, self.mines[key] - gained)
                plan = self.plans.get(rid)
                if gained:
                    if plan and plan.get("mine") == key:
                        plan["remaining"] = max(0, plan["remaining"] - gained)
                else:
                    # No inventory gain is enough to stop repeating this collect;
                    # it is not proof that the mine was depleted or permanently closed.
                    self.blocked_until[key] = w.round + 5
                    self.plans.pop(rid, None)
            elif verb == "sell" and not any(stock[kind] for kind in MINERALS):
                self.plans.pop(rid, None)
        self.plans = {rid: plan for rid, plan in self.plans.items()
                      if rid in w.own and (plan.get("mine") is None or
                                          plan["mine"] in visible and self.mines[plan["mine"]] > 0)}
        self.context = {
            "round": w.round, "gold": w.gold,
            "gold_delta": None if self.last_gold is None else w.gold - self.last_gold,
            "prices": dict(w.prices), "daylight_left": w.daylight_left,
            "upgrade": {}, "events": events, "workers": {},
            "mine_estimates": [{"kind": key[0], "pos": list(key[1:]), "remaining_estimate": count}
                               for key, count in sorted(self.mines.items())],
        }
        for role in w.workers:
            stock = Counter(role.get("backpack", []))
            self.context["workers"][str(role["id"])] = {
                "pos": list(pos(role)), "stock": {key: value for key, value in stock.items() if value},
                "inventory_value": sum(stock[k] * w.prices.get(k, 0) for k in MINERALS),
                "mode": "unassigned", "reason": "not_scheduled",
            }
        self.last_round, self.last_gold = w.round, w.gold
        self.refresh_inventory(w)

    def refresh_inventory(self, w):
        """Reservations may be published after observe; read them at use time."""
        for role in w.workers:
            row = self.context.get("workers", {}).get(str(role["id"]))
            if row is not None:
                stock = Counter(role.get("backpack") or [])
                sellable = sellable_inventory(w, role)
                row["reserved_stone"] = stock["stone"] - sellable["stone"]
                row["sellable_value"] = sum(sellable[k] * w.prices.get(k, 0) for k in MINERALS)

    def note(self, rid, mode, reason, **details):
        row = self.context.get("workers", {}).get(str(rid))
        if row is not None:
            row.update(mode=mode, reason=reason, **details)

    def record(self, w, commands):
        """Replace provisional actions with the actual validated response when called again."""
        self.refresh_inventory(w)
        self.pending = {}
        for row in self.context.get("workers", {}).values():
            row.pop("action", None)
            row.pop("target", None)
        zones = {pos(z): z for z in w.zones if z.get("neutralType") in MINERALS}
        for rid, command in commands.items():
            role = w.own.get(str(rid))
            if not role or role.get("roleType") != "worker":
                continue
            verb = command.get("action")
            record = {"round": w.round, "action": verb, "stock": dict(Counter(role.get("backpack", []))),
                      "name": command.get("name")}
            if verb == "collect":
                targets = command.get("targetPos") or []
                zone = zones.get(pos(targets[0])) if targets else None
                if not zone:
                    continue
                record["mine"] = mine_key(zone)
            self.pending[str(rid)] = record
            row = self.context.get("workers", {}).get(str(rid))
            if row is not None:
                row["action"] = verb
                if command.get("targetPos"):
                    row["target"] = [list(pos(p)) for p in command["targetPos"]]

    @staticmethod
    def upgrade_trip(w, worker, start, target):
        """Actual path lengths for shop, building and the worker's own control cell."""
        rid = str(worker["id"])
        choices = []
        shops = sorted((z for z in w.zones if z.get("neutralType") == "weaponShop"),
                       key=lambda z: (dist(start, z), pos(z)))[:2]
        for shop in shops:
            if w.expired():
                break
            outbound = w.plan_route(worker, start, w.adjacent(shop))
            if not outbound.reachable:
                continue
            delivery = w.plan_route(worker, outbound.goal, w.adjacent(target))
            if not delivery.reachable:
                continue
            home = w.plan_return_route(worker, delivery.goal)
            if not home.reachable:
                continue
            choices.append({"shop": shop, "outbound": outbound,
                            "turns": outbound.total_distance + delivery.total_distance + home.total_distance + 2,
                            "home_turns": home.total_distance,
                            "route_status": {"shop": outbound.planning_status, "delivery": delivery.planning_status,
                                             "home": home.planning_status}})
        return min(choices, key=lambda x: (x["turns"], pos(x["shop"]))) if choices else None

    def _options(self, w, worker, closed, goal_gap, liquid_enough):
        rid = str(worker["id"])
        stock = sellable_inventory(w, worker)
        occupied_capacity = len(worker.get("backpack", []))
        disabled = getattr(w, "disabled_actions", set())
        failures = Counter()
        def check(route, leg):
            if not route.reachable:
                failures[leg + ":" + route.status] += 1
            elif route.delay:
                failures[leg + ":temporary_people"] += 1
            return route.reachable
        home = w.plan_return_route(worker, worker)
        options = [{"mode": "wait", "income": 0, "harvest": 0, "mine_key": None,
                    "finish": home.goal if home.reachable else pos(worker),
                    "finish_turns": home.total_distance if home.reachable else 0,
                    "home_turns": 0 if home.reachable else None, "travel_turns": home.total_distance,
                    "route_failures": failures, "return_status": home.planning_status,
                    "score": 0.0, "reason": "no_feasible_economic_route"}]
        check(home, "home")
        if w.expired():
            options[0]["reason"] = "budget_exhausted"
            return options
        vendors = sorted((z for z in w.zones if z.get("neutralType") == "vendor"),
                         key=lambda z: (dist(worker, z), pos(z)))[:2]
        if not vendors:
            options[0]["reason"] = "no_vendor"
        sellable = {k: stock[k] for k in MINERALS if stock[k] and w.prices.get(k, 0) > 0}
        income = sum(count * w.prices[k] for k, count in sellable.items())
        if "sell" not in disabled and income:
            for vendor in vendors:
                outward = self._outbound(w, worker, vendor, "sell")
                if not check(outward, "vendor"):
                    continue
                back = w.plan_return_route(worker, outward.goal)
                if not check(back, "home"):
                    continue
                turns = outward.total_distance + len(sellable)
                if turns + back.total_distance + w.return_margin <= w.daylight_left:
                    options.append({"mode": "sell", "income": income, "harvest": 0, "mine_key": None,
                                    "vendor": vendor, "finish": outward.goal, "finish_turns": turns,
                                    "stand": outward.goal,
                                    "home_turns": back.total_distance, "sell_turns": len(sellable),
                                    "travel_turns": outward.total_distance,
                                    "route_status": {"vendor": outward.planning_status, "home": back.planning_status},
                                    "score": income / float(turns + back.total_distance + 1), "reason": "cash_in_inventory"})
                else:
                    failures["sale:time_insufficient"] += 1
        if "collect" in disabled or liquid_enough or occupied_capacity >= worker.get("backPackCapability", 100):
            if "collect" in disabled:
                options[0]["reason"] = "collect_disabled"
            elif liquid_enough:
                options[0]["reason"] = "joint_inventory_liquidation"
            else:
                options[0]["reason"] = "backpack_full"
            return options
        capacity = max(0, worker.get("backPackCapability", 100) - occupied_capacity)
        plan = self.plans.get(rid)
        stable = plan.get("mine") if plan and plan.get("remaining", 0) else None
        if plan and (plan.get("mode") == "sell" or plan.get("remaining") == 0) and income:
            return options
        mines = [z for z in w.zones if z.get("neutralType") in MINERALS
                 and self.available_yield(w, mine_key(z)) > 0 and self.blocked_until.get(mine_key(z), 0) <= w.round
                 and not closed(z["neutralType"], w.day) and w.prices.get(z["neutralType"], 0) > 0]
        mines.sort(key=lambda z: (mine_key(z) != stable, dist(worker, z), pos(z)))
        selected = [z for z in mines if mine_key(z) == stable]
        for kind in MINERALS:
            nearest = next((z for z in mines if z["neutralType"] == kind), None)
            if nearest is not None and nearest not in selected:
                selected.append(nearest)
        for mine in mines:
            if len(selected) >= 4:
                break
            if mine not in selected:
                selected.append(mine)
        if not selected:
            options[0]["reason"] = "no_priced_collectible_mine"
        elif vendors:
            options[0]["reason"] = "economic_route_or_time"
        stable_options = []
        for mine in selected:
            if w.expired():
                break
            key = mine_key(mine)
            outward = self._outbound(w, worker, mine, "mine")
            if not check(outward, "mine"):
                continue
            maximum = min(self.available_yield(w, key), capacity)
            if key == stable:
                maximum = min(maximum, plan["remaining"])
            mineral = key[0]
            price = w.prices[mineral]
            # When selling was explicitly disabled, gather only if a safe home
            # trip remains; inventory is held for another day and credited as zero.
            if "sell" in disabled:
                back = w.plan_return_route(worker, outward.goal)
                check(back, "home")
                limit = w.daylight_left - outward.total_distance - (back.total_distance or 0) - w.return_margin
                amount = min(maximum, limit) if back.reachable else 0
                if amount > 0:
                    options.append({"mode": "mine", "income": 0, "harvest": amount, "mine_key": key,
                                    "mine": mine, "finish": outward.goal, "stand": outward.goal,
                                    "finish_turns": outward.total_distance + amount, "home_turns": back.total_distance,
                                    "sell_turns": 0, "travel_turns": outward.total_distance,
                                    "route_status": {"mine": outward.planning_status, "home": back.planning_status},
                                    "score": price * amount / float(outward.total_distance + amount + back.total_distance + 1),
                                    "reason": "hold_inventory_sell_disabled"})
                continue
            for vendor in vendors:
                if w.expired():
                    break
                sale = w.plan_route(worker, outward.goal, w.adjacent(vendor))
                if not check(sale, "vendor"):
                    continue
                back = w.plan_return_route(worker, sale.goal)
                if not check(back, "home"):
                    continue
                travel = outward.total_distance + sale.total_distance
                limit = min(maximum, w.daylight_left - travel - back.total_distance - w.return_margin)
                if limit <= 0:
                    failures["income:time_insufficient"] += 1
                    continue
                # Keep the mine stable, but let its quota shrink when a second
                # worker becomes available to share the same observed deposit.
                amounts = range(1, limit + 1)
                for amount in amounts:
                    projected = dict(worker, backpack=list(worker.get("backpack", [])) + [mineral] * amount)
                    after_collect = sellable_inventory(w, projected)
                    sold = {k: after_collect[k] for k in MINERALS if after_collect[k] and w.prices.get(k, 0) > 0}
                    value = sum(count * w.prices[k] for k, count in sold.items())
                    sell_turns = len(sold)
                    turns = travel + sell_turns + amount
                    if not value or turns + back.total_distance + w.return_margin > w.daylight_left:
                        failures["income:time_insufficient"] += 1
                        continue
                    option = {"mode": "mine", "income": value, "harvest": amount, "mine_key": key,
                              "mine": mine, "vendor": vendor, "finish": sale.goal, "finish_turns": turns,
                              "stand": outward.goal, "home_turns": back.total_distance, "sell_turns": sell_turns,
                              "travel_turns": outward.total_distance + sale.total_distance,
                              "route_status": {"mine": outward.planning_status, "vendor": sale.planning_status,
                                               "home": back.planning_status},
                              "remaining_inventory": occupied_capacity + amount - sum(sold.values()),
                              "score": value / float(turns + back.total_distance + 1), "reason": "income_cycle"}
                    options.append(option)
                    if key == stable:
                        stable_options.append(option)
        if stable_options:
            # Preserve a feasible mine until its observed quota is met. A funded
            # upgrade can still interrupt it through the joint liquidation check.
            options = [o for o in options if o["mode"] == "wait"] + stable_options
        if w.expired():
            failures["planning:budget_exhausted"] += 1
            options[0]["reason"] = "budget_exhausted"
        return options

    def _outbound(self, w, worker, target, mode):
        """Keep a useful interaction cell; reselect after three stalled turns."""
        rid = str(worker["id"])
        goals = w.adjacent(target)
        avoided = self.avoid_stands.get(rid)
        if avoided and avoided[1] > w.round and len(goals) > 1:
            goals = goals - {avoided[0]}
        plan = self.plans.get(rid, {})
        matching = (plan.get("mode") == mode and
                    (plan.get("mine") == mine_key(target) if mode == "mine" else
                     plan.get("vendor") == pos(target)))
        if matching and plan.get("stand") in goals:
            retained = w.plan_route(worker, worker, {plan["stand"]})
            if retained.reachable:
                return retained
        return w.plan_route(worker, worker, goals)

    def available_yield(self, w, key):
        # Wall workers are outside the economic pair, but use the same deposit.
        return max(0, self.mines.get(key, 0) -
                   _reservation(getattr(w, "wall_mine_reservations", {}), key))

    @staticmethod
    def remaining_inventory(w, worker, choice):
        if "remaining_inventory" in choice:
            return choice["remaining_inventory"]
        remaining = len(worker.get("backpack", []))
        if choice["mode"] == "sell":
            stock = sellable_inventory(w, worker)
            remaining -= sum(stock[k] for k in MINERALS if w.prices.get(k, 0) > 0)
        elif choice["mode"] == "mine":
            remaining += choice["harvest"]
        return remaining

    def step(self, w, commands, workers, budget, goal, closed, move, defend):
        self.refresh_inventory(w)
        if not workers:
            return
        workers = sorted(workers, key=lambda p: str(p["id"]))[:2]
        gap = max(0, goal["price"] + goal["reserve"] - budget) if goal else 0
        liquid = sum(sum(sellable_inventory(w, p)[k] * w.prices.get(k, 0) for k in MINERALS)
                     for p in workers)
        options = [self._options(w, p, closed, gap, bool(goal and gap and liquid >= gap)) for p in workers]
        if goal and gap and liquid >= gap and sum(max(c["income"] for c in choices) for choices in options) < gap:
            # Stock behind an unusable route cannot finance the goal. The other
            # worker may still safely earn the missing income independently.
            options = [self._options(w, p, closed, gap, False) for p in workers]
        # Cache each possible courier's complete route once, not per combination.
        trips = {}
        if goal:
            for worker, choices in zip(workers, options):
                rid = str(worker["id"])
                for choice in choices:
                    if w.expired():
                        break
                    key = (rid, choice["finish"])
                    if key not in trips:
                        trips[key] = self.upgrade_trip(w, worker, choice["finish"], goal["target"])
        best, best_key, completion = None, None, None
        for choices in itertools.product(*options):
            if w.expired():
                break
            claims = Counter()
            for choice in choices:
                if choice["mine_key"]:
                    claims[choice["mine_key"]] += choice["harvest"]
            if any(amount > self.available_yield(w, key) for key, amount in claims.items()):
                continue
            total = sum(c["income"] for c in choices)
            finish = None
            courier = None
            if goal and total >= gap:
                # Income arrives on the observation after the corresponding sell.
                receipts = sorted((c["finish_turns"], c["income"]) for c in choices if c["income"])
                available, funded_at = 0, 0
                for when, value in receipts:
                    if available >= gap:
                        break
                    available += value
                    funded_at = when
                for worker, choice in zip(workers, choices):
                    rid = str(worker["id"])
                    if self.remaining_inventory(w, worker, choice) >= worker.get("backPackCapability", 100):
                        continue
                    trip = trips.get((rid, choice["finish"]))
                    if trip is None:
                        continue
                    end = max(funded_at, choice["finish_turns"]) + trip["turns"] + w.return_margin
                    if end <= w.daylight_left and (finish is None or end < finish):
                        finish, courier = end, rid
            rank = ((1, -finish, total, sum(c["score"] for c in choices)) if finish is not None else
                    (0, sum(c["score"] for c in choices), total, -sum(c["finish_turns"] for c in choices)))
            if best_key is None or rank > best_key:
                best, best_key, completion = choices, rank, (finish, courier)
        if goal:
            upgrade = self.context["upgrade"]
            upgrade.update(target_id=str(goal["target"]["id"]), voucher=goal["name"], price=goal["price"],
                           reserve=goal["reserve"], cash_gap=gap, joint_inventory_value=liquid,
                           reason="fundable_cycle" if completion and completion[0] is not None else
                           ("accumulating_or_no_upgrade_window" if gap else "cash_ready_no_upgrade_window"))
            if completion and completion[0] is not None:
                upgrade.update(trip_turns=completion[0], worker_id=completion[1])
        if best is None:
            for worker in workers:
                self.note(worker["id"], "wait", "budget_exhausted" if w.expired() else "no_feasible_economic_route")
                defend(w, commands, [worker])
            return
        for worker, choice, choices in zip(workers, best, options):
            rid = str(worker["id"])
            details = {key: choice[key] for key in ("sell_turns", "home_turns", "travel_turns",
                                                   "route_status", "route_failures", "return_status") if key in choice}
            details["collect_turns"] = choice["harvest"]
            if choice.get("vendor"):
                details["vendor"] = list(pos(choice["vendor"]))
            if choice.get("mine"):
                details["mine"] = {"kind": choice["mine_key"][0], "pos": list(pos(choice["mine"]))}
            reason = "joint_plan_wait" if choice["mode"] == "wait" and len(choices) > 1 else choice["reason"]
            self.note(rid, choice["mode"], reason, **details)
            if choice["mode"] == "mine":
                self.plans[rid] = {"mode": "mine", "mine": choice["mine_key"], "remaining": choice["harvest"],
                                   "stand": choice["stand"]}
                if w.near(worker, choice["mine"]):
                    commands[rid] = action("collect", pos(choice["mine"]))
                elif not move(w, commands, worker, {choice["stand"]}):
                    self.note(rid, "mine", "mine_path_blocked")
            elif choice["mode"] == "sell":
                self.plans[rid] = {"mode": "sell", "mine": None, "remaining": 0,
                                   "stand": choice["stand"], "vendor": pos(choice["vendor"])}
                if w.near(worker, choice["vendor"]):
                    stock = sellable_inventory(w, worker)
                    kind = max((k for k in MINERALS if stock[k] and w.prices.get(k, 0) > 0),
                               key=lambda k: stock[k] * w.prices[k])
                    commands[rid] = action("sell", name=kind, num=stock[kind])
                elif not move(w, commands, worker, {choice["stand"]}):
                    self.note(rid, "sell", "vendor_path_blocked")
            else:
                defend(w, commands, [worker])
