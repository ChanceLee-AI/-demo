"""Platform-reported library candidates, not verified sandbox dependencies.

Versions are copied from docs/requirements.txt.txt during development. Runtime
code never reads that document or imports these libraries to build a prompt.
"""

TASK_LIBRARIES = (
    {"distribution": "requests", "module": "requests", "version": "2.32.3"},
    {"distribution": "numpy", "module": "numpy", "version": "1.26.4"},
    {"distribution": "pandas", "module": "pandas", "version": "2.2.2"},
    {"distribution": "networkx", "module": "networkx", "version": "3.3"},
    {"distribution": "sympy", "module": "sympy", "version": "1.13.2"},
    {"distribution": "Pillow", "module": "PIL", "version": "10.4.0"},
    {"distribution": "PyYAML", "module": "yaml", "version": "6.0.2"},
)
