"""Observed-inventory healing with one funded daytime self-purchase trip."""
from collections import Counter

from .world import action, pos


MEDICINES = ("Medicine", "medicine")


def maximum_health(role):
    for key in ("maxHealth", "maxHp", "healthMax"):
        value = role.get(key)
        if isinstance(value, (int, float)) and value > 0:
            return value
    return 220 if role.get("roleType") == "worker" else 200


def wounded(role):
    return 0 < role.get("health", 0) <= maximum_health(role) / 2


def occupied_roles(commands):
    return set(map(str, commands)) | {str(c["controllerId"]) for c in commands.values()
                                      if c.get("controllerId") is not None}


def travel_distance(route):
    return getattr(route, "total_distance", route.distance)


class MedicalPlanner:
    def __init__(self):
        self.round = None
        self.plan = None
        self.pending = {}
        self.failures = {}
        self.blocked = {}
        self.travel_pending = None
        self.stalls = {}
        self.avoided_stands = {}
        self.context = {}

    @staticmethod
    def _busy(w, role):
        return role.get("roleType") == "pioneer" and bool(
            getattr(w, "task_busy", False) or w.raw.get("phaseTask"))

    def _allowed(self, w, rid, verb):
        return (verb not in getattr(w, "disabled_actions", set())
                and self.failures.get((w.day, rid, verb), 0) < 2
                and self.blocked.get((rid, verb), 0) <= w.round)

    @staticmethod
    def _route(w, role, start, goals):
        if hasattr(w, "plan_route"):
            return w.plan_route(role, start, goals)
        return w.route(start, goals, ignore_people={str(role["id"])})

    @staticmethod
    def _home(w, role, start):
        if hasattr(w, "plan_return_route"):
            return w.plan_return_route(role, start)
        return w.return_route(start, ignore_people={str(role["id"])})

    def _trip(self, w, role):
        choices = []
        rid = str(role["id"])
        for shop in w.zones:
            if w.expired():
                break
            if shop.get("neutralType") != "weaponShop":
                continue
            goals = {cell for cell in w.adjacent(shop)
                     if self.avoided_stands.get((rid, pos(shop), cell), 0) <= w.round}
            old = self.plan
            preferred = (old.get("stand") if old and old["role"] == rid
                         and pos(old["shop"]) == pos(shop) else None)
            outward = self._route(w, role, role, {preferred}) if preferred in goals else None
            if outward is None or not outward.reachable:
                outward = self._route(w, role, role, goals)
            if not outward.reachable:
                continue
            home = self._home(w, role, outward.goal)
            if not home.reachable:
                continue
            turns = travel_distance(outward) + 2 + travel_distance(home)
            if turns + w.return_margin <= w.daylight_left:
                choices.append({"shop": shop, "stand": outward.goal, "turns": turns,
                                "home_turns": travel_distance(home)})
        old_shop = pos(self.plan["shop"]) if self.plan and self.plan["role"] == rid else None
        return min(choices, key=lambda t: (pos(t["shop"]) != old_shop, t["turns"], pos(t["shop"]))) if choices else None

    def _cash_guard(self, w):
        reserve = 25 * max(0, 3 - len(w.weapons))
        base = w.station
        if (not base or base.get("level", 1) >= 3
                or {"buy", "use"}.intersection(getattr(w, "disabled_actions", set()))):
            return reserve
        level = int(base.get("level", 1))
        if base.get("health", 1500 * level) >= 750 * level:
            return reserve
        name = "StationUpgradeVoucher" + str(level)
        if name not in w.shop:
            return reserve
        if any(name in (r.get("backpack") or [])
               for r in (w.raw.get("teamOur") or {}).get("roles", [])):
            return reserve
        price = w.shop[name]
        if price + reserve > w.gold:
            return reserve
        for role in w.workers:
            if len(role.get("backpack") or []) >= role.get("backPackCapability", 100):
                continue
            for shop in w.zones:
                if w.expired():
                    return reserve
                if shop.get("neutralType") != "weaponShop":
                    continue
                outbound = self._route(w, role, role, w.adjacent(shop))
                if not outbound.reachable:
                    continue
                delivery = self._route(w, role, outbound.goal, w.adjacent(base))
                if not delivery.reachable:
                    continue
                home = self._home(w, role, delivery.goal)
                if (home.reachable and travel_distance(outbound) + travel_distance(delivery)
                        + travel_distance(home) + 2 + w.return_margin <= w.daylight_left):
                    return reserve + price
        return reserve

    def _observe(self, w):
        events = []
        travel = self.travel_pending
        if travel:
            role = w.own.get(travel["role"])
            key = (travel["role"], travel["shop"], travel["stand"])
            stalled = (travel["round"] + 1 == w.round and role
                       and pos(role) == travel["position"])
            self.stalls[key] = self.stalls.get(key, 0) + 1 if stalled else 0
            if self.stalls[key] >= 3:
                self.avoided_stands[key] = w.round + 5
                self.stalls[key] = 0
                self.plan = None
                events.append({"role": travel["role"], "event": "medical_stalled_replan",
                               "avoided_stand": list(travel["stand"]), "until": w.round + 5})
        self.travel_pending = None
        self.stalls = {k: v for k, v in self.stalls.items() if k[0] in w.own and v}
        self.avoided_stands = {k: v for k, v in self.avoided_stands.items() if k[0] in w.own and v > w.round}
        results = w.raw.get("lastRoundRoleActionResults") or {}
        results = {str(k): v for k, v in results.items()} if isinstance(results, dict) else {}
        for rid, pending in self.pending.items():
            if pending["round"] + 1 != w.round:
                events.append({"role": rid, "event": "feedback_unassociated", "action": pending["action"]})
                continue
            role = w.own.get(rid)
            if role is None:
                events.append({"role": rid, "event": "role_unavailable"})
                continue
            count = Counter(role.get("backpack") or [])[pending["name"]]
            verb = pending["action"]
            inventory_confirmed = (count > pending["count"] if verb == "buy" else count < pending["count"])
            health_confirmed = verb == "use" and role.get("health", 0) > pending["hp"]
            confirmed = inventory_confirmed or health_confirmed
            events.append({"role": rid, "event": "confirmed" if confirmed else "unconfirmed",
                           "action": verb, "feedback": results.get(rid),
                           "hp_before": pending["hp"], "hp_after": role.get("health"),
                           "inventory_before": pending["count"], "inventory_after": count,
                           "confirmation": (["inventory"] if inventory_confirmed else [])
                                           + (["health"] if health_confirmed else [])})
            if not confirmed:
                key = (w.day, rid, verb)
                self.failures[key] = self.failures.get(key, 0) + 1
                self.blocked[(rid, verb)] = w.round + 5
                if self.plan and self.plan["role"] == rid:
                    self.plan = None
        self.pending = {}
        self.failures = {key: value for key, value in self.failures.items() if key[0] == w.day}
        self.blocked = {key: value for key, value in self.blocked.items()
                        if value > w.round and key[0] in w.own}
        return events

    def _publish(self, w):
        w.medical_roles = set(self.context.get("roles", {}))
        w.medical_reserve = self.context.get("reserved_gold", 0)
        w.medical_context = self.context

    def prepare(self, w):
        if self.round == w.round:
            self._publish(w)
            return
        self.round = w.round
        self.context = {"round": w.round, "roles": {}, "reserved_gold": 0,
                        "plan": None, "events": self._observe(w)}
        candidates = []
        for role in w.people:
            rid = str(role["id"])
            if not wounded(role) or self._busy(w, role):
                continue
            name = next((n for n in MEDICINES if n in (role.get("backpack") or [])), None)
            reason = None
            if not self._allowed(w, rid, "use"):
                reason = "use_disabled_or_paused"
            elif name:
                home = self._home(w, role, role) if not w.night else None
                if w.night or (home.reachable and travel_distance(home) + 1 + w.return_margin <= w.daylight_left):
                    self.context["roles"][rid] = {"stage": "use_owned", "name": name,
                                                  "hp": role["health"]}
                else:
                    reason = "return_before_healing"
            elif not w.night:
                if len(role.get("backpack") or []) >= role.get("backPackCapability", 40 if role.get("roleType") == "pioneer" else 100):
                    reason = "backpack_full"
                elif not self._allowed(w, rid, "buy"):
                    reason = "buy_disabled_or_paused"
                else:
                    candidates.append(role)
            if reason:
                self.context["events"].append({"role": rid, "event": reason})
        name = next((n for n in MEDICINES if n in w.shop), None)
        # A funded emergency base upgrade must also survive the earlier task
        # procurement phase when nobody needs medicine, or exactly the voucher
        # price is available and no medical purchase plan can be created.
        guard = self._cash_guard(w) if not w.night else 0
        self.context["cash_guard"] = guard
        old_plan = self.plan
        choices = []
        if name and candidates and w.shop[name] <= w.gold - guard:
            for role in candidates:
                if w.expired():
                    break
                trip = self._trip(w, role)
                if trip:
                    rid = str(role["id"])
                    choices.append((not (old_plan and old_plan["role"] == rid),
                                    role["health"] / maximum_health(role), trip["turns"], rid, trip))
            if choices:
                _, _, _, rid, trip = min(choices, key=lambda c: c[:4])
                self.plan = {"role": rid, "name": name, "price": w.shop[name], "stand": trip["stand"],
                             "shop": trip["shop"], "turns": trip["turns"],
                             "home_turns": trip["home_turns"], "cash_guard": guard}
                self.context["reserved_gold"] = w.shop[name]
                self.context["roles"][rid] = {"stage": "buy", "name": name,
                                               "hp": w.own[rid]["health"]}
                self.context["plan"] = dict(self.plan)
        if self.context["plan"] is None:
            self.plan = None
        if candidates and not self.plan:
            reason = "medicine_unavailable" if name is None else (
                "insufficient_observed_cash" if w.shop[name] > w.gold - guard else "medical_route_or_time")
            self.context["events"].append({"event": reason})
        self._publish(w)

    def use_owned(self, w, commands, held=()):
        used = occupied_roles(commands) | set(held)
        for rid, plan in self.context.get("roles", {}).items():
            if plan["stage"] != "use_owned" or rid in used:
                continue
            role = w.own.get(rid)
            if role and wounded(role) and plan["name"] in (role.get("backpack") or []):
                commands[rid] = action("use", name=plan["name"])

    def purchase(self, w, commands, budget, unavailable, move):
        plan = self.plan
        if not plan or w.night:
            return set(), 0
        rid = plan["role"]
        if rid in occupied_roles(commands) | set(unavailable):
            return set(), 0
        role = w.own.get(rid)
        if role is None or self._busy(w, role):
            return set(), 0
        # Re-evaluate after earlier purchases; an uncommitted sale is never cash.
        consumed_guard = sum(25 for c in commands.values() if c.get("action") == "build"
                             and c.get("name") in ("railgun", "gatling", "rocket"))
        consumed_guard += sum(w.shop.get(c.get("name"), 0) * c.get("num", 1)
                              for c in commands.values() if c.get("action") == "buy"
                              and str(c.get("name", "")).startswith("StationUpgradeVoucher"))
        guard = max(0, plan["cash_guard"] - consumed_guard)
        if plan["price"] > budget - guard:
            self.context["events"].append({"role": rid, "event": "cash_consumed_by_prior_action"})
            return set(), 0
        if w.near(role, plan["shop"]):
            commands[rid] = action("buy", name=plan["name"], num=1)
        else:
            self.context["travel_claimed"] = rid
            moved = move(w, commands, role, {plan["stand"]})
            if moved:
                return {rid}, plan["price"]
            self.context["events"].append({"role": rid, "event": "medical_move_blocked"})
            # Keep the funded trip through a transient actor blockage.
            return {rid}, plan["price"]
        return {rid}, plan["price"]

    def record(self, w, commands):
        """Called only by Engine after final validation; same-round calls replace."""
        self.pending = {}
        for rid, command in commands.items():
            rid = str(rid)
            role = w.own.get(rid)
            if (not role or command.get("name") not in MEDICINES
                    or command.get("action") not in ("buy", "use")):
                continue
            self.pending[rid] = {"round": w.round, "action": command["action"],
                                 "name": command["name"], "hp": role.get("health", 0),
                                 "count": Counter(role.get("backpack") or [])[command["name"]]}
        self.context["sent"] = {rid: {"action": p["action"], "name": p["name"]}
                                for rid, p in self.pending.items()}
        self.travel_pending = None
        rid = self.context.get("travel_claimed")
        if (self.plan and rid == self.plan["role"] and rid in w.own
                and commands.get(rid, {}).get("action") in (None, "move")):
            self.travel_pending = {"role": rid, "round": w.round, "position": pos(w.own[rid]),
                                   "shop": pos(self.plan["shop"]), "stand": self.plan["stand"]}
