"""Reference building rings with explicit, joint hypothetical-wall connectivity.

Static planning ignores transient actors; actual moves still use World.route and
the final validator. A wall is never assumed to shield a ranged attack.
"""
from collections import deque

from .world import PathResult, dist, pos


class FortLayout:
    def __init__(self):
        self.targets = ()
        self.gate = None
        self.ready = False
        self.reason = "no_base"
        self._base = None
        self._signature = None
        self._world = None
        self._trees = {}
        self.inner = set()

    @staticmethod
    def ring(w, radius):
        if not w.station:
            return ()
        footprint = w.footprint(w.station)
        xs, ys = [x for x, _ in footprint], [y for _, y in footprint]
        return tuple((x, y) for x in range(min(xs) - radius, max(xs) + radius + 1)
                     for y in range(min(ys) - radius, max(ys) + radius + 1)
                     if w.in_bounds((x, y)) and min(dist((x, y), p) for p in footprint) == radius)

    @staticmethod
    def wall_order(w):
        if not w.station:
            return ()
        fp = w.footprint(w.station)
        xmin, xmax = min(x for x, _ in fp), max(x for x, _ in fp)
        ymin, ymax = min(y for _, y in fp), max(y for _, y in fp)
        cells = ([(x, ymin - 2) for x in range(xmax + 2, xmin - 3, -1)]
                 + [(xmin - 2, y) for y in range(ymin - 1, ymax + 2)]
                 + [(x, ymax + 2) for x in range(xmin - 2, xmax + 3)]
                 + [(xmax + 2, y) for y in range(ymax + 1, ymin - 2, -1)])
        return tuple(p for p in cells if w.in_bounds(p))

    def weapon_sites(self, w):
        return tuple(p for p in self.ring(w, 1) if p not in w.static)

    def prospective_weapon_safe(self, w, candidate):
        """A new first-ring gun must preserve the established complete layout."""
        if not self.ready or self.gate is None:
            # With no safe perimeter, independent weapon construction may still
            # be useful; the wall planner stays paused and records the reason.
            return True
        proposal = {"roleType": "gatling", "pos": {"x": pos(candidate)[0], "y": pos(candidate)[1]}}
        return self._complete_layout_safe(w, self.targets, self.gate, [proposal])

    def _sync(self, w):
        if self._world is not w:
            self._world = w
            self._trees = {}

    def _tree(self, w, start, blocked):
        self._sync(w)
        start, blocked = pos(start), frozenset(blocked)
        key = (start, blocked)
        if key in self._trees:
            return self._trees[key]
        if start in blocked or not w.in_bounds(start):
            return {}, {}, True
        parents, depths, queue = {start: None}, {start: 0}, deque([start])
        complete, visited = True, 0
        while queue:
            current = queue.popleft()
            if visited % 64 == 0 and w.expired():
                complete = False
                break
            visited += 1
            for nxt in w.neighbors(current):
                if nxt not in blocked and nxt not in parents:
                    parents[nxt] = current
                    depths[nxt] = depths[current] + 1
                    queue.append(nxt)
        if complete:
            self._trees[key] = parents, depths, complete
        return parents, depths, complete

    def route(self, w, start, goals, add_walls=()):
        start = pos(start)
        goals = {pos(p) for p in goals if w.in_bounds(p)}
        blocked = w.static | {pos(p) for p in add_walls}
        if w.expired():
            return PathResult("budget_exhausted")
        if start in blocked:
            return PathResult("unreachable")
        if start in goals:
            return PathResult("arrived", [], goal=start)
        parents, depths, complete = self._tree(w, start, blocked)
        available = goals.intersection(parents)
        if not available:
            return PathResult("unreachable" if complete else "budget_exhausted")
        goal = min(available, key=lambda p: (depths[p], p))
        cursor, steps = goal, []
        while cursor != start:
            steps.append(cursor)
            cursor = parents[cursor]
        return PathResult("reachable", list(reversed(steps)), goal=goal)

    @staticmethod
    def _destinations(w):
        return [w.adjacent(z) for z in w.zones
                if z.get("neutralType") in ("vendor", "weaponShop")
                or str(z.get("neutralType", "")).startswith(w.team_type + "TaskPoint")]

    def _complete_layout_safe(self, w, walls, gate, extra_guns=()):
        static = w.static | {pos(g) for g in extra_guns}
        inner = sorted(set(self.ring(w, 1)) - static)
        if not inner or gate in static:
            return False
        anchor = inner[0]
        before, _, complete = self._tree(w, anchor, static)
        if not complete:
            return False
        after, _, complete = self._tree(w, anchor, static | set(walls))
        if not complete or gate not in after:
            return False
        outside = {p for p in self.ring(w, 3) if p not in static}
        if not outside.intersection(after):
            return False
        # Do not introduce a disconnection to any previously accessible service
        # or inner control cell. Existing map obstructions are not our fault.
        for goals in self._destinations(w) + [{p} for p in inner]:
            if goals.intersection(before) and not goals.intersection(after):
                return False
        # Individually reachable control cells are insufficient when two guns
        # share their only cell. Include the selected opening as a fallback for
        # legacy layouts; new gun placement reserves three distinct inner cells.
        controls = set(inner) | {gate}
        choices = [w.adjacent(gun).intersection(controls, after) for gun in list(w.weapons) + list(extra_guns)]
        def assign(index, used):
            if index == len(choices):
                return True
            return any(assign(index + 1, used | {cell}) for cell in choices[index] - used)
        return assign(0, set())

    def prepare(self, w):
        self._sync(w)
        base = tuple(sorted(w.footprint(w.station))) if w.station else None
        if base != self._base:
            self._base, self._signature, self.gate = base, None, None
        self.inner = set(self.ring(w, 1)) - w.static
        if not base:
            self.targets, self.ready, self.reason = (), False, "no_base"
            self._publish(w)
            return
        walls = {pos(r) for r in w.own.values() if r.get("roleType") == "wall"}
        fixed = w.static - walls
        signature = (base, frozenset(w.static), tuple(sorted(pos(g) for g in w.weapons)))
        if signature != self._signature:
            order = tuple(p for p in self.wall_order(w) if p not in fixed)
            xmax, ymin = max(x for x, _ in base), min(y for _, y in base)
            default = (xmax + 2, ymin - 1)
            preferred = [p for p in (self.gate, default) if p in order]
            gates = list(dict.fromkeys(preferred + list(order)))
            chosen = None
            for gate in gates:
                if w.expired():
                    break
                if gate not in w.static and self._complete_layout_safe(w, set(order) - {gate}, gate):
                    chosen = gate
                    break
            if chosen is None:
                self.ready = False
                self.reason = "layout_budget" if w.expired() else "no_safe_gate"
                # Retain the material requirement during a transient planning
                # timeout, but never issue walls with an unconfirmed safe gate.
                self.targets = tuple(p for p in order if p != self.gate)
            else:
                self.gate, self.ready, self.reason = chosen, True, "ready"
                self.targets = tuple(p for p in order if p != chosen)
            if not w.expired():
                self._signature = signature
        self._publish(w)

    def _publish(self, w):
        present = {pos(r) for r in w.own.values() if r.get("roleType") == "wall"}
        w.wall_layout = self
        w.wall_targets = set(self.targets)
        w.wall_gate = self.gate
        w.wall_planned = set(self.targets) - present if self.ready else set()
        w.defense_inner = set(self.inner)
        w.wall_layout_reason = self.reason

    def safe(self, w, add_walls, commands=None):
        cells = {pos(p) for p in add_walls}
        if not self.ready or not cells or not cells.issubset(self.targets) or self.gate in cells:
            return False
        if cells.intersection(w.occupied):
            return False
        commands = commands or {}
        if any(pos(p) in cells for c in commands.values() if c.get("action") == "move"
               for p in c.get("targetPos", [])):
            return False
        assignments = getattr(w, "defense_assignments", {})
        if cells.intersection(pos(a["pos"]) for a in assignments.values()):
            return False
        # Cache one static graph per actor and joint set. Unlike World.route's
        # transient-block fallback, hypothetical walls remain blocked throughout.
        destinations = self._destinations(w)
        inside = self.inner - cells
        for person in w.people:
            before, _, complete = self._tree(w, pos(person), w.static)
            if not complete:
                return False
            after, _, complete = self._tree(w, pos(person), w.static | cells)
            if not complete:
                return False
            goals = list(destinations) + [inside]
            assigned = assignments.get(str(person["id"]))
            if assigned:
                goals.append({pos(assigned["pos"])})
            for goal in goals:
                if goal.intersection(before) and not goal.intersection(after):
                    return False
        return True
