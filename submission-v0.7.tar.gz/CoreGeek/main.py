#!/usr/bin/env python3
"""Competition HTTP entry point. Uses only the Python standard library."""
import sys


def emit_event(message):
    """Keep critical fixed-label diagnostics visible to either stream collector."""
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.write(message + "\n")
            stream.flush()
        except Exception:
            # A unavailable log stream must not interrupt startup or a round.
            pass


if __name__ == "__main__":
    emit_event("boot stage=python_enter python=" + ".".join(str(n) for n in sys.version_info[:3]))
else:
    emit_event("boot stage=module_import entry=main")

import json
import logging
import os
import socketserver
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

MAX_REQUEST_BYTES = 8 * 1024 * 1024


def empty_response():
    return {"roleCommandMap": {}, "prompt": "", "executeCmd": ""}


def callback(raw):
    """SDK callback entry; importing this module does not import the Agent."""
    try:
        from agent.sdk import callback as sdk_callback
        return sdk_callback(raw)
    except Exception as exc:
        emit_event("callback stage=failed reason=import_failed error=" + type(exc).__name__)
        return empty_response()


def __getattr__(name):
    if name == "app":
        try:
            from agent.sdk import get_app
            return get_app()
        except Exception as exc:
            emit_event("boot stage=failed reason=app_import_failed error=" + type(exc).__name__)
            raise ImportError("Agent application unavailable") from None
    raise AttributeError("module 'main' has no attribute " + repr(name))


class AgentServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True

    def __init__(self, address, engine, version, decision_lock=None):
        self.engine = engine
        self.version = version
        self.decision_lock = decision_lock if decision_lock is not None else threading.Lock()
        self.request_sequence = 0
        self.connection_sequence = 0
        self.sequence_lock = threading.Lock()
        super().__init__(address, Handler)

    def server_bind(self):
        # HTTPServer's implementation resolves a hostname before listening.
        # The numeric bound address is sufficient for this HTTP endpoint.
        socketserver.TCPServer.server_bind(self)
        self.server_name = str(self.server_address[0])
        self.server_port = self.server_address[1]

    def get_request(self):
        connection, address = super().get_request()
        with self.sequence_lock:
            self.connection_sequence += 1
            sequence = self.connection_sequence
        if sequence <= 3:
            emit_event("connection seq=%s stage=accepted version=%s" % (sequence, self.version))
        return connection, address

    def next_sequence(self):
        with self.sequence_lock:
            self.request_sequence += 1
            return self.request_sequence


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt, *args):
        # Do not log request bodies, model output, sandbox output, or URLs.
        pass

    def _send(self, payload):
        encoded = json.dumps(payload, ensure_ascii=False, allow_nan=False, separators=(",", ":")).encode("utf-8")
        self.close_connection = True
        try:
            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(encoded)))
            self.send_header("Connection", "close")
            self.end_headers()
            self.wfile.write(encoded)
            self.wfile.flush()
            return len(encoded), True
        except (BrokenPipeError, ConnectionResetError, OSError):
            return len(encoded), False

    def do_GET(self):
        self._send({"status": "ok", "version": self.server.version})

    def _trace(self, sequence, stage, **fields):
        if sequence <= 3:
            details = " ".join(str(key) + "=" + str(value) for key, value in fields.items())
            emit_event("request seq=%s stage=%s version=%s %s" %
                       (sequence, stage, self.server.version, details))

    def _read_body(self):
        deadline = time.monotonic() + 2.0

        def read(size, line=False):
            parts, received = [], 0
            while received < size:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    raise ValueError("body_deadline")
                self.connection.settimeout(remaining)
                piece = self.rfile.read1(1 if line else size - received)
                if not piece:
                    break
                parts.append(piece)
                received += len(piece)
                if line and piece == b"\n":
                    break
            return b"".join(parts)

        transfer = self.headers.get("Transfer-Encoding", "").lower().strip()
        lengths = self.headers.get_all("Content-Length", [])
        if transfer:
            if transfer != "chunked" or lengths:
                raise ValueError("unsupported_framing")
            chunks, total, overhead = [], 0, 0
            while True:
                line = read(128, line=True)
                overhead += len(line)
                if not line.endswith(b"\r\n") or overhead > 65536:
                    raise ValueError("chunk_header")
                token = line[:-2].split(b";", 1)[0]
                if not token or any(c not in b"0123456789abcdefABCDEF" for c in token):
                    raise ValueError("chunk_size")
                size = int(token, 16)
                if size == 0:
                    while True:
                        trailer = read(8192, line=True)
                        overhead += len(trailer)
                        if not trailer.endswith(b"\r\n") or overhead > 65536:
                            raise ValueError("chunk_trailer")
                        if trailer == b"\r\n":
                            return b"".join(chunks)
                total += size
                if total > MAX_REQUEST_BYTES:
                    raise ValueError("body_too_large")
                chunk = read(size)
                if len(chunk) != size or read(2) != b"\r\n":
                    raise ValueError("chunk_incomplete")
                chunks.append(chunk)
        if len(lengths) != 1 or not lengths[0].isdigit():
            raise ValueError("content_length_missing_or_invalid")
        length = int(lengths[0])
        if not 0 < length <= MAX_REQUEST_BYTES:
            raise ValueError("content_length_out_of_bounds")
        body = read(length)
        if len(body) != length:
            raise ValueError("body_incomplete")
        return body

    def do_POST(self):
        response = empty_response()
        acquired = False
        phase = "read_body"
        started = time.monotonic()
        sequence = self.server.next_sequence()
        self._trace(sequence, "received", method="POST")
        round_no, roles_count = "unknown", 0
        try:
            body = self._read_body()
            phase = "parse_json"
            raw = json.loads(body.decode("utf-8-sig"), parse_constant=lambda x: (_ for _ in ()).throw(ValueError("nonfinite")))
            if isinstance(raw, dict):
                number = raw.get("roundNo")
                round_no = number if type(number) is int and 0 <= number <= 10000000 else "invalid"
                team = raw.get("teamOur")
                roles = team.get("roles") if isinstance(team, dict) else None
                roles_count = len(roles) if isinstance(roles, list) else "invalid"
            self._trace(sequence, "parsed", round=round_no, roles=roles_count, request_bytes=len(body))
            phase = "decision_lock"
            acquired = self.server.decision_lock.acquire(timeout=1.0)
            if acquired:
                phase = "decision"
                response = self.server.engine.handle(raw)
                self._trace(sequence, "decided", round=round_no, roles=roles_count,
                            actions=len(response["roleCommandMap"]),
                            elapsed_ms=round((time.monotonic() - started) * 1000, 2))
            else:
                logging.getLogger("futurewar").warning("request_fallback phase=decision_lock reason=busy")
                emit_event("request seq=%s stage=failed phase=decision_lock reason=busy" % sequence)
        except Exception as exc:
            # _read_body raises only fixed operational labels; JSON exceptions
            # can contain task data and must never be included verbatim.
            reason = str(exc) if phase == "read_body" and type(exc) is ValueError else type(exc).__name__
            logging.getLogger("futurewar").warning("request_fallback phase=%s reason=%s", phase, reason)
            emit_event("request seq=%s stage=failed phase=%s reason=%s" % (sequence, phase, reason))
        finally:
            if acquired:
                self.server.decision_lock.release()
        if time.monotonic() - started > 4.0:
            logging.getLogger("futurewar").warning("slow_request phase=%s elapsed_ms=%.1f", phase,
                                                   (time.monotonic() - started) * 1000)
        response_bytes, written = self._send(response)
        self._trace(sequence, "written" if written else "write_failed", round=round_no, roles=roles_count,
                    actions=len(response["roleCommandMap"]), response_bytes=response_bytes,
                    elapsed_ms=round((time.monotonic() - started) * 1000, 2))


def configure_logging():
    logger = logging.getLogger("futurewar")
    logger.setLevel(logging.INFO)
    stream = logging.StreamHandler()
    stream.setFormatter(logging.Formatter("%(message)s"))
    logger.addHandler(stream)
    # File logging is opt-in and best effort. Default stderr works in read-only
    # submissions and contains only operational summaries, never task content.
    path = os.environ.get("FUTUREWAR_LOG")
    if path:
        try:
            handler = logging.FileHandler(path, encoding="utf-8")
            handler.setFormatter(logging.Formatter("%(message)s"))
            logger.addHandler(handler)
        except OSError:
            logger.info("file_log_unavailable")
    # Logging failures must not cause a failed round.
    logging.raiseExceptions = False


def main():
    arguments = sys.argv[1:]
    if (len(arguments) != 1 or not 1 <= len(arguments[0]) <= 5
            or any(c not in "0123456789" for c in arguments[0])
            or not 1 <= int(arguments[0]) <= 65535):
        emit_event("boot stage=failed reason=invalid_port")
        return 2
    port = int(arguments[0])
    try:
        from agent import VERSION
        from agent.sdk import get_runtime
        runtime = get_runtime()
    except Exception as exc:
        emit_event("boot stage=failed reason=import_failed error=" + type(exc).__name__)
        return 3
    emit_event("boot stage=agent_imported version=" + VERSION)
    configure_logging()
    try:
        server = AgentServer(("0.0.0.0", port), runtime.engine, VERSION, runtime.decision_lock)
    except OSError as exc:
        emit_event("boot stage=failed reason=bind_failed error=%s errno=%s port=%s" %
                   (type(exc).__name__, exc.errno, port))
        return 4
    except Exception as exc:
        emit_event("boot stage=failed reason=server_init_failed error=" + type(exc).__name__)
        return 5
    emit_event("boot stage=listening version=%s host=0.0.0.0 port=%s" % (VERSION, server.server_port))
    logging.getLogger("futurewar").info("ready version=%s host=0.0.0.0 port=%s python=%s", VERSION,
                                       server.server_port, sys.version.split()[0])
    try:
        server.serve_forever(poll_interval=0.25)
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
