#!/usr/bin/env bash
set -eu
agent_boot() {
    printf '%s\n' "$1"
    printf '%s\n' "$1" >&2
}
agent_boot 'boot stage=shell_enter'

if [ "$#" -ne 1 ]; then
    agent_boot 'boot stage=failed reason=invalid_port'
    exit 2
fi
case "$1" in
    ''|*[!0-9]*)
        agent_boot 'boot stage=failed reason=invalid_port'
        exit 2
        ;;
esac
# Remove leading zeroes before bounded numeric comparison; no input is logged.
AGENT_PORT="${1#"${1%%[!0]*}"}"
if [ -z "$AGENT_PORT" ] || [ "${#AGENT_PORT}" -gt 5 ]; then
    agent_boot 'boot stage=failed reason=invalid_port'
    exit 2
fi
if [ "$AGENT_PORT" -gt 65535 ]; then
    agent_boot 'boot stage=failed reason=invalid_port'
    exit 2
fi
AGENT_SCRIPT_DIR="${BASH_SOURCE[0]%/*}"
if [ "$AGENT_SCRIPT_DIR" = "${BASH_SOURCE[0]}" ]; then
    AGENT_SCRIPT_DIR=.
fi
if ! cd -- "$AGENT_SCRIPT_DIR" 2>/dev/null; then
    agent_boot 'boot stage=failed reason=working_directory_unavailable'
    exit 1
fi
export PYTHONDONTWRITEBYTECODE=1
AGENT_PYTHON=
AGENT_INTERPRETER_REASON=interpreter_unavailable
for AGENT_CANDIDATE in python3 python; do
    if command -v "$AGENT_CANDIDATE" >/dev/null 2>&1; then
        if "$AGENT_CANDIDATE" -c 'import sys; sys.exit(0 if sys.version_info >= (3, 8) else 21)' >/dev/null 2>&1; then
            AGENT_PYTHON="$AGENT_CANDIDATE"
            break
        else
            AGENT_PROBE_STATUS=$?
            if [ "$AGENT_PROBE_STATUS" -eq 21 ]; then
                AGENT_INTERPRETER_REASON=interpreter_unsupported
            fi
        fi
    fi
done
if [ -z "$AGENT_PYTHON" ]; then
    agent_boot "boot stage=failed reason=$AGENT_INTERPRETER_REASON"
    exit 127
fi
exec "$AGENT_PYTHON" -u main.py "$AGENT_PORT"
