"""Bounded battle observations; action legality is not evidence of damage or kills."""
import json
import logging
from collections import Counter

from . import VERSION
from .world import PEOPLE, WEAPONS, pos

LOG = logging.getLogger("futurewar")


class BattleDiagnostics:
    def __init__(self):
        self.last_round = None
        self.previous = {}
        self.pending_attacks = {}
        self.metrics = Counter()
        self.loss_groups = []
        self.last_report = None

    def observe(self, w, response):
        if self.last_round is not None and w.round <= self.last_round:
            return
        raw_roles = (w.raw.get("teamOur") or {}).get("roles", [])
        present = {str(r["id"]): r for r in raw_roles if isinstance(r, dict) and "id" in r}
        results = w.raw.get("lastRoundRoleActionResults") or {}
        results = {str(k): v for k, v in results.items()} if isinstance(results, dict) else {}
        feedback = {}
        for gid, controller in self.pending_attacks.items():
            value = results.get(gid) if w.round == self.last_round + 1 else None
            status = "legal" if value is True else "rejected" if value is False else "missing"
            self.metrics["attack_feedback_" + status] += 1
            feedback[gid] = {"controller": controller, "status": status}

        units = {rid: {"type": r.get("roleType"), "hp": r.get("health", 0),
                       "pos": list(pos(r)), "level": r.get("level", 1)}
                 for rid, r in w.own.items() if r.get("roleType") in PEOPLE + WEAPONS + ("station",)}
        losses, base_loss = [], 0
        for rid, before in self.previous.items():
            now = units.get(rid)
            if now is None:
                explicit = present.get(rid)
                reason = "dead" if explicit and explicit.get("health", 1) <= 0 else "absent"
                losses.append({"id": rid, "type": before["type"], "observation": reason})
            if before["type"] == "station":
                # A missing base is recorded separately; absence alone is not HP=0.
                after_hp = now["hp"] if now else present.get(rid, {}).get("health")
                if isinstance(after_hp, (int, float)):
                    base_loss += max(0, before["hp"] - after_hp)
        if losses:
            self.loss_groups.append({"observed_round": w.round, "units": losses})
            self.loss_groups = self.loss_groups[-12:]

        sent = {str(gid): str(c["controllerId"]) for gid, c in response["roleCommandMap"].items()
                if c.get("action") == "attack" and "controllerId" in c}
        self.metrics["attacks_sent"] += len(sent)
        self.pending_attacks = sent
        self.previous, self.last_round = units, w.round
        assignments = {str(rid): {"weapon_id": str(a["weapon_id"]), "pos": list(a["pos"])}
                       for rid, a in getattr(w, "defense_assignments", {}).items()}
        report = {"version": VERSION, "round": w.round, "day": w.day,
                  "night": w.night, "gold": w.gold, "units": units,
                  "assignments": assignments, "attacks_sent": sent,
                  "refuges": {str(rid): list(cell) for rid, cell in getattr(w, "defense_refuges", {}).items()},
                  "previous_attack_feedback": feedback, "base_hp_loss": base_loss,
                  "losses_observed": losses, "loss_groups": self.loss_groups,
                  "metrics": dict(self.metrics)}
        self.last_report = report
        # First-night preparation and combat need useful detail without model text.
        milestone = w.turn in (0, 59, 64, 69, 70, 129) or (w.night and (w.turn - 70) % 10 == 0)
        changed = bool(losses or base_loss or any(f["status"] == "rejected" for f in feedback.values()))
        if milestone or changed:
            try:
                LOG.info("battle %s", json.dumps(report, ensure_ascii=False, separators=(",", ":")))
            except Exception:
                pass
