"""One serialized match state; observations, not optimistic actions, are truth."""
import hashlib
import json
import logging
import re
import time
from collections import OrderedDict
from . import VERSION
from .world import World
from .validation import ACTIONS, empty_response, validate
from .diagnostics import BattleDiagnostics

LOG = logging.getLogger("futurewar")


class Engine:
    def __init__(self):
        self.identity = None
        self.last_round = -1
        self.origin = 1
        self.cache = OrderedDict()
        self.tasks = None
        self.game = None
        self.matches = 0
        self.errors = 0
        self.last_summary = None
        self.rejected_requests = 0
        self.battle = None
        self.disabled_actions = set()
        self.last_task_metrics = {}

    def _reset(self, identity, round_no):
        from .game import GameAgent
        from .tasks import TaskAgent
        self.identity = identity
        self.origin = 0 if round_no == 0 else 1
        self.last_round = -1
        self.cache.clear()
        self.tasks = TaskAgent()
        self.game = GameAgent()
        self.matches += 1
        self.errors = 0
        self.last_summary = None
        self.battle = BattleDiagnostics()
        self.disabled_actions = set()
        self.last_task_metrics = {}
        LOG.info("match_start version=%s sequence=%s side=%s", VERSION, self.matches, identity[1])

    @staticmethod
    def _identity(raw):
        our = raw.get("teamOur") or {}
        # Base health/destruction is not an identity change. The side and team ID are.
        return (str(our.get("teamId", "")), str(our.get("type", "challenger")))

    def handle(self, raw):
        if not isinstance(raw, dict):
            return self._reject("request_not_object")
        if type(raw.get("roundNo")) is not int or raw["roundNo"] < 0:
            return self._reject("roundNo_missing_or_not_nonnegative_int")
        if not isinstance(raw.get("teamOur"), dict) or not isinstance(raw.get("mapInfo"), dict):
            return self._reject("teamOur_or_mapInfo_not_object")
        if not isinstance(raw["teamOur"].get("roles"), list):
            return self._reject("teamOur_roles_not_array")
        round_no = raw["roundNo"]
        identity = self._identity(raw)
        signature = hashlib.sha256(json.dumps(raw, sort_keys=True, ensure_ascii=False, separators=(",", ":"), allow_nan=False).encode("utf-8")).hexdigest()
        # A new opening after a completed match starts a fresh match, even when
        # both starts happen to have identical observations. Process restarts are
        # the documented per-game lifecycle; this also accommodates test runners.
        restart = (identity == self.identity and round_no in (0, 1)
                   and self.last_round >= self.origin + 1299)
        if identity != self.identity or restart or self.tasks is None:
            self._reset(identity, round_no)
        if round_no in self.cache and self.cache[round_no][0] == signature:
            LOG.info("cache_hit round=%s", round_no)
            return self.cache[round_no][1]
        if round_no < self.last_round and round_no in (0, 1):
            self._reset(identity, round_no)
        if round_no in self.cache:
            LOG.warning("cache_conflict round=%s keeping_original_response=1", round_no)
            return self.cache[round_no][1]
        if round_no <= self.last_round:
            # Stale requests must never rewind the active task or daily budget.
            return self._reject("stale_round")
        started = time.monotonic()
        deadline = started + 1.0
        proposed = empty_response()
        try:
            w = World(raw, self.origin, deadline)
        except Exception as exc:
            LOG.warning("observation_rejected round=%s class=%s", round_no, type(exc).__name__)
            return self._reject("world_construction_failed")
        commands = proposed["roleCommandMap"]
        self._feedback(w)
        w.disabled_actions = set(self.disabled_actions)
        if round_no <= self.origin + 9 or not w.people:
            LOG.info("observation round=%s roles_raw=%s roles_alive=%s people=%s", round_no,
                     len(raw["teamOur"]["roles"]), len(w.own), len(w.people))
        try:
            self.game.prepare_world(w)
        except Exception as exc:
            self.errors += 1
            LOG.warning("module_error module=movement_feedback round=%s class=%s", round_no, type(exc).__name__)
        # Share the soft budget fairly: a model response can be large, but it
        # must not starve basic movement and defense of their local CPU budget.
        try:
            prompt, cmd = self.tasks.step(w, commands, min(deadline, started + 0.35))
            proposed["prompt"], proposed["executeCmd"] = prompt, cmd
        except Exception as exc:
            self.errors += 1
            LOG.warning("module_error module=tasks round=%s class=%s", round_no, type(exc).__name__)
        try:
            if not w.expired():
                held = getattr(self.tasks, "held_role", None)
                w.held_roles = {str(held)} if held is not None else set()
                self.game.market_advice = self._market_advice(getattr(self.tasks, "forecasts", []))
                self.game.step(w, commands, deadline)
            else:
                LOG.warning("budget_exhausted module=game round=%s", round_no)
        except Exception as exc:
            self.errors += 1
            LOG.warning("module_error module=game round=%s class=%s", round_no, type(exc).__name__)
        try:
            for rid in list(commands):
                if (isinstance(commands[rid], dict) and isinstance(commands[rid].get("action"), str)
                        and commands[rid]["action"] in self.disabled_actions):
                    LOG.info("action_disabled round=%s role=%s action=%s", round_no, rid, commands[rid]["action"])
                    del commands[rid]
            diagnostics = []
            response = validate(w, proposed, diagnostics)
            for item in diagnostics:
                LOG.info("action_filtered round=%s role=%s action=%s reason=%s", round_no,
                         item["role_id"], item["action"], item["reason"])
            # Validate wire serialization before putting a response in the cache.
            json.dumps(response, ensure_ascii=False, allow_nan=False)
        except Exception as exc:
            self.errors += 1
            LOG.warning("module_error module=validation round=%s class=%s", round_no, type(exc).__name__)
            response = empty_response()
        try:
            self.game.record_actions(w, response["roleCommandMap"])
        except Exception as exc:
            self.errors += 1
            LOG.warning("module_error module=record_actions round=%s class=%s", round_no, type(exc).__name__)
        self.last_round = round_no
        self.cache[round_no] = (signature, response)
        while len(self.cache) > 1301:
            self.cache.popitem(last=False)
        invalid = len(commands) - len(response["roleCommandMap"])
        if invalid:
            LOG.info("filtered round=%s count=%s", round_no, invalid)
        # A broken log sink must never invalidate a decided/cached round.
        try:
            self.battle.observe(w, response)
            self._summarize(w, response, time.monotonic() - started)
        except Exception:
            pass
        return response

    def _reject(self, reason):
        self.rejected_requests += 1
        LOG.warning("input_rejected reason=%s count=%s", reason, self.rejected_requests)
        return empty_response()

    def _feedback(self, w):
        previous = self.cache.get(w.round - 1)
        prior = previous[1]["roleCommandMap"] if previous else {}
        errors = w.raw.get("errors") or []
        if not isinstance(errors, list):
            return
        for error in errors:
            if not isinstance(error, dict):
                continue
            code = str(error.get("errorCode", ""))
            LOG.info("judge_error round=%s code=%s", w.round, code if code.isdigit() else "unknown")
            if code != "4" or not prior:
                continue
            description = str(error.get("description", ""))[:2048]
            named = {a for a in ACTIONS if re.search(r"(?<![A-Za-z])" + re.escape(a) + r"(?![A-Za-z])", description, re.I)}
            identified = {cmd["action"] for rid, cmd in prior.items()
                          if re.search(r"(?<!\d)" + re.escape(rid) + r"(?!\d)", description)}
            candidates = named.intersection({c["action"] for c in prior.values()}) or identified
            if (not candidates and len(prior) == 1 and not previous[1].get("prompt")
                    and not previous[1].get("executeCmd")):
                candidates = {next(iter(prior.values()))["action"]}
            if len(candidates) == 1:
                rejected = next(iter(candidates))
                self.disabled_actions.add(rejected)
                LOG.warning("instruction_branch_disabled round=%s action=%s", w.round, rejected)
            else:
                LOG.warning("instruction_error_unattributed round=%s", w.round)

    @staticmethod
    def _market_advice(forecasts):
        if isinstance(forecasts, dict):
            return forecasts
        advice = {}
        for item in forecasts or []:
            if isinstance(item, dict):
                key = item.get("mineral", item.get("resource", item.get("name")))
                if key in ("stone", "iron", "copper"):
                    advice.setdefault(key, []).append(item)
        return advice

    def _summarize(self, w, response, elapsed):
        phase = (w.day, w.night)
        task_metrics = dict(getattr(self.tasks, "metrics", {}))
        task_event = (bool(response["prompt"] or response["executeCmd"] or w.raw.get("llmResp")
                           or w.raw.get("lastCmdResult")) or task_metrics != self.last_task_metrics)
        if (phase == self.last_summary and w.round > self.origin + 9
                and w.round != self.origin + 1299 and response["roleCommandMap"] and not task_event):
            return
        self.last_summary = phase
        self.last_task_metrics = task_metrics
        results = w.raw.get("lastRoundRoleActionResults") or {}
        failed = sum(value is False for value in results.values()) if isinstance(results, dict) else 0
        score = (w.raw.get("teamOur") or {}).get("totalScore", 0)
        summary = {"version": VERSION, "round": w.round, "day": w.day,
                   "night": w.night, "gold": w.gold, "score": score,
                   "base_hp": w.station.get("health", 0) if w.station else 0,
                   "people": len(w.people), "weapons": len(w.weapons),
                   "actions": len(response["roleCommandMap"]), "previous_failed": failed,
                   "build_failures_today": getattr(self.game, "build_failures", 0),
                   "tasks_completed": getattr(self.tasks, "metrics", {}).get("tasks_completed", 0),
                   "attacks_sent": self.battle.metrics["attacks_sent"],
                   "attack_feedback_legal": self.battle.metrics["attack_feedback_legal"],
                   "module_errors": self.errors,
                   "llm_requested": bool(response["prompt"]), "command_requested": bool(response["executeCmd"]),
                   "llm_response_chars": len(w.raw.get("llmResp") or "") if isinstance(w.raw.get("llmResp"), str) else 0,
                   "task_metrics": task_metrics,
                   "decision_ms": round(elapsed * 1000, 2)}
        LOG.info("summary %s", json.dumps(summary, ensure_ascii=False, separators=(",", ":")))
