"""Persistent gunner assignments and conservative, unobstructed threat estimates."""
import itertools

from .world import dist, pos


def number(value, default=0):
    try:
        return max(0, float(value))
    except (TypeError, ValueError):
        return float(default)


def exposure(w, cell):
    """Potential next-turn damage, not a claim that every robot will attack.

    Buildings do not reduce this estimate: no undocumented shielding is assumed.
    A robot one step outside attack range contributes half its attack power.
    """
    total = 0.0
    defaults = {"smallRobot": 5, "middleRobot": 10, "largeRobot": 20, "bossRobot": 40}
    for robot in w.robots:
        if robot.get("abnormalState") == "dizzy":
            continue
        reach = number(robot.get("attackRange"), 3)
        power = number(robot.get("attackPower"), defaults.get(robot.get("roleType"), 10))
        distance = dist(robot, cell)
        if distance <= reach:
            total += power
        elif distance <= reach + 1:
            total += power * 0.5
    return total


def coverage(w, gun):
    kind = gun.get("roleType")
    level = max(1, min(3, int(number(gun.get("level"), 1))))
    ranges = {"railgun": (6, 8, 10), "rocket": (10, 15, 1000), "gatling": (3, 5, 7)}
    reach = number(gun.get("attackRange"), ranges[kind][level - 1])
    power = number(gun.get("attackPower"), 10 * level if kind == "railgun" else 20 if kind == "rocket" else 10)
    targets = sum(min(number(robot.get("health"), 1), power)
                  for robot in w.robots if dist(gun, robot) <= reach)
    return targets / (1 + number(gun.get("cooldown")))


class DefensePlanner:
    def __init__(self):
        self.assignments = {}
        self.blocked = {}
        self.refuges = {}
        self.round = None

    def prepare(self, w):
        if self.round == w.round:
            w.defense_assignments = {rid: dict(value) for rid, value in self.assignments.items()}
            w.defense_refuges = dict(self.refuges)
            return
        self.round = w.round
        previous = self.assignments
        people, guns = list(w.people), list(w.weapons)
        by_gun = {str(gun["id"]): gun for gun in guns}
        # A short-lived actor blockage may clear; repeated blockage loses its
        # retained-position preference and triggers a different slot assignment.
        for person in people:
            rid = str(person["id"])
            old = previous.get(rid)
            route = w.route(person, {old["pos"]}) if old and old["weapon_id"] in by_gun else None
            self.blocked[rid] = self.blocked.get(rid, 0) + 1 if route and route.status == "blocked" else 0
        options = {}
        for person in people:
            rid, current = str(person["id"]), pos(person)
            health = max(1, number(person.get("health"), 1))
            for gun in guns:
                gid = str(gun["id"])
                choices = []
                for cell in sorted(w.adjacent(gun)):
                    if w.expired():
                        break
                    if cell in w.occupied and cell != current:
                        continue
                    old = previous.get(rid)
                    same = bool(old and old["weapon_id"] == gid and old["pos"] == cell)
                    if same and self.blocked.get(rid, 0) >= 3:
                        continue
                    route = w.route(person, {cell}, reserved=w.move_avoid.get(rid, set()))
                    if route.distance is None:
                        continue
                    first = route.steps[0] if route.steps else current
                    immediate, future = exposure(w, first), exposure(w, cell)
                    # A route's first step changes as actors travel. Using that
                    # transient exposure in the aggregate assignment score can
                    # make two safe gunners exchange guns and reverse forever.
                    # Keep it in the lethal-step guard, but compare sustained
                    # exposure at the destination before retaining assignments.
                    damage = future
                    # The objective order is safety, fire coverage, retention,
                    # then travel cost. Current safe control cells cost no move.
                    score = (int(max(immediate, future) >= health), damage, -coverage(w, gun),
                             -int(same), route.distance + (2 if not route.reachable else 0))
                    choices.append((score, cell))
                if choices:
                    options[(rid, gid)] = sorted(choices)
        best, best_key = {}, (0, 0, 0, 0, 0, 0)
        # At most three people, three guns and eight cells per gun. Enumerating
        # these small assignments avoids greedy collisions between control cells.
        for size in range(min(len(people), len(guns)), 0, -1):
            for selected in itertools.combinations(people, size):
                for ordered_guns in itertools.permutations(guns, size):
                    keys = [(str(p["id"]), str(g["id"])) for p, g in zip(selected, ordered_guns)]
                    if any(key not in options for key in keys):
                        continue
                    for choices in itertools.product(*(options[key] for key in keys)):
                        if w.expired():
                            break
                        cells = [choice[1] for choice in choices]
                        if len(set(cells)) != size:
                            continue
                        sums = tuple(sum(choice[0][i] for choice in choices) for i in range(5))
                        score = (sums[0], -size) + sums[1:]
                        if score < best_key:
                            best_key = score
                            best = {rid: {"weapon_id": gid, "pos": cell}
                                    for (rid, gid), cell in zip(keys, cells)}
            if w.expired():
                break
        if not best and w.expired():
            # Keep known assignments when planning runs out of its CPU budget.
            best = {rid: dict(value) for rid, value in previous.items()
                    if rid in w.own and value["weapon_id"] in by_gun
                    and value["pos"] in w.adjacent(by_gun[value["weapon_id"]])
                    and exposure(w, value["pos"]) < number(w.own[rid].get("health"), 1)}
        self.assignments = best
        self.refuges = {}
        reserved = {value["pos"] for value in best.values()}
        for person in people:
            rid, current = str(person["id"]), pos(person)
            if rid in best or not w.robots:
                continue
            choices = []
            # An unassigned endangered gunner retreats locally; it must not be
            # pulled back toward an unsafe gun by the ordinary base fallback.
            for x in range(max(0, current[0] - 3), min(w.width, current[0] + 4)):
                for y in range(max(0, current[1] - 3), min(w.height, current[1] + 4)):
                    cell = (x, y)
                    if w.expired() or cell in reserved or cell in w.occupied and cell != current:
                        continue
                    route = w.route(person, {cell}, reserved=reserved)
                    if not route.reachable:
                        continue
                    first = route.steps[0] if route.steps else current
                    immediate, future = exposure(w, first), exposure(w, cell)
                    score = (max(immediate, future) >= number(person.get("health"), 1),
                             immediate + future * 0.5, route.distance, cell)
                    choices.append((score, cell))
            target = min(choices)[1] if choices else current
            self.refuges[rid] = target
            reserved.add(target)
        w.defense_assignments = {rid: dict(value) for rid, value in best.items()}
        w.defense_refuges = dict(self.refuges)
