# 《未来战争》Agent v0.4

沿用已由 v0.3 平台试跑验证成功的 SDK 结构：**包内顶层是 CoreGeek/，Python 入口是 CoreGeek/main3.py**。用户反馈 v0.3 已有动作、得分且三座武器建成，但对战在第 101 回合结束。v0.4 集中改进首夜生存；是否进入第二天仍需新版本试跑确认。

## 提交包

上传 agent_demo/dist/submission-v0.4.tar.gz。包内不要再套 SDK、python3sdk 或 agent_demo 目录，也不要把 CoreGeek 内的文件平铺到包根目录。

```text
submission-v0.4.tar.gz
└── CoreGeek/
    ├── main3.py       # SDK Python 入口
    ├── main.py        # HTTP 实现及兼容入口
    ├── run.sh         # 启动辅助脚本
    ├── VERSION
    ├── README.md
    └── agent/
        ├── __init__.py
        ├── sdk.py     # 共享 Engine、callback、app
        └── ...        # 比赛决策模块
```

包内没有比赛资料、日志、测试工具或第三方安装包。运行时使用包内版本常量，打包器核对它与 VERSION 文件相同。归档采用 UTF-8/LF，run.sh 的 TAR 权限为 0755。每版同时生成 ZIP、manifest 和 SHA256SUMS，历史包不会被覆盖。

解压后可从 SDK 所在层级运行：

```bash
python3 CoreGeek/main3.py 8080
# 同一个服务的辅助启动方式：
bash CoreGeek/run.sh 8080
```

端口必须使用平台传入的参数，服务绑定 0.0.0.0，不固定使用对手日志里的 6666。

## 平台交互

平台主动向服务发送 POST /，正文是含 roundNo、mapInfo、teamOur 等字段的状态 JSON。SDK 的 callback 处理该对象并返回命令，HTTP 响应直接包含：

```json
{"roleCommandMap": {}, "prompt": "", "executeCmd": ""}
```

空对象只表示结构；正常状态下会填入角色动作。无需增加 data、command 等包装层。动作通过 HTTP 响应返回，stdout/stderr 用于诊断。prompt 和 executeCmd 交给平台模型和任务沙盒执行，下一回合读取 llmResp 和 lastCmdResult；程序不需要模型密钥，也不在本机执行模型给出的命令。

main3.py 和 main.py 都公开 callback，并可通过 module.app 获取同一个 WSGI 应用。环境已有 Flask 时使用 SDK 同样的 request.get_json → callback → jsonify 路由；没有 Flask 时提供标准 WSGI callable。直接运行脚本和 run.sh 使用标准库 HTTP 服务，**没有强制第三方运行依赖，不会在启动时联网安装**。导入模块、获取 app 不会自动监听；各入口共享一个 Engine 和互斥锁。

## 首夜生存策略

首回合直接执行正常经济和任务计划，不再等待单个工人的试探移动。保留两座电磁炮和一座火箭台；三炮建成后统一分配操作者与站位，采矿、任务和防守按同一战位计算返程，预留五回合。死亡、持续受阻和危险站位会触发调整；站位风险采用可见机器人攻击范围、攻击力和角色血量，不假设建筑能挡住机器人攻击。

三炮建齐后首笔升级资金优先用于基地二级，然后提升火箭和电磁炮；商店实际价格优先。宝藏采购需扣除尚未完成的防守预算。夜间基地低于半血时，相邻且持有适用升级券的角色可以使用券恢复基地生命，该角色当回合不能同时操炮；夜间不派人远行买券。以上是生存基线，并非已证明最强的组合。

## 诊断

- 脚本进入：boot stage=shell_enter。
- Python 脚本进入：boot stage=python_enter；模块导入：boot stage=module_import。
- 标准服务输出 agent_imported、listening；前三次 TCP 输出 connection ... accepted，前三次 POST 输出 received/parsed/decided/written。
- 公开 callback 使用独立 callback 标记，app 初始化记录 flask 或 wsgi 后端。
- battle 记录备战节点、夜间每十回合及基地受伤/单位消失事件，包含炮手位置和血量、武器等级、分配战位、攻击操作者及上一回合反馈。attacks_sent 仅表示发出了动作，attack_feedback_legal 仅表示判题器返回合法，不能视作命中或击杀。
- 同回合观察到的死亡或消失作为一组记录，不猜测组内先后；缺少下一回合反馈记作 missing，不默认为成功。

标记同时写入 stdout/stderr，不含来源地址、URL、题面、新闻或模型内容。合并双流时可能重复。完全没有标记仍需核对入口执行和日志采集，不能据此唯一确定某种网络错误。FUTUREWAR_LOG 可选指定额外日志文件；目录不可写不影响响应。

## 开发与验证

源码继续在 agent_demo/，打包时映射到 CoreGeek/，不建立第二份开发代码。从 agent_demo 执行：

```bash
python -B -m unittest discover -s tests -v
python -B tools/package.py
python -B tools/probe_sdk_entrypoints.py --archive dist/submission-v0.4.tar.gz
python -B tools/smoke_package.py --archive dist/submission-v0.4.tar.gz
```

入口探测从实际归档的 CoreGeek 目录验证：双 callback、直接 main3.py、纯标准库 WSGI、Flask WSGI。Flask 分支测试使用 tools/.sdk-test-deps 中的独立测试依赖，不加入提交包。原 SDK 对照工具 tools/probe_original_sdk.py 只修改临时副本，原始资料保留。

smoke 验证实际包的含空格路径、不同工作目录、随机端口、1300 回合 HTTP 及双方共 200 回合的有限动作场景；夜间场景延长至第 90 回合，检查安全到位后电磁炮持续开火，避免炮手反复换位。建造区、矿产刷新和机器人目标是测试数据，不等于官方比赛模拟。各项结果以 dist 中对应版本报告为准。

本地环境为 Windows / Python 3.14.6 / Git Bash，目标 Linux / Python 3.11.10 尚未在本机实测。v0.3 已由用户确认平台接入成功，后续沿用该提交结构；v0.4 的生存表现仍以平台回放为准。原始比赛资料、旧日志及历史包保留不变。
