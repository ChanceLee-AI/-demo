"""One serialized match state; observations, not optimistic actions, are truth."""
import hashlib
import json
import logging
import time
from collections import OrderedDict
from . import VERSION
from .world import World
from .validation import empty_response, validate

LOG = logging.getLogger("futurewar")


class Engine:
    def __init__(self):
        self.identity = None
        self.last_round = -1
        self.origin = 1
        self.cache = OrderedDict()
        self.tasks = None
        self.game = None
        self.matches = 0
        self.errors = 0
        self.last_summary = None

    def _reset(self, identity, round_no):
        from .game import GameAgent
        from .tasks import TaskAgent
        self.identity = identity
        self.origin = 0 if round_no == 0 else 1
        self.last_round = -1
        self.cache.clear()
        self.tasks = TaskAgent()
        self.game = GameAgent()
        self.matches += 1
        self.errors = 0
        self.last_summary = None
        LOG.info("match_start version=%s sequence=%s side=%s", VERSION, self.matches, identity[1])

    @staticmethod
    def _identity(raw):
        our = raw.get("teamOur") or {}
        # Base health/destruction is not an identity change. The side and team ID are.
        return (str(our.get("teamId", "")), str(our.get("type", "challenger")))

    def handle(self, raw):
        if not isinstance(raw, dict) or type(raw.get("roundNo")) is not int or raw["roundNo"] < 0:
            return empty_response()
        if not isinstance(raw.get("teamOur"), dict) or not isinstance(raw.get("mapInfo"), dict):
            return empty_response()
        round_no = raw["roundNo"]
        identity = self._identity(raw)
        signature = hashlib.sha256(json.dumps(raw, sort_keys=True, ensure_ascii=False, separators=(",", ":"), allow_nan=False).encode("utf-8")).hexdigest()
        # A new opening after a completed match starts a fresh match, even when
        # both starts happen to have identical observations. Process restarts are
        # the documented per-game lifecycle; this also accommodates test runners.
        restart = (identity == self.identity and round_no in (0, 1)
                   and self.last_round >= self.origin + 1299)
        if identity != self.identity or restart or self.tasks is None:
            self._reset(identity, round_no)
        if round_no in self.cache and self.cache[round_no][0] == signature:
            return self.cache[round_no][1]
        if round_no < self.last_round and round_no in (0, 1):
            self._reset(identity, round_no)
        if round_no in self.cache:
            return self.cache[round_no][1]
        if round_no <= self.last_round:
            # Stale requests must never rewind the active task or daily budget.
            return empty_response()
        started = time.monotonic()
        deadline = started + 1.0
        proposed = empty_response()
        try:
            w = World(raw, self.origin, deadline)
        except Exception as exc:
            LOG.warning("observation_rejected round=%s class=%s", round_no, type(exc).__name__)
            return empty_response()
        commands = proposed["roleCommandMap"]
        # Share the soft budget fairly: a model response can be large, but it
        # must not starve basic movement and defense of their local CPU budget.
        try:
            prompt, cmd = self.tasks.step(w, commands, min(deadline, started + 0.35))
            proposed["prompt"], proposed["executeCmd"] = prompt, cmd
        except Exception as exc:
            self.errors += 1
            LOG.warning("module_error module=tasks round=%s class=%s", round_no, type(exc).__name__)
        try:
            if not w.expired():
                held = getattr(self.tasks, "held_role", None)
                w.held_roles = {str(held)} if held is not None else set()
                self.game.market_advice = self._market_advice(getattr(self.tasks, "forecasts", []))
                self.game.step(w, commands, deadline)
        except Exception as exc:
            self.errors += 1
            LOG.warning("module_error module=game round=%s class=%s", round_no, type(exc).__name__)
        try:
            response = validate(w, proposed)
            # Validate wire serialization before putting a response in the cache.
            json.dumps(response, ensure_ascii=False, allow_nan=False)
        except Exception as exc:
            self.errors += 1
            LOG.warning("module_error module=validation round=%s class=%s", round_no, type(exc).__name__)
            response = empty_response()
        self.last_round = round_no
        self.cache[round_no] = (signature, response)
        while len(self.cache) > 1301:
            self.cache.popitem(last=False)
        invalid = len(commands) - len(response["roleCommandMap"])
        if invalid:
            LOG.info("filtered round=%s count=%s", round_no, invalid)
        self._summarize(w, response, time.monotonic() - started)
        return response

    @staticmethod
    def _market_advice(forecasts):
        if isinstance(forecasts, dict):
            return forecasts
        advice = {}
        for item in forecasts or []:
            if isinstance(item, dict):
                key = item.get("mineral", item.get("resource", item.get("name")))
                if key in ("stone", "iron", "copper"):
                    advice.setdefault(key, []).append(item)
        return advice

    def _summarize(self, w, response, elapsed):
        phase = (w.day, w.night)
        if phase == self.last_summary and w.round != self.origin + 1299:
            return
        self.last_summary = phase
        results = w.raw.get("lastRoundRoleActionResults") or {}
        failed = sum(value is False for value in results.values())
        score = (w.raw.get("teamOur") or {}).get("totalScore", 0)
        summary = {"version": VERSION, "round": w.round, "day": w.day,
                   "night": w.night, "gold": w.gold, "score": score,
                   "base_hp": w.station.get("health", 0) if w.station else 0,
                   "people": len(w.people), "weapons": len(w.weapons),
                   "actions": len(response["roleCommandMap"]), "previous_failed": failed,
                   "build_failures_today": getattr(self.game, "build_failures", 0),
                   "tasks_completed": getattr(self.tasks, "metrics", {}).get("tasks_completed", 0),
                   "attacks_total": getattr(self.game, "stats", {}).get("attacks", 0),
                   "module_errors": self.errors, "decision_ms": round(elapsed * 1000, 2)}
        LOG.info("summary %s", json.dumps(summary, ensure_ascii=False, separators=(",", ":")))
