"""Final wire and action/resource validation, independent of strategy modules."""
from collections import Counter
from .world import PEOPLE, WEAPONS, pos, dist

SUMMONS = {"SmallRobotSummonOrder", "MiddleRobotSummonOrder", "LargeRobotSummonOrder", "BossRobotSummonOrder"}
TARGETED = {"move", "attack", "build", "remove", "collect", "summonTreasure"}
NAMES = {"build", "buy", "sell", "use", "drop"}
ACTIONS = TARGETED | NAMES | {"acceptTask", "submitAnswer"}


def empty_response():
    return {"roleCommandMap": {}, "prompt": "", "executeCmd": ""}


def validate(w, proposed):
    result = empty_response()
    commands = proposed.get("roleCommandMap", {})
    if not isinstance(commands, dict):
        commands = {}
    used, destinations = set(), set()
    gold = w.gold
    weapon_count = len(w.weapons)
    for identifier, source in commands.items():
        try:
            rid = str(identifier)
            actor = w.own.get(rid)
            if not actor or rid in used or not isinstance(source, dict):
                continue
            name = source.get("action")
            if name not in ACTIONS:
                continue
            kind = actor.get("roleType")
            if name != "attack" and kind not in PEOPLE:
                continue
            command = {"action": name}
            targets = source.get("targetPos", [])
            if not isinstance(targets, list):
                continue
            if any(not isinstance(p, dict) or type(p.get("x")) is not int or type(p.get("y")) is not int for p in targets):
                continue
            cells = [pos(p) for p in targets]
            if any(not w.in_bounds(p) for p in cells):
                continue
            if name in TARGETED and not cells:
                continue
            if name != "attack" and len(cells) > 1:
                continue
            if cells:
                command["targetPos"] = [{"x": p[0], "y": p[1]} for p in cells]
            item = source.get("name")
            if name in NAMES:
                if not isinstance(item, str) or not item:
                    continue
                command["name"] = item
            bag = Counter(actor.get("backpack") or [])
            consume = {rid}
            spend = 0
            reservation = None
            if name == "attack":
                controller = str(source.get("controllerId", ""))
                person = w.own.get(controller)
                level = min(3, max(1, int(actor.get("level", 1))))
                count = 1 if kind == "railgun" else level
                if (kind not in WEAPONS or not w.night or len(cells) != count
                        or not person or person.get("roleType") not in PEOPLE
                        or controller in used or not w.near(person, actor)
                        or int(actor.get("cooldown", 0)) > 0
                        or any(dist(actor, p) > int(actor["attackRange"]) for p in cells)):
                    continue
                if kind == "gatling":
                    x, y = pos(actor)
                    vectors = [(px - x, py - y) for px, py in cells]
                    if any(ax * bx + ay * by < 0 for ax, ay in vectors for bx, by in vectors):
                        continue
                command["controllerId"] = controller
                consume.add(controller)
            elif name == "move":
                if dist(actor, cells[0]) != 1 or cells[0] in w.occupied or cells[0] in destinations:
                    continue
                reservation = cells[0]
            elif name == "build":
                if (kind != "worker" or w.night or item not in WEAPONS + ("wall",)
                        or not w.near(actor, cells[0]) or cells[0] in w.occupied or cells[0] in destinations):
                    continue
                if item == "wall":
                    if bag["stone"] < 1:
                        continue
                else:
                    if weapon_count >= 3:
                        continue
                    spend = 25
                reservation = cells[0]
            elif name == "collect":
                if kind != "worker" or not w.near(actor, cells[0]):
                    continue
                if not any(pos(z) == cells[0] and z.get("neutralType") in ("stone", "iron", "copper") for z in w.zones):
                    continue
                if sum(bag.values()) >= int(actor.get("backPackCapability", 100)):
                    continue
            elif name in ("buy", "sell"):
                count = source.get("num", 1)
                if type(count) is not int or count <= 0:
                    continue
                zone_type = "weaponShop" if name == "buy" else "vendor"
                if not any(z.get("neutralType") == zone_type and w.near(actor, z) for z in w.zones):
                    continue
                command["num"] = count
                if name == "buy":
                    if item not in w.shop or item in SUMMONS:
                        continue
                    if sum(bag.values()) + count > int(actor.get("backPackCapability", 40 if kind == "pioneer" else 100)):
                        continue
                    spend = w.shop[item] * count
                elif item not in w.prices or bag[item] < count:
                    continue
                # Do not spend income that will only arrive at turn settlement.
            elif name == "remove":
                if kind != "worker" or not w.near(actor, cells[0]):
                    continue
                if not any(r.get("roleType") == "wall" and pos(r) == cells[0] for r in w.own.values()):
                    continue
            elif name in ("acceptTask", "submitAnswer", "summonTreasure"):
                if kind != "pioneer":
                    continue
                task_zones = [z for z in w.zones if str(z.get("neutralType", "")).startswith(w.team_type + "TaskPoint")]
                if name in ("acceptTask", "submitAnswer"):
                    if not any(w.near(actor, z) for z in task_zones):
                        continue
                    if name == "acceptTask" and w.raw.get("phaseTask"):
                        continue
                    if name == "submitAnswer":
                        answer = source.get("taskAnswer")
                        if not w.raw.get("phaseTask") or not isinstance(answer, str) or not answer.strip():
                            continue
                        command["taskAnswer"] = answer
                else:
                    sacrifice = source.get("item")
                    if not isinstance(sacrifice, list) or not all(isinstance(s, str) and s for s in sacrifice):
                        continue
                    if not w.near(actor, cells[0]) or Counter(sacrifice) - bag:
                        continue
                    command["item"] = sacrifice
            elif name in ("use", "drop"):
                if bag[item] < 1 or item in SUMMONS:
                    continue
                if name == "use":
                    if "UpgradeVoucher" in item or item == "WallFixer":
                        if len(cells) != 1:
                            continue
                        building = next((r for r in w.own.values() if cells[0] in w.footprint(r) and r.get("roleType") not in PEOPLE), None)
                        if not building or not w.near(actor, building):
                            continue
                        expected = ("station",) if item.startswith("Station") else (("wall",) if item.startswith("Wall") else WEAPONS)
                        if building.get("roleType") not in expected:
                            continue
                        if "UpgradeVoucher" in item and int(building.get("level", 1)) != int(item[-1]):
                            continue
                    elif item in ("Bomb", "DizzyWeapon"):
                        if len(cells) != 1:
                            continue
                    elif item not in ("Medicine", "medicine"):
                        continue
            if spend > gold:
                continue
            gold -= spend
            if name == "build" and item in WEAPONS:
                weapon_count += 1
            if reservation is not None:
                destinations.add(reservation)
            used.update(consume)
            result["roleCommandMap"][rid] = command
        except (ValueError, KeyError, TypeError, IndexError, OverflowError):
            continue
    prompt = proposed.get("prompt", "")
    cmd = proposed.get("executeCmd", "")
    result["prompt"] = prompt if isinstance(prompt, str) else ""
    task_zones = [z for z in w.zones if str(z.get("neutralType", "")).startswith(w.team_type + "TaskPoint")]
    active = bool(w.raw.get("phaseTask") and w.pioneer and any(w.near(w.pioneer, z) for z in task_zones))
    result["executeCmd"] = cmd if active and isinstance(cmd, str) else ""
    return result
