"""Deterministic economy and defence. No network or sandbox execution occurs here."""
import itertools
from collections import Counter

from .world import action, dist, pos


MINERALS = ("stone", "iron", "copper")
WEAPONS = ("railgun", "rocket", "gatling")
BUILD_ORDER = ("railgun", "railgun", "rocket")


def level(unit):
    try:
        return max(1, min(3, int(str(unit.get("level", 1)).replace("level", ""))))
    except (ValueError, TypeError):
        return 1


def ray_cells(start, end):
    """Cells crossed by the centre-to-centre segment, excluding the origin.

    A line merely touching a cell corner does not enter that cell. Keeping this
    discretisation isolated makes it easy to adapt to a judge's ray convention.
    """
    x, y = pos(start)
    ex, ey = pos(end)
    dx, dy = ex - x, ey - y
    sx, sy = (1 if dx > 0 else -1), (1 if dy > 0 else -1)
    tx = 0.5 / abs(dx) if dx else float("inf")
    ty = 0.5 / abs(dy) if dy else float("inf")
    ix = 1.0 / abs(dx) if dx else float("inf")
    iy = 1.0 / abs(dy) if dy else float("inf")
    cells = []
    while (x, y) != (ex, ey):
        if abs(tx - ty) < 1e-10:
            x, y, tx, ty = x + sx, y + sy, tx + ix, ty + iy
        elif tx < ty:
            x, tx = x + sx, tx + ix
        else:
            y, ty = y + sy, ty + iy
        cells.append((x, y))
    return cells


def same_cone(origin, targets):
    """Every pair of gatling directions must form an angle of at most 90 deg."""
    ox, oy = pos(origin)
    vectors = [(x - ox, y - oy) for x, y in targets]
    return all(ax * bx + ay * by >= 0
               for (ax, ay), (bx, by) in itertools.combinations(vectors, 2))


def _used(commands):
    return set(str(k) for k in commands) | {
        str(c["controllerId"]) for c in commands.values() if c.get("controllerId") is not None
    }


class GameAgent:
    def __init__(self):
        self.build_pending = None
        self.build_invalid = {kind: set() for kind in WEAPONS + ("wall",)}
        self.build_success = []
        self.build_disabled = False
        self.build_day = None
        self.build_failures = 0
        self.build_goal = None
        self.upgrade_plan = None
        self.last_shot = {}
        self.collect_pending = {}
        self.mine_blocked_until = {}
        self.market_advice = {}
        self.held_roles = set()
        self.stats = Counter()

    def step(self, w, commands, deadline=None):
        """Add actions, preserving actions and controllers already assigned by tasks."""
        self.held_roles = {str(rid) for rid in getattr(w, "held_roles", set())}
        self._observe(w)
        if w.expired():
            return
        budget = w.gold
        for c in commands.values():
            if c.get("action") == "buy":
                budget -= w.shop.get(c.get("name"), 0) * c.get("num", 1)
            elif c.get("action") == "build" and c.get("name") in WEAPONS:
                budget -= 25
        budget = max(0, budget)
        if w.night:
            self._defend(w, commands)
            return
        # Return decisions precede new journeys, so economic work cannot strand a gunner.
        returning = [p for p in w.people if str(p["id"]) not in _used(commands) | self.held_roles
                     and w.daylight_left <= w.return_distance(p) + 3]
        self._defend(w, commands, returning)
        used = _used(commands) | self.held_roles | {str(p["id"]) for p in returning}
        available = [p for p in w.workers if str(p["id"]) not in used]
        # One worker carries upgrade vouchers; the other keeps the economy running.
        if available and not w.expired():
            upgrader, spent = self._upgrade(w, commands, available, budget)
            budget -= spent
            if upgrader is not None:
                available = [p for p in available if str(p["id"]) != upgrader]
        if available and not w.expired():
            builder = min(available, key=lambda p: dist(p, w.station) if w.station else 0)
            spent = self._build(w, commands, builder, budget)
            budget -= max(0, spent)
            if str(builder["id"]) in commands:
                available = [p for p in available if p is not builder]
        for worker in available:
            if w.expired():
                break
            self._economy(w, commands, worker)
        # A task-free pioneer waits near the defences rather than obstructing trade.
        if w.pioneer and str(w.pioneer["id"]) not in _used(commands) | self.held_roles:
            self._defend(w, commands, [w.pioneer])

    def _observe(self, w):
        if self.build_day != w.day:
            self.build_day, self.build_failures = w.day, 0
        pending = self.build_pending
        if pending and w.round > pending["round"]:
            self.build_pending = None
            success = any(p.get("roleType") == pending["kind"] and pos(p) == pending["pos"]
                          for p in w.own.values())
            if success:
                self.build_success.append(pending["pos"])
                self.stats["build_success"] += 1
            else:
                self.build_invalid[pending["kind"]].add(pending["pos"])
                self.build_failures += 1
                self.stats["build_failed"] += 1
                errors = w.raw.get("errors", []) or []
                results = w.raw.get("lastRoundRoleActionResults", {}) or {}
                for err in errors:
                    if str(err.get("errorCode")) != "4":
                        continue
                    description = str(err.get("description", ""))
                    if ("build" in description.lower() or "建造" in description
                            or pending["role"] in description
                            or results.get(pending["role"]) is False):
                        self.build_disabled = True
                        self.stats["build_disabled_after_instruction_error"] += 1
            self.build_goal = None
        for rid, record in list(self.collect_pending.items()):
            if w.round <= record["round"]:
                continue
            role = w.own.get(rid)
            if role and Counter(role.get("backpack", []))[record["kind"]] <= record["count"]:
                self.mine_blocked_until[record["pos"]] = w.round + 5
            del self.collect_pending[rid]

    def _put_move(self, w, commands, role, goals):
        command = w.move_toward(role, goals, commands)
        if command:
            commands[str(role["id"])] = command
            return True
        return False

    def _build(self, w, commands, worker, budget):
        if (not w.station or self.build_disabled or self.build_failures >= 12
                or self.build_pending or w.daylight_left < 6):
            return 0
        counts = Counter(p.get("roleType") for p in w.weapons)
        desired = Counter(BUILD_ORDER)
        kind = next((k for k in BUILD_ORDER if counts[k] < desired[k]), None)
        if len(w.weapons) >= 3:
            kind = None
        if kind and budget < 25:
            return 0
        if not kind:
            walls = [p for p in w.own.values() if p.get("roleType") == "wall"]
            if len(w.weapons) < 3 or len(walls) >= 2 or w.day < 2:
                return 0
            if "stone" not in worker.get("backpack", []):
                return 0
            kind = "wall"
        goal = self.build_goal
        if (not goal or goal[0] != str(worker["id"]) or goal[1] != kind
                or goal[2] in w.occupied or goal[2] in self.build_invalid[kind]):
            goal = None
            candidates = self._build_candidates(w, worker, kind)
            for candidate in candidates:
                if w.expired():
                    break
                goals = w.adjacent({"pos": {"x": candidate[0], "y": candidate[1]}})
                route = w.path(worker, goals)
                if route is not None and len(route) + w.return_distance(worker) + 4 < w.daylight_left:
                    if kind == "wall" and not self._wall_keeps_paths(w, candidate):
                        continue
                    goal = (str(worker["id"]), kind, candidate)
                    break
            self.build_goal = goal
        if not goal:
            return 0
        candidate = goal[2]
        if dist(worker, candidate) <= 1:
            commands[str(worker["id"])] = action("build", candidate, name=kind)
            self.build_pending = {"role": str(worker["id"]), "kind": kind,
                                  "pos": candidate, "round": w.round}
            return 0 if kind == "wall" else 25
        self._put_move(w, commands, worker, w.adjacent(candidate))
        return 0

    def _build_candidates(self, w, worker, kind):
        footprint = w.footprint(w.station)
        sx, sy = pos(w.station)
        candidates = []
        for x in range(max(0, sx - 6), min(w.width, sx + 8)):
            for y in range(max(0, sy - 7), min(w.height, sy + 7)):
                cell = (x, y)
                ring = min(dist(cell, p) for p in footprint)
                if cell in w.occupied or cell in self.build_invalid[kind]:
                    continue
                if not (1 <= ring <= 6) or (kind == "wall" and ring < 3):
                    continue
                candidates.append(cell)
        # Sample offsets only order probes; no cell is assumed to be legally buildable.
        sample_offsets = [(sx - 1, sy), (sx, sy + 1), (sx - 1, sy + 1)]
        def score(cell):
            ring = min(dist(cell, p) for p in footprint)
            if kind != "wall":
                hint = sample_offsets.index(cell) - 3 if cell in sample_offsets else 0
                successful = min((dist(cell, p) for p in self.build_success), default=2)
                return (ring, hint, successful, dist(worker, cell), cell)
            return (ring, dist(cell, (w.width // 2, w.height // 2)), dist(worker, cell), cell)
        return sorted(candidates, key=score)

    def _wall_keeps_paths(self, w, candidate):
        exits = set()
        for zone in w.zones:
            if zone.get("neutralType") in ("vendor", "weaponShop"):
                exits.update(w.adjacent(zone))
        if not exits:
            return False
        # Reserve the future wall while checking routes from all living characters.
        for role in w.people:
            if w.expired() or w.path(role, exits, reserved={candidate}) is None:
                return False
        base_cells = w.adjacent(w.station) - {candidate}
        if not base_cells:
            return False
        return any(w.path(cell, exits, reserved={candidate}) is not None
                   for cell in sorted(base_cells)[:8] if cell not in w.occupied)

    def _upgrade_candidates(self, w):
        station = w.station
        weapons = sorted([p for p in w.weapons if level(p) < 3],
                         key=lambda p: (level(p), p.get("roleType") != "rocket", str(p["id"])))
        candidates = []
        if station and level(station) < 3:
            max_health = 1500 * level(station)
            if station.get("health", max_health) < max_health / 2:
                candidates.append(station)
        candidates += [p for p in weapons if level(p) == 1]
        if station and level(station) == 1:
            candidates.append(station)
        candidates += [p for p in weapons if level(p) == 2]
        if station and level(station) == 2:
            candidates.append(station)
        seen = set()
        unique = []
        for target in candidates:
            if str(target["id"]) not in seen:
                seen.add(str(target["id"]))
                prefix = "Station" if target.get("roleType") == "station" else "Weapon"
                unique.append((target, prefix + "UpgradeVoucher" + str(level(target))))
        return unique

    def _upgrade(self, w, commands, workers, budget):
        candidates = self._upgrade_candidates(w)
        by_id = {str(p["id"]): p for p in workers}
        # Existing vouchers take precedence, including those retained after a death.
        for target, name in candidates:
            carriers = [p for p in workers if name in p.get("backpack", [])]
            if carriers:
                carrier = min(carriers, key=lambda p: dist(p, target))
                if w.near(carrier, target):
                    commands[str(carrier["id"])] = action("use", pos(target), name=name)
                else:
                    self._put_move(w, commands, carrier, w.adjacent(target))
                self.upgrade_plan = None
                return str(carrier["id"]), 0
        # Reserve the first three guns' construction cost unless the base is critical.
        critical = (w.station and w.station.get("health", 1500) < 750 * level(w.station))
        reserve = 0 if critical else max(0, 3 - len(w.weapons)) * 25
        shops = [z for z in w.zones if z.get("neutralType") == "weaponShop"]
        if not shops:
            return None, 0
        options = {(str(t["id"]), n): t for t, n in candidates}
        if self.upgrade_plan:
            rid, tid, name = self.upgrade_plan
            if rid not in by_id or (tid, name) not in options:
                self.upgrade_plan = None
        if not self.upgrade_plan:
            for target, name in candidates:
                price = w.shop.get(name, 100 if level(target) == 1 else 150)
                # Do not buy another voucher when a currently unavailable character carries it.
                if any(name in p.get("backpack", []) for p in w.people):
                    continue
                if price <= budget - reserve:
                    selected = min(workers, key=lambda p: min(dist(p, z) for z in shops))
                    self.upgrade_plan = (str(selected["id"]), str(target["id"]), name)
                    break
        if not self.upgrade_plan:
            return None, 0
        rid, tid, name = self.upgrade_plan
        role, target = by_id[rid], options[(tid, name)]
        price = w.shop.get(name, 100 if level(target) == 1 else 150)
        if price > budget - reserve or len(role.get("backpack", [])) >= role.get("backPackCapability", 100):
            self.upgrade_plan = None
            return None, 0
        shop = min(shops, key=lambda z: dist(role, z))
        outbound = w.path(role, w.adjacent(shop))
        homeward = w.path(pos(shop), w.adjacent(target))
        if outbound is None or homeward is None or len(outbound) + len(homeward) + 5 >= w.daylight_left:
            return None, 0
        if w.near(role, shop):
            commands[rid] = action("buy", name=name, num=1)
            return rid, price
        self._put_move(w, commands, role, w.adjacent(shop))
        return rid, price  # Reserve funds during the journey, too.

    def _economy(self, w, commands, worker):
        rid = str(worker["id"])
        stock = Counter(worker.get("backpack", []))
        quantity = sum(stock[k] for k in MINERALS)
        vendors = [z for z in w.zones if z.get("neutralType") == "vendor"]
        if not vendors:
            return
        vendor = min(vendors, key=lambda z: dist(worker, z))
        vendor_route = w.path(worker, w.adjacent(vendor))
        if vendor_route is None:
            return
        vendor_return = w.return_distance(pos(vendor))
        time_to_sell = len(vendor_route) + vendor_return + len([k for k in MINERALS if stock[k]]) + 4
        sell = (quantity >= 10 or len(worker.get("backpack", [])) >= worker.get("backPackCapability", 100)
                or quantity and w.daylight_left <= time_to_sell + 5)
        if quantity and (sell or w.near(worker, vendor)):
            if w.near(worker, vendor):
                kind = max((k for k in MINERALS if stock[k]), key=lambda k: stock[k] * w.prices.get(k, 1))
                commands[rid] = action("sell", name=kind, num=stock[kind])
            elif time_to_sell <= w.daylight_left:
                self._put_move(w, commands, worker, w.adjacent(vendor))
            else:
                self._defend(w, commands, [worker])
            return
        mines = [z for z in w.zones if z.get("neutralType") in MINERALS
                 and self.mine_blocked_until.get(pos(z), 0) <= w.round]
        mines.sort(key=lambda z: (dist(worker, z), pos(z)))
        best = None
        for mine in mines[:10]:
            if w.expired():
                break
            kind = mine["neutralType"]
            if self._mine_closed(kind, w.day):
                continue
            route = w.path(worker, w.adjacent(mine))
            if route is None:
                continue
            to_vendor = w.path(pos(mine), w.adjacent(vendor))
            if to_vendor is None:
                continue
            capacity = max(0, worker.get("backPackCapability", 100) - len(worker.get("backpack", [])))
            harvest = min(10, capacity, max(0, w.daylight_left - len(route) - len(to_vendor) - vendor_return - 5))
            if harvest <= 0:
                continue
            price = w.prices.get(kind, {"stone": 1, "iron": 3, "copper": 5}[kind])
            score = price * harvest / float(len(route) + len(to_vendor) + harvest + 1)
            candidate = (score, -len(route), mine)
            if best is None or candidate[:2] > best[:2]:
                best = candidate
        if best:
            mine = best[2]
            if w.near(worker, mine):
                commands[rid] = action("collect", pos(mine))
                self.collect_pending[rid] = {"round": w.round, "kind": mine["neutralType"],
                                             "pos": pos(mine), "count": stock[mine["neutralType"]]}
            else:
                self._put_move(w, commands, worker, w.adjacent(mine))
        elif quantity and time_to_sell <= w.daylight_left:
            self._put_move(w, commands, worker, w.adjacent(vendor))
        else:
            self._defend(w, commands, [worker])

    def _mine_closed(self, mineral, day):
        if isinstance(self.market_advice, list):
            forecasts = [f for f in self.market_advice if isinstance(f, dict) and f.get("mineral") == mineral]
        elif isinstance(self.market_advice, dict):
            forecasts = self.market_advice.get(mineral, {})
            if isinstance(forecasts, dict):
                forecasts = [forecasts]
        else:
            forecasts = []
        for forecast in forecasts:
            if not isinstance(forecast, dict):
                continue
            if day in forecast.get("unavailable_days", []):
                return True
            try:
                first, last = int(forecast.get("from_day", 1)), int(forecast.get("to_day", 10))
                if forecast.get("collectible") is False and first <= day <= last:
                    return True
            except (TypeError, ValueError):
                continue
        return False

    def _defend(self, w, commands, selected=None):
        used = _used(commands) | self.held_roles
        people = [p for p in w.people if str(p["id"]) not in used]
        if selected is not None:
            allowed = {str(p["id"]) for p in selected}
            people = [p for p in people if str(p["id"]) in allowed]
        if not people:
            return
        guns = [g for g in w.weapons if str(g["id"]) not in commands]
        routes = {}
        for person in people:
            for gun in guns:
                if w.expired():
                    break
                goals = w.adjacent(gun)
                # People who already occupy a control cell remain eligible.
                if w.near(person, gun):
                    goals.add(pos(person))
                options = []
                for cell in sorted(goals):
                    route = w.path(person, {cell})
                    if route is not None:
                        options.append((len(route), cell, route))
                if options:
                    routes[(str(person["id"]), str(gun["id"]))] = sorted(options)
        best, best_key = [], (-1, float("-inf"))
        best_stands = {}
        for size in range(1, min(len(people), len(guns)) + 1):
            # Ordering people as well as weapons avoids reserving a scarce control
            # cell for someone who has several equally short alternatives.
            for chosen in itertools.permutations(people, size):
                for ordering in itertools.permutations(guns, size):
                    pairs = [(p, g) for p, g in zip(chosen, ordering)]
                    keys = [(str(p["id"]), str(g["id"])) for p, g in pairs]
                    if any(k not in routes for k in keys):
                        continue
                    stands, lengths = {}, []
                    for key in keys:
                        options = [o for o in routes[key] if o[1] not in stands.values()]
                        if not options:
                            break
                        length, endpoint, _ = options[0]
                        stands[key[0]] = endpoint
                        lengths.append(length)
                    if len(stands) != size:
                        continue
                    score = -sum(lengths)
                    if (size, score) > best_key:
                        best, best_key = pairs, (size, score)
                        best_stands = stands
        health = {str(r["id"]): max(0, r.get("health", 1)) for r in w.robots}
        # Small shots precede splash attacks so the latter account for committed damage.
        best.sort(key=lambda pair: pair[1].get("roleType") == "rocket")
        handled = set()
        for person, gun in best:
            rid, gid = str(person["id"]), str(gun["id"])
            handled.add(rid)
            if w.near(person, gun):
                if w.night:
                    targets, damage = self._aim(w, gun, health)
                    if targets:
                        commands[gid] = {"action": "attack", "controllerId": rid,
                                         "targetPos": [{"x": x, "y": y} for x, y in targets]}
                        self.last_shot[gid] = w.round
                        self.stats["attacks"] += 1
                        for robot_id, amount in damage.items():
                            health[robot_id] = max(0, health.get(robot_id, 0) - amount)
            else:
                self._put_move(w, commands, person, {best_stands[rid]})
        for person in people:
            if str(person["id"]) not in handled and w.station:
                self._put_move(w, commands, person, w.adjacent(w.station))

    def _aim(self, w, gun, predicted):
        kind, lvl, gid = gun.get("roleType"), level(gun), str(gun["id"])
        if gun.get("cooldown", 0) > 0:
            return [], {}
        if kind == "rocket" and "cooldown" not in gun and w.round - self.last_shot.get(gid, -100) <= 3:
            return [], {}
        default_range = {"railgun": (6, 8, 10), "gatling": (3, 5, 7), "rocket": (10, 15, 1000)}
        reach = gun.get("attackRange", default_range[kind][lvl - 1])
        power = gun.get("attackPower", 10 * lvl if kind == "railgun" else 20 if kind == "rocket" else 10)
        if power <= 0 or reach <= 0:
            return [], {}
        robots_by_pos = {pos(r): r for r in w.robots}
        weights = {}
        for robot in w.robots:
            base_distance = min((dist(robot, c) for c in w.footprint(w.station)), default=20) if w.station else 20
            near_person = min((dist(robot, p) for p in w.people), default=20)
            weight = 1 + 8.0 / (base_distance + 1) + 2.0 / (near_person + 1)
            if robot.get("targetTeam") and robot["targetTeam"] != w.team_type:
                weight *= 0.25
            if robot.get("abnormalState") == "dizzy":
                weight *= 0.8
            weights[str(robot["id"])] = weight
        def value(damage, hp):
            total = 0.0
            for rid, amount in damage.items():
                remaining = hp.get(rid, 0)
                total += min(remaining, amount) * weights.get(rid, 1)
                if remaining > 0 and amount >= remaining:
                    total += 10 * weights.get(rid, 1)
            return total
        if kind == "rocket":
            candidates = set()
            for robot in w.robots:
                x, y = pos(robot)
                for dx in (-1, 0, 1):
                    for dy in (-1, 0, 1):
                        cell = x + dx, y + dy
                        if 0 <= cell[0] < w.width and 0 <= cell[1] < w.height and dist(gun, cell) <= reach:
                            candidates.add(cell)
            effects = {}
            for cell in sorted(candidates):
                damage = {}
                x, y = cell
                for dx in (-1, 0, 1):
                    for dy in (-1, 0, 1):
                        robot = robots_by_pos.get((x + dx, y + dy))
                        if robot:
                            damage[str(robot["id"])] = power if dx == dy == 0 else power / 2
                effects[cell] = damage
            chosen, combined, hp = [], Counter(), dict(predicted)
            for _ in range(lvl):
                if not effects or w.expired():
                    break
                target = max(effects, key=lambda c: value(effects[c], hp))
                if value(effects[target], hp) <= 0 and not chosen:
                    return [], {}
                chosen.append(target)
                combined.update(effects[target])
                for rid, amount in effects[target].items():
                    hp[rid] = max(0, hp.get(rid, 0) - amount)
            # The protocol requires one target per level; padding is a legal overlap.
            while chosen and len(chosen) < lvl:
                chosen.append(chosen[-1])
                combined.update(effects[chosen[-1]])
            return chosen, dict(combined)
        effects = {}
        for robot in w.robots:
            target = pos(robot)
            if dist(gun, target) > reach:
                continue
            damage, energy = {}, power
            for cell in ray_cells(pos(gun), target):
                hit = robots_by_pos.get(cell)
                if hit:
                    rid = str(hit["id"])
                    amount = min(energy, hit.get("health", 1)) if kind == "railgun" else power
                    damage[rid] = amount
                    energy -= amount
                    if kind == "gatling" or energy <= 0:
                        break
            effects[target] = damage
        if not effects:
            return [], {}
        if kind == "railgun":
            target = max(effects, key=lambda c: value(effects[c], predicted))
            return ([target], effects[target]) if value(effects[target], predicted) > 0 else ([], {})
        chosen, combined, hp = [], Counter(), dict(predicted)
        for _ in range(lvl):
            eligible = [c for c in effects if same_cone(gun, chosen + [c])]
            if not eligible:
                break
            target = max(eligible, key=lambda c: value(effects[c], hp))
            if not chosen and value(effects[target], hp) <= 0:
                return [], {}
            chosen.append(target)
            combined.update(effects[target])
            for rid, amount in effects[target].items():
                hp[rid] = max(0, hp.get(rid, 0) - amount)
        return chosen, dict(combined)
