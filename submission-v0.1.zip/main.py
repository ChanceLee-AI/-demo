#!/usr/bin/env python3
"""Competition HTTP entry point. Uses only the Python standard library."""
import argparse
import json
import logging
import os
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from agent import VERSION
from agent.engine import Engine
from agent.validation import empty_response

MAX_REQUEST_BYTES = 8 * 1024 * 1024


class AgentServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True

    def __init__(self, address):
        super().__init__(address, Handler)
        self.engine = Engine()
        self.decision_lock = threading.Lock()


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt, *args):
        # Do not log request bodies, model output, sandbox output, or URLs.
        pass

    def _send(self, payload):
        encoded = json.dumps(payload, ensure_ascii=False, allow_nan=False, separators=(",", ":")).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(encoded)))
        self.send_header("Connection", "close")
        self.end_headers()
        self.close_connection = True
        try:
            self.wfile.write(encoded)
        except (BrokenPipeError, ConnectionResetError, OSError):
            pass

    def do_GET(self):
        self._send({"status": "ok", "version": VERSION})

    def do_POST(self):
        response = empty_response()
        acquired = False
        try:
            self.connection.settimeout(2.0)
            length = int(self.headers.get("Content-Length", "0"))
            if not 0 < length <= MAX_REQUEST_BYTES:
                self._send(response)
                return
            body = self.rfile.read(length)
            if len(body) != length:
                self._send(response)
                return
            raw = json.loads(body.decode("utf-8-sig"), parse_constant=lambda x: (_ for _ in ()).throw(ValueError("nonfinite")))
            acquired = self.server.decision_lock.acquire(timeout=1.0)
            if acquired:
                response = self.server.engine.handle(raw)
        except Exception as exc:
            logging.getLogger("futurewar").warning("request_fallback class=%s", type(exc).__name__)
        finally:
            if acquired:
                self.server.decision_lock.release()
        self._send(response)


def configure_logging():
    logger = logging.getLogger("futurewar")
    logger.setLevel(logging.INFO)
    stream = logging.StreamHandler()
    stream.setFormatter(logging.Formatter("%(message)s"))
    logger.addHandler(stream)
    # File logging is opt-in and best effort. Default stderr works in read-only
    # submissions and contains only operational summaries, never task content.
    path = os.environ.get("FUTUREWAR_LOG")
    if path:
        try:
            handler = logging.FileHandler(path, encoding="utf-8")
            handler.setFormatter(logging.Formatter("%(message)s"))
            logger.addHandler(handler)
        except OSError:
            logger.info("file_log_unavailable")
    # Logging failures must not cause a failed round.
    logging.raiseExceptions = False


def main():
    parser = argparse.ArgumentParser(description="Future War Agent " + VERSION)
    parser.add_argument("port", type=int)
    args = parser.parse_args()
    if not 1 <= args.port <= 65535:
        parser.error("port must be between 1 and 65535")
    configure_logging()
    server = AgentServer(("0.0.0.0", args.port))
    logging.getLogger("futurewar").info("ready version=%s port=%s", VERSION, server.server_port)
    try:
        server.serve_forever(poll_interval=0.25)
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
