"""Small observed-state histories for diagnosing breaches without guessing AI."""
from collections import Counter, deque

from . import VERSION
from .world import dist, pos


class SurvivalTrace:
    def __init__(self):
        self.history = deque(maxlen=5)
        self.previous = None
        self.night = None
        self.summary = None

    def observe(self, w, response, game, emit):
        people = {str(role["id"]): {"hp": role.get("health"), "pos": pos(role),
                                  "medicine": (role.get("backpack") or []).count("Medicine")}
                  for role in w.people}
        walls = {pos(role): {"id": str(role["id"]), "hp": role.get("health"), "level": role.get("level", 1)}
                 for role in w.own.values() if role.get("roleType") == "wall"}
        guns = {str(role["id"]): {"level": role.get("level", 1), "hp": role.get("health"),
                                 "cooldown": role.get("cooldown")}
                for role in w.weapons}
        counts = dict(Counter(robot.get("roleType") for robot in w.robots))
        lost_people, lost_walls, drops = [], [], {}
        if self.previous and self.previous["round"] + 1 == w.round:
            lost_people = sorted(set(self.previous["people"]) - set(people))
            lost_walls = sorted(set(self.previous["walls"]) - set(walls))
            drops = {rid: self.previous["people"][rid]["hp"] - person["hp"] for rid, person in people.items()
                     if rid in self.previous["people"] and person["hp"] < self.previous["people"][rid]["hp"]}
        nearby = [{"id": str(robot["id"]), "type": robot.get("roleType"), "pos": pos(robot),
                   "hp": robot.get("health"), "targetTeam": robot.get("targetTeam")}
                  for robot in sorted(w.robots, key=lambda r: (min((dist(r, p) for p in w.people), default=1000), str(r["id"])))[:8]]
        frame = {"round": w.round, "people": people, "guns": guns, "gold": w.gold,
                 "base_hp": w.station.get("health") if w.station else None,
                 "support": getattr(w, "support_id", None), "primary": getattr(w, "rotation_primary", None),
                 "nearby_robots": nearby, "wall_count": len(walls),
                 "actions": response["roleCommandMap"]}
        if w.night and self.night != w.day:
            self.night = w.day
            self.summary = {"day": w.day, "start_round": w.round, "robots": counts,
                            "robot_total_hp": sum(r.get("health", 0) for r in w.robots),
                            "guns_at_start": guns, "people_at_start": people, "gold_at_start": w.gold,
                            "shots_sent": 0, "maintenance_uses_sent": 0, "people_absent": [], "walls_absent": []}
            emit("night_start", dict(self.summary, version=VERSION))
        if self.summary and self.night == w.day and w.night:
            self.summary["shots_sent"] += sum(c.get("action") == "attack" for c in response["roleCommandMap"].values())
            self.summary["maintenance_uses_sent"] += sum(c.get("action") == "use" and str(c.get("name", "")).startswith("Wall")
                                                        for c in response["roleCommandMap"].values())
            self.summary["people_absent"] = sorted(set(self.summary["people_absent"]) | set(lost_people))
            self.summary["walls_absent"] = sorted(set(map(tuple, self.summary["walls_absent"])) | set(lost_walls))
        gate = getattr(w, "wall_gate", None)
        gate_robots = [str(r["id"]) for r in w.robots if gate is not None and dist(r, gate) <= 1]
        if w.night and (w.turn % 5 == 0 or lost_people or lost_walls or drops):
            emit("survival", dict(frame, version=VERSION, robot_types=counts,
                                  people_absent=lost_people, wall_positions_absent=lost_walls,
                                  people_hp_drops=drops, robots_near_gate=gate_robots[:8],
                                  walls=[dict(data, pos=cell) for cell, data in sorted(walls.items())],
                                  observations_only=True))
        if lost_people or lost_walls:
            emit("breach_observation", {"version": VERSION, "round": w.round,
                                        "people_absent": lost_people, "wall_positions_absent": lost_walls,
                                        "recent": list(self.history)[-3:] + [frame], "cause_confirmed": False})
        if self.summary and (w.turn == 129 or (not w.night and self.night is not None and w.day > self.night)):
            emit("night_summary", dict(self.summary, version=VERSION, observed_round=w.round,
                                       gold_last=w.gold, base_hp_last=frame["base_hp"],
                                       attack_count_is_sent_not_confirmed=True))
            self.summary = None
        maintenance = getattr(game.maintenance, "context", {})
        if maintenance and (w.night or maintenance.get("events") or w.turn % 5 == 0):
            emit("maintenance", dict(maintenance, version=VERSION, round=w.round))
        self.history.append(frame)
        self.previous = {"round": w.round, "people": people, "walls": walls}
