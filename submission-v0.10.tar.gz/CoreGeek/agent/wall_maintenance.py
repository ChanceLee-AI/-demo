"""Observed wall upkeep with a separate budget and action failure boundary.

Maintenance never constructs a wall, changes the gate, transfers inventory, or
assumes a wall blocks robot fire. Purchase money is reserved only from observed
cash; final sent orders remain in the daily ledger until their result is known.
"""
import re
from collections import Counter

from .defense import number
from .layout import FortLayout
from .medical import occupied_roles
from .threat import POWER, endangered
from .world import PathResult, action, dist, pos


FIXER = "WallFixer"
VOUCHER = "WallUpgradeVoucher1"
ITEMS = (FIXER, VOUCHER)


def wall_max_health(wall):
    for key in ("maxHealth", "maxHp", "healthMax"):
        value = wall.get(key)
        if isinstance(value, (int, float)) and value > 0:
            return value
    return 500 * (min(3, max(1, int(wall.get("level", 1)))) + 1)


class WallMaintenancePlanner:
    daily_limit = 80
    target_limit = 3
    fixer_limit = 2

    def __init__(self):
        self.round = None
        self.day = None
        self.context = {}
        self.targets = []
        self.carrier = None
        self.plan = None
        self.snapshot = {}
        self.snapshot_round = None
        self.snapshot_day = None
        self.snapshot_night = False
        self.night_losses = {}
        self.recent_losses = {}
        self.pending = {}
        self.ledger = {}
        self.failures = Counter()
        self.blocked_until = {}
        self.disabled = False
        self.disabled_reason = ""
        self._sent_round = None
        self._rejected = set()
        self._outcomes = {}
        self._proposed = {}
        self._travel = None
        self._stalls = Counter()
        self._avoid = {}

    @staticmethod
    def _walls(w):
        return {pos(role): role for role in w.own.values() if role.get("roleType") == "wall"}

    @staticmethod
    def _result(w, rid):
        results = w.raw.get("lastRoundRoleActionResults") or {}
        if not isinstance(results, dict):
            return None
        return next((value for key, value in results.items() if str(key) == rid), None)

    def _event(self, event, **details):
        self.context.setdefault("events", []).append(dict(event=event, **details))

    def _allowed(self, w, verb):
        return (w.day >= 2 and not self.disabled
                and verb not in getattr(w, "disabled_actions", set())
                and self.failures[(w.day, verb)] < 2
                and self.blocked_until.get(verb, 0) <= w.round)

    def _fail(self, w, pending):
        verb = pending["action"]
        self.failures[(w.day, verb)] += 1
        self.blocked_until[verb] = w.round + 5
        self.plan = None

    def _observe(self, w):
        self._outcomes = {}
        walls = self._walls(w)
        for rid, pending in list(self.pending.items()):
            if pending["round"] >= w.round:
                continue
            del self.pending[rid]
            consecutive = pending["round"] + 1 == w.round
            feedback = self._result(w, rid) if consecutive else None
            role = w.own.get(rid)
            stock = Counter(role.get("backpack") or []) if role else Counter()
            target = walls.get(pending.get("target"))
            same_target = bool(target and str(target["id"]) == pending.get("target_id"))
            inventory = bool(role and (stock[pending["name"]] > pending["count"]
                                      if pending["action"] == "buy"
                                      else stock[pending["name"]] < pending["count"]))
            upgraded = bool(same_target and pending["name"] == VOUCHER
                            and int(target.get("level", 1)) > pending.get("level", 1))
            # Skipped observations cannot associate a later inventory change or
            # another actor's repair with this response's action.
            confirmed = consecutive and (inventory or upgraded)
            failed = consecutive and feedback is False and not confirmed and role is not None
            event = ("confirmed" if confirmed else "failed" if failed else
                     "feedback_unassociated" if not consecutive else
                     "role_unavailable" if role is None else "unconfirmed")
            if pending["action"] == "buy":
                entry = self.ledger.get(pending["key"])
                if entry:
                    if confirmed:
                        entry["state"] = "confirmed"
                    elif failed:
                        entry["state"] = "failed"
                    # Unknown orders keep their original day's encumbrance.
                    # This never consumes the next day's 80 gold allowance.
            if failed:
                self._fail(w, pending)
            self._outcomes[rid] = event
            self._event(event, role=rid, action=pending["action"], name=pending["name"],
                        target=pending.get("target"), target_id=pending.get("target_id"),
                        feedback=feedback, inventory_before=pending["count"],
                        inventory_after=stock[pending["name"]] if role else None,
                        inventory_changed=inventory if consecutive else None,
                        level_changed=upgraded if consecutive else None,
                        target_replaced=bool(target and not same_target and pending["action"] == "use"),
                        hp_before=pending.get("hp"), hp_after=target.get("health") if target else None)
        travel = self._travel
        if travel and travel["round"] + 1 == w.round:
            role = w.own.get(travel["role"])
            key = (travel["role"], travel["target"], travel["stand"])
            self._stalls[key] = self._stalls[key] + 1 if role and pos(role) == travel["position"] else 0
            if self._stalls[key] >= 3:
                self._avoid[key] = w.round + 5
                self.plan = None
                self._event("maintenance_stalled_replan", role=key[0], target=key[1], stand=key[2])
        self._travel = None
        self._avoid = {key: until for key, until in self._avoid.items()
                       if until > w.round and key[0] in w.own}
        self._stalls = Counter({key: count for key, count in self._stalls.items()
                                if count and key[0] in w.own})

    def _history(self, w):
        walls = self._walls(w)
        self.recent_losses = {}
        if self.snapshot_round is not None and self.snapshot_round < w.round and self.snapshot_night:
            losses = self.night_losses.setdefault(self.snapshot_day, Counter())
            for cell, previous in self.snapshot.items():
                current = walls.get(cell)
                # A rebuilt wall is a new object; never subtract its fresh HP
                # from the old wall's last observed health.
                same = current and str(current["id"]) == previous["id"]
                loss = max(0, previous["hp"] - number(current.get("health"))) if same else previous["hp"]
                if loss:
                    losses[cell] += loss
                    if self.snapshot_round + 1 == w.round:
                        self.recent_losses[cell] = loss
                    self._event("wall_loss_observed", target=cell, hp_loss=loss,
                                disappeared=not same, observation_gap=w.round - self.snapshot_round)
        self.snapshot = {cell: {"id": str(wall["id"]), "hp": number(wall.get("health"))}
                         for cell, wall in walls.items()}
        self.snapshot_round, self.snapshot_day, self.snapshot_night = w.round, w.day, w.night
        self.night_losses = {day: losses for day, losses in self.night_losses.items() if day >= w.day - 1}

    @staticmethod
    def _pressure(w, cell):
        """Potential pressure from our/unknown-target robots; no shielding."""
        current, future = 0.0, 0.0
        for robot in w.robots:
            if robot.get("targetTeam") and robot.get("targetTeam") != w.team_type:
                continue
            reach = number(robot.get("attackRange"), 3)
            power = number(robot.get("attackPower"), POWER.get(robot.get("roleType"), 10))
            distance = dist(robot, cell)
            if distance <= reach and robot.get("abnormalState") != "dizzy":
                current += power
            if distance <= reach + 1:
                future += power
        return current + future

    def _urgent(self, w, wall):
        hp, cell = number(wall.get("health")), pos(wall)
        estimate = max(self._pressure(w, cell), 2 * self.recent_losses.get(cell, 0))
        return hp <= wall_max_health(wall) / 2 or (estimate > 0 and hp <= estimate)

    @staticmethod
    def _inner(w):
        return set(getattr(w, "defense_inner", ()) or FortLayout.ring(w, 1)) - w.static

    @staticmethod
    def _primary_ids(w):
        primary = getattr(w, "rotation_primary", None)
        # gunner_roles also contains an idle assigned support worker. Its
        # standby duty permits maintenance; only the primary is unconditional.
        # _workers separately excludes every actual action/controller in the
        # current command map, including a support takeover or extra shot.
        return {str(primary)} if primary is not None else set()

    def _stands(self, w, worker, target):
        cells = w.adjacent(target) & self._inner(w)
        if w.night:
            anchor, gate = getattr(w, "rocket_anchor", None), getattr(w, "wall_gate", None)
            cells -= {pos(value) for value in (anchor, gate) if value is not None}
            cells -= {pos(w.own[rid]) for rid in self._primary_ids(w) if rid in w.own}
        return {cell for cell in cells if not endangered(w, worker, cell)
                and self._avoid.get((str(worker["id"]), pos(target), cell), 0) <= w.round}

    def _route(self, w, worker, start, goals, commands=None, dynamic=False):
        start = pos(start)
        goals = {pos(cell) for cell in goals}
        if w.expired():
            return PathResult("budget_exhausted")
        if endangered(w, worker, start):
            return PathResult("unsafe")
        friendly = {pos(role) for role in w.people}
        blocked = set(w.static) | (set(w.occupied) if dynamic else w.occupied - friendly)
        blocked.update(getattr(w, "move_avoid", {}).get(str(worker["id"]), ()))
        for command in (commands or {}).values():
            if command.get("action") in ("move", "build"):
                blocked.update(pos(cell) for cell in command.get("targetPos", ()))
        if w.night:
            inner = self._inner(w)
            if start not in inner:
                return PathResult("outside_inner")
            blocked.update((x, y) for x in range(w.width) for y in range(w.height) if (x, y) not in inner)
            protected = set()
            for value in (getattr(w, "rocket_anchor", None), getattr(w, "wall_gate", None)):
                if value is not None:
                    protected.add(pos(value))
            blocked.update(protected)
            if start in protected:
                return PathResult("reserved_operator_cell")
        # The whole intended route, not only the work square, must meet the
        # same two-turn health margin as other v0.10 worker movement.
        if w.robots:
            cache = getattr(w, "_maintenance_danger", None)
            if cache is None:
                cache = w._maintenance_danger = {}
            key = (number(worker.get("health")), worker.get("roleType"),
                   worker.get("maxHealth"), worker.get("maxHp"), worker.get("healthMax"))
            if key not in cache:
                cells = set()
                for x in range(w.width):
                    if w.expired():
                        return PathResult("budget_exhausted")
                    for y in range(w.height):
                        if endangered(w, worker, (x, y)):
                            cells.add((x, y))
                cache[key] = cells
            blocked.update(cache[key])
        blocked.discard(start)
        goals -= blocked
        if not goals or start in w.static:
            return PathResult("unreachable")
        if start in goals:
            return PathResult("arrived", [], goal=start)
        steps, complete = w._search(start, goals, blocked, ("maintenance", start, frozenset(blocked)))
        if steps is None:
            return PathResult("unreachable" if complete else "budget_exhausted")
        delay = 0 if dynamic else 2 * bool((friendly - {pos(worker)}).intersection(steps))
        return PathResult("reachable", steps, goal=steps[-1], delay=delay)

    def _home(self, w, worker, start):
        rid = str(worker["id"])
        assigned = w.defense_assignments.get(rid)
        refuge = w.defense_refuges.get(rid)
        if assigned:
            goals = {pos(assigned["pos"])}
        elif refuge is not None:
            goals = {pos(refuge)}
        else:
            goals = self._inner(w)
        return self._route(w, worker, start, goals)

    def _use_trip(self, w, worker, wall):
        goals = self._stands(w, worker, wall)
        route = self._route(w, worker, worker, goals)
        if not route.reachable:
            return None
        if w.night:
            return {"stand": route.goal, "turns": route.total_distance + 1, "home_turns": 0}
        home = self._home(w, worker, route.goal)
        if not home.reachable:
            return None
        turns = route.total_distance + 1 + home.total_distance
        if turns + w.return_margin > w.daylight_left:
            return None
        return {"stand": route.goal, "turns": turns, "home_turns": home.total_distance}

    def _selection(self, w):
        walls = self._walls(w)
        previous = self.night_losses.get(w.day - 1, {})
        choices = []
        for cell, wall in walls.items():
            if w.expired():
                break
            loss = previous.get(cell, 0)
            pressure = self._pressure(w, cell)
            missing = max(0, wall_max_health(wall) - number(wall.get("health")))
            if not (loss or pressure or missing):
                continue
            distances = []
            for worker in w.workers:
                route = self._route(w, worker, worker, self._stands(w, worker, wall))
                if route.reachable:
                    distances.append(route.total_distance)
            if distances:
                choices.append((0 if w.night and self._urgent(w, wall) else 1,
                                -loss, -pressure, -missing, min(distances), cell))
        ranked = [choice[-1] for choice in sorted(choices)]
        if w.night:
            self.targets = ranked[:self.target_limit]
        else:
            # Keep valid daytime selections even after an upgrade restores HP;
            # otherwise a single day could silently upgrade more than 3 walls.
            self.targets = [cell for cell in self.targets if cell in walls]
            self.targets += [cell for cell in ranked if cell not in self.targets][
                :max(0, self.target_limit - len(self.targets))]

    def _money(self, w):
        entries = [entry for entry in self.ledger.values() if entry["day"] == w.day]
        spent = sum(entry["price"] for entry in entries if entry["state"] == "confirmed")
        pending = sum(entry["price"] for entry in entries if entry["state"] == "pending")
        return spent, pending

    def _choose_carrier(self, w):
        support = str(getattr(w, "support_id", ""))
        if w.day >= 3 and support in w.own:
            self.carrier = support
            return
        if self.carrier in w.own:
            return
        walls = self._walls(w)
        candidates = []
        for worker in w.workers:
            distances = []
            for cell in self.targets:
                if cell in walls:
                    trip = self._use_trip(w, worker, walls[cell])
                    if trip:
                        distances.append(trip["turns"])
            if distances:
                held = any(item in ITEMS for item in worker.get("backpack", ()))
                candidates.append((not held, min(distances), str(worker["id"])))
        if candidates:
            self.carrier = min(candidates)[-1]

    def _publish(self, w):
        walls = self._walls(w)
        spent, pending = self._money(w)
        self.context.update(round=w.round, day=w.day, carrier=self.carrier,
                            daily_limit=self.daily_limit, daily_spent=spent, daily_pending=pending,
                            daily_remaining=max(0, self.daily_limit - spent - pending),
                            disabled=self.disabled, disabled_reason=self.disabled_reason,
                            failures_today={verb: self.failures[(w.day, verb)] for verb in ("buy", "use")},
                            targets=[{"pos": cell, "id": str(walls[cell]["id"]),
                                      "level": walls[cell].get("level", 1), "hp": walls[cell].get("health"),
                                      "previous_night_loss": self.night_losses.get(w.day - 1, {}).get(cell, 0),
                                      "estimated_two_turn_damage": self._pressure(w, cell),
                                      "urgent": self._urgent(w, walls[cell])}
                                     for cell in self.targets if cell in walls])
        w.maintenance_targets = set(self.targets)
        w.wall_urgent = any(cell in walls and self._urgent(w, walls[cell])
                            and (self._pressure(w, cell) > 0 or self.recent_losses.get(cell, 0) > 0)
                            for cell in self.targets)
        w.wall_maintenance = self.context

    def prepare(self, w):
        if self.round == w.round:
            self._publish(w)
            return
        self.round = w.round
        self.context = {"events": [], "roles": {}, "plan": None}
        self._proposed = {}
        self._rejected = set()
        if self.day != w.day:
            self.day = w.day
            self.targets = []
            self.plan = None
            self.failures = Counter({key: value for key, value in self.failures.items() if key[0] == w.day})
            self.blocked_until = {}
        self._observe(w)
        self._history(w)
        self.ledger = {key: entry for key, entry in self.ledger.items() if entry["day"] >= w.day - 1}
        if self.carrier not in w.own:
            self.carrier = None
            self.plan = None
        if w.day >= 2 and not self.disabled:
            self._selection(w)
            self._choose_carrier(w)
        self._publish(w)

    def _workers(self, w, workers, commands=None, purchasing=False):
        used = occupied_roles(commands or {}) | self._primary_ids(w)
        people = [worker for worker in workers if str(worker["id"]) in w.own
                  and worker.get("roleType") == "worker" and str(worker["id"]) not in used]
        support = str(getattr(w, "support_id", ""))
        if w.day >= 3 and support in w.own and (purchasing or w.night):
            people = [worker for worker in people if str(worker["id"]) == support]
        elif purchasing and self.carrier in w.own and (
                self.carrier in used or not any(str(worker["id"]) == self.carrier for worker in people)):
            # A healing/gunner action pauses the carrier; it does not justify
            # filling a second worker's backpack with another two repair kits.
            people = []
        return people

    def _pending_count(self, w, rid, name):
        return sum(1 for entry in self.ledger.values()
                   if entry["day"] == w.day and entry["state"] == "pending"
                   and entry["role"] == rid and entry["name"] == name)

    def _purchase_trip(self, w, worker, wall):
        choices = []
        for shop in w.zones:
            if w.expired():
                break
            if shop.get("neutralType") != "weaponShop":
                continue
            goals = {cell for cell in w.adjacent(shop)
                     if self._avoid.get((str(worker["id"]), pos(wall), cell), 0) <= w.round}
            outward = self._route(w, worker, worker, goals)
            if not outward.reachable:
                continue
            delivery = self._route(w, worker, outward.goal, self._stands(w, worker, wall))
            if not delivery.reachable:
                continue
            home = self._home(w, worker, delivery.goal)
            if not home.reachable:
                continue
            turns = outward.total_distance + delivery.total_distance + home.total_distance + 2
            if turns + w.return_margin <= w.daylight_left:
                choices.append({"shop": shop, "stand": outward.goal, "use_stand": delivery.goal,
                                "turns": turns, "home_turns": home.total_distance})
        return min(choices, key=lambda item: (item["turns"], pos(item["shop"]), item["stand"])) if choices else None

    def goal(self, w, workers, budget, guard=0):
        self.prepare(w)
        if w.night or not self._allowed(w, "buy") or not self._allowed(w, "use"):
            return None
        walls = self._walls(w)
        targets = [walls[cell] for cell in self.targets if cell in walls]
        if not targets:
            return None
        spent, pending = self._money(w)
        allowance = self.daily_limit - spent - pending
        choices = []
        workers = self._workers(w, workers, purchasing=True)
        if not workers:
            return None
        retained = next((worker for worker in workers if str(worker["id"]) == self.carrier), None)
        if retained and any(self._purchase_trip(w, retained, target) for target in targets):
            workers = [retained]
        vouchers = sum(Counter(worker.get("backpack") or [])[VOUCHER] for worker in w.workers)
        vouchers += sum(self._pending_count(w, str(worker["id"]), VOUCHER) for worker in w.workers)
        needs_upgrade = sum(int(wall.get("level", 1)) == 1 for wall in targets)
        for worker in workers:
            rid, bag = str(worker["id"]), Counter(worker.get("backpack") or [])
            if sum(bag.values()) >= worker.get("backPackCapability", 100):
                continue
            names = []
            if bag[FIXER] + self._pending_count(w, rid, FIXER) < self.fixer_limit:
                names.append(FIXER)
            if vouchers < needs_upgrade:
                names.append(VOUCHER)
            for item_index, name in enumerate(names):
                if name not in w.shop or w.shop[name] > allowance:
                    continue
                for target in targets:
                    if name == VOUCHER and int(target.get("level", 1)) != 1:
                        continue
                    trip = self._purchase_trip(w, worker, target)
                    if trip:
                        old = self.plan or {}
                        plan = dict(trip, kind="maintenance", role=rid, target=target, name=name,
                                    price=w.shop[name], reserve=max(0, guard),
                                    available_cash=max(0, budget - max(0, guard)))
                        choices.append((rid != self.carrier, item_index,
                                        not (rid == old.get("role") and name == old.get("name")
                                             and pos(target) == pos(old["target"])),
                                        trip["turns"], pos(target), rid, plan))
                # Fixer stock has priority over new vouchers. A missing quote,
                # over-budget price or impossible trip does not freeze upgrades.
                if any(choice[-1]["role"] == rid and choice[-1]["name"] == name for choice in choices):
                    break
        if not choices:
            self.plan = None
            self.context["plan"] = None
            return None
        plan = min(choices, key=lambda item: item[:-1])[-1]
        self.carrier = plan["role"]
        self.plan = plan
        self.context["plan"] = plan
        self._publish(w)
        return dict(plan)

    def _move(self, w, commands, worker, goal, target, game):
        # Use the planner's dynamic safe path, then ask the shared movement
        # helper to reserve exactly that next step (never an unsafe alternate).
        route = self._route(w, worker, worker, {goal}, commands, dynamic=True)
        rid = str(worker["id"])
        self._travel = {"round": w.round, "role": rid, "target": pos(target),
                        "stand": pos(goal), "position": pos(worker)}
        if not route.reachable or not route.steps:
            planned = self._route(w, worker, worker, {goal}, commands)
            if planned.reachable and planned.steps:
                w.blocked_routes.append((rid, planned.steps))
            self._event("maintenance_move_blocked", role=rid, target=pos(target), status=route.status)
            return False
        move = game._put_move if hasattr(game, "_put_move") else game
        if move is None:
            commands[rid] = action("move", route.steps[0])
            return True
        return bool(move(w, commands, worker, {route.steps[0]}))

    def purchase(self, w, commands, workers, budget, guard, game):
        available = self._workers(w, workers, commands, purchasing=True)
        plan = self.goal(w, available, budget, guard)
        if not plan or plan["price"] > budget - max(0, guard):
            return set(), 0
        rid = plan["role"]
        if rid in occupied_roles(commands):
            return set(), 0
        worker = w.own.get(rid)
        if worker is None:
            return set(), 0
        if w.near(worker, plan["shop"]):
            commands[rid] = action("buy", name=plan["name"], num=1)
            self._proposed[rid] = dict(commands[rid])
        else:
            self._move(w, commands, worker, plan["stand"], plan["target"], game)
        self.context["roles"][rid] = {"stage": "purchase", "name": plan["name"],
                                      "target": pos(plan["target"]), "turns": plan["turns"]}
        self._publish(w)
        return {rid}, plan["price"]

    def use_owned(self, w, commands, workers, game, emergency_only=False):
        self.prepare(w)
        if not self._allowed(w, "use"):
            return set()
        walls = self._walls(w)
        choices = []
        reserved_targets = {pos(cell) for command in commands.values()
                            if command.get("action") == "use" and command.get("name") in ITEMS
                            for cell in command.get("targetPos", ())}
        for worker in self._workers(w, workers, commands):
            rid, bag = str(worker["id"]), Counter(worker.get("backpack") or [])
            for index, cell in enumerate(self.targets):
                wall = walls.get(cell)
                if wall is None or cell in reserved_targets:
                    continue
                urgent = self._urgent(w, wall)
                if (w.night or emergency_only) and not urgent:
                    continue
                # The owned level-one voucher increases capacity and restores
                # HP in the same action. No level-two voucher is ever purchased.
                name = VOUCHER if bag[VOUCHER] and int(wall.get("level", 1)) == 1 else (
                    FIXER if bag[FIXER] and urgent and number(wall.get("health")) < wall_max_health(wall) else None)
                if name is None:
                    continue
                trip = self._use_trip(w, worker, wall)
                if trip:
                    choices.append((not urgent if w.night else name != VOUCHER,
                                    rid != self.carrier, index, trip["turns"], rid, wall, name, trip))
        if not choices:
            return set()
        _, _, _, _, rid, wall, name, trip = min(choices, key=lambda item: item[:5])
        worker = w.own[rid]
        if self.carrier not in w.own:
            self.carrier = rid
        if pos(worker) == trip["stand"]:
            commands[rid] = action("use", wall, name=name)
            self._proposed[rid] = dict(commands[rid])
        else:
            self._move(w, commands, worker, trip["stand"], wall, game)
        self.context["roles"][rid] = {"stage": "use_owned", "name": name,
                                      "target": pos(wall), "turns": trip["turns"]}
        self._publish(w)
        return {rid}

    def record(self, w, commands):
        """Track only final validated actions; duplicate record calls are inert."""
        self.prepare(w)
        if self._sent_round == w.round:
            return
        self._sent_round = w.round
        self.pending = {}
        final = {str(rid): command for rid, command in commands.items()}
        for rid, command in final.items():
            role = w.own.get(rid)
            verb, name = command.get("action"), command.get("name")
            if role is None or verb not in ("buy", "use") or name not in ITEMS:
                continue
            # This tracker owns all final wall-maintenance actions, including a
            # caller's valid owned-item action, but never unrelated buy/use.
            pending = {"round": w.round, "day": w.day, "role": rid, "action": verb,
                       "name": name, "count": Counter(role.get("backpack") or [])[name]}
            if verb == "buy":
                key = (w.round, rid, name)
                pending["key"] = key
                self.ledger[key] = {"day": w.day, "role": rid, "name": name,
                                    "state": "pending", "price": w.shop.get(name, 0) * command.get("num", 1)}
            else:
                targets = command.get("targetPos") or []
                wall = self._walls(w).get(pos(targets[0])) if len(targets) == 1 else None
                if wall is None:
                    continue
                pending.update(target=pos(wall), target_id=str(wall["id"]),
                               hp=number(wall.get("health")), level=int(wall.get("level", 1)))
            self.pending[rid] = pending
        if self._travel:
            rid = self._travel["role"]
            if final.get(rid, {}).get("action") not in (None, "move"):
                self._travel = None
        self.context["sent"] = [{"role": rid, "action": pending["action"], "name": pending["name"],
                                 "target": pending.get("target")}
                                for rid, pending in self.pending.items()]
        self._publish(w)

    def reject(self, w, prior, description):
        """Return True only for an explicitly attributable maintenance error."""
        self.prepare(w)
        if self._sent_round != w.round - 1:
            return False
        text = str(description)[:2048]
        if text in self._rejected:
            return self.disabled
        prior = {str(rid): command for rid, command in prior.items() if isinstance(command, dict)}
        named_ids = {rid for rid in prior if re.search(r"(?<![A-Za-z0-9_])" + re.escape(rid)
                                                      + r"(?![A-Za-z0-9_])", text)}
        selected = {rid: prior[rid] for rid in named_ids} if named_ids else dict(prior)
        item_named = any(name.lower() in text.lower() for name in ITEMS) or any(
            word in text for word in ("围墙修复包", "围墙升级券"))
        verbs = {verb for verb in ("buy", "use", "move", "build", "attack", "sell", "collect")
                 if re.search(r"(?<![A-Za-z])" + verb + r"(?![A-Za-z])", text, re.I)}
        candidates = {rid: command for rid, command in selected.items()
                      if command.get("action") in ("buy", "use") and command.get("name") in ITEMS
                      and (not verbs or command.get("action") in verbs)}
        if not candidates or not (item_named or named_ids):
            return False
        # An explicit actor naming another action takes priority over an item
        # word elsewhere in a compound error; generic 'use failed' is unsafe.
        if named_ids and len(candidates) != len(selected):
            return False
        if any(self._result(w, rid) is True or self._outcomes.get(rid) == "confirmed" for rid in candidates):
            return False
        self._rejected.add(text)
        self.disabled, self.disabled_reason = True, "explicit_maintenance_instruction_error"
        self.plan = None
        self._event("maintenance_disabled", roles=sorted(candidates), reason=text[:300])
        self._publish(w)
        return True
