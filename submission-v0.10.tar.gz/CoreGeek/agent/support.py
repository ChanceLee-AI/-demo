"""Third-night support duty and conservative two-turn operator survival."""
from .rotation import _used
from .single_gunner import SingleGunnerRotation
from .threat import (current_damage, damage_score, endangered, maximum_health,
                     safe_escape, two_turn_damage)
from .validation import validate
from .world import dist, pos


class SupportRotation(SingleGunnerRotation):
    def __init__(self):
        super().__init__()
        self.support_id = None
        self.support_stand = None
        self.support_returning = False
        self.support_blocked = 0
        self.support_checked = None
        self.support_reason = "before_day_three"

    def _best_stand(self, w, person, previous=None, actual=False, ignore_people=(), require_route=True):
        if person is None:
            return None
        guns, anchor = self._guns(w), getattr(w, "rocket_anchor", None)
        cells = {cell for gun in guns for cell in w.adjacent(gun)}
        if not cells:
            cells = ({tuple(anchor)} if anchor is not None and tuple(anchor) not in w.static
                     else w.adjacent(w.station) if w.station else set())
        cells -= set(getattr(w, "wall_planned", ()))
        options = []
        for cell in sorted(cells):
            if w.expired():
                break
            route = (w.route(person, {cell}, ignore_people=ignore_people) if actual
                     else w.plan_route(person, pos(person), {cell}))
            if not route.reachable and require_route:
                continue
            risk, danger = two_turn_damage(w, cell), endangered(w, person, cell)
            score = (danger, risk if danger else 0, -sum(w.near(cell, gun) for gun in guns),
                     cell != anchor, cell != previous,
                     route.total_distance if route.total_distance is not None else 10000, risk, cell)
            options.append((score, cell))
        return min(options)[1] if options else None

    def _support_cells(self, w):
        inner = set(getattr(w, "defense_inner", ()))
        if not inner and w.station:
            inner = w.adjacent(w.station)
        forbidden = set(getattr(w, "wall_planned", ())) | w.static
        forbidden.update(cell for cell in (getattr(w, "wall_gate", None),
                                          getattr(w, "rocket_anchor", None), self.pioneer_goal)
                         if cell is not None)
        return {cell for cell in inner - forbidden
                if w.in_bounds(cell) and any(w.near(cell, gun) for gun in self._guns(w))}

    def _select_support(self, w):
        if w.day < 3:
            self.support_id = self.support_stand = None
            self.support_returning = False
            self.support_reason = "before_day_three"
            return
        cells = self._support_cells(w)
        worker = w.own.get(self.support_id)
        old_pair = self.support_id, self.support_stand
        valid = bool(worker and worker.get("roleType") == "worker" and self.support_stand in cells
                     and not endangered(w, worker, self.support_stand))
        if valid:
            planned = w.plan_route(worker, pos(worker), {self.support_stand})
            due = w.night or (planned.total_distance is not None
                             and w.daylight_left <= planned.total_distance + w.return_margin)
            if planned.status == "budget_exhausted":
                due = due or self.support_returning
            route = w.route(worker, {self.support_stand}) if due else planned
            if self.support_checked != w.round:
                self.support_checked = w.round
                if route.status != "budget_exhausted":
                    # A genuinely disconnected planning route cannot acquire a
                    # return deadline: its distance is unknown. Count that
                    # evidence in daylight too, rather than waiting until night.
                    failed = planned.status == "unreachable" or (due and not route.reachable)
                    self.support_blocked = (self.support_blocked + 1
                                            if failed else 0)
            if self.support_blocked < 3:
                self.support_returning = due
                self.support_reason = "route_wait" if not route.reachable else "assigned"
                return
        # A spent planning budget is not evidence that the existing duty is bad.
        if w.expired() and worker and self.support_stand in cells:
            self.support_returning = w.night or self.support_returning
            self.support_reason = "budget_wait"
            return
        choices = []
        for person in w.workers:
            rid = str(person["id"])
            # An already selected substitute is the support; do not recall a
            # second economic worker while the pioneer is still unavailable.
            if self.replacement and rid != self.replacement:
                continue
            stands = []
            for cell in sorted(cells):
                if self.support_blocked >= 3 and (rid, cell) == old_pair:
                    continue
                if endangered(w, person, cell):
                    continue
                route = w.route(person, {cell})
                if not route.reachable:
                    continue
                stands.append((two_turn_damage(w, cell),
                               -sum(w.near(cell, gun) for gun in self._guns(w)), route.distance, cell))
            if stands:
                # First find this person's safest useful control square. A
                # zero-distance one-gun square must not hide a safe two-gun
                # square nearby. Only then compare workers' actual journeys.
                _, _, distance, cell = min(stands)
                choices.append((distance, -person.get("health", 0) / maximum_health(person), rid, cell))
        if choices:
            _, _, self.support_id, self.support_stand = min(choices)
            self.support_blocked = 0
            person = w.own[self.support_id]
            route = w.plan_route(person, pos(person), {self.support_stand})
            self.support_returning = w.night or (route.total_distance is not None
                                                and w.daylight_left <= route.total_distance + w.return_margin)
            self.support_reason = "assigned"
        else:
            self.support_id = self.support_stand = None
            self.support_returning = False
            self.support_reason = "no_safe_reachable_inner_control"

    def _publish_single(self, w, state=None):
        super()._publish_single(w, state)
        w.support_id, w.support_stand = self.support_id, self.support_stand
        w.support_returning = self.support_returning
        if self.support_id in w.own and (w.night or self.support_returning):
            w.economic_roles.discard(self.support_id)
            w.gunner_roles.add(self.support_id)
            w.rotation_protected_roles.add(self.support_id)
        self.context.update(support=self.support_id, support_stand=self.support_stand,
                            support_returning=self.support_returning,
                            support_reason=self.support_reason, support_blocked=self.support_blocked,
                            economic_roles=sorted(w.economic_roles), gunner_roles=sorted(w.gunner_roles))
        # The priority tiers depend on today's chosen operators.
        w.__dict__.pop("_threat_tiers", None)

    def prepare(self, w):
        super().prepare(w)
        self._select_support(w)
        if self.replacement == self.support_id and self.support_id is not None:
            self.stand = self.support_stand
        self._bind_one(w, self.support_id, self.support_stand)
        self._publish_single(w)

    def _escape(self, w, person, commands):
        return (safe_escape(w, person, commands, getattr(w, "wall_planned", ()))
                if person is not None else None)

    def _recoverable(self, w, commands):
        return bool(w.pioneer and self.pioneer_goal is not None
                    and not endangered(w, w.pioneer)
                    and not endangered(w, w.pioneer, self.pioneer_goal)
                    and super()._recoverable(w, commands))

    def _choose_replacement(self, w, commands, ignore_pioneer=True):
        if w.day < 3:
            return super()._choose_replacement(w, commands, ignore_pioneer)
        person = w.own.get(self.support_id)
        if (person is None or self.support_stand is None
                or self.support_id in _used(commands) | set(getattr(w, "medical_roles", ()))):
            return None, None
        route = w.route(person, {self.support_stand})
        return (self.support_id, self.support_stand) if route.reachable else (None, None)

    def evade(self, w, commands, game):
        """Only personal danger can consume an operator's action before fire."""
        if not w.night:
            return
        details = {}
        for rid in dict.fromkeys((self.primary, self.support_id)):
            person = w.own.get(rid)
            if person is None or rid in _used(commands):
                continue
            danger = endangered(w, person)
            cell = self._escape(w, person, commands) if danger else None
            moved = bool(cell is not None and game._put_move(w, commands, person, {cell}))
            details[rid] = {"damage_now": current_damage(w, pos(person)),
                            "damage_two_turns": two_turn_damage(w, pos(person)),
                            "endangered": danger, "escape": cell, "move_proposed": moved}
        w.operator_risk = details
        self.context["operator_risk"] = details

    @staticmethod
    def _projected_health(w, commands):
        health = {str(robot["id"]): max(0, robot.get("health", 1)) for robot in w.robots}
        # Use only currently legal proposed attacks. This is damage allocation,
        # never evidence that a threatening robot has already stopped attacking.
        valid = validate(w, {"roleCommandMap": commands})["roleCommandMap"]
        for gid, command in valid.items():
            gun = w.own.get(str(gid), {})
            if command.get("action") != "attack" or gun.get("roleType") != "rocket":
                continue
            power = gun.get("attackPower", 20)
            for target in command.get("targetPos", ()):
                for robot in w.robots:
                    distance = dist(robot, target)
                    if distance <= 1:
                        rid = str(robot["id"])
                        health[rid] = max(0, health[rid] - (power if distance == 0 else power / 2))
        return health, valid

    def _fire(self, w, commands, game, rid, label):
        person = w.own.get(rid)
        if person is None or rid in _used(commands) or "attack" in getattr(w, "disabled_actions", ()):
            return False
        health, _ = self._projected_health(w, commands)
        candidates, statuses = [], {}
        support = w.own.get(self.support_id)
        preserve_support = bool(label == "main" and support and self.support_id != rid
                                and self.support_id not in _used(commands)
                                and (getattr(w, "wall_urgent", False) or endangered(w, person)
                                     or endangered(w, support)))
        for gun in self._guns(w):
            gid = str(gun["id"])
            if gid in commands or not w.near(person, gun):
                statuses[gid] = "not_available_to_operator"
                continue
            cooldown = gun.get("cooldown")
            if cooldown is None:
                cooldown = max(0, 4 - (w.round - self.last_shot.get(gid, -100)))
            if cooldown > 0:
                statuses[gid] = "cooldown"
                continue
            targets, damage = game._aim(w, dict(gun, cooldown=0), health)
            score = damage_score(w, damage, health)
            if not targets or not any(score):
                statuses[gid] = "no_effective_target"
                continue
            statuses[gid] = "ready"
            # A support square can reach only one of the three guns. For equal
            # main-shot value, leave that gun for a useful emergency extra shot.
            support_cost = bool(preserve_support and w.near(support, gun))
            candidates.append((tuple(-part for part in score), support_cost,
                               self.last_shot.get(gid, -100), gid, targets))
        self.context[label + "_weapons_status"] = statuses
        if not candidates:
            self.context[label + "_state"] = "cooldown_or_no_target"
            return False
        _, _, _, gid, targets = min(candidates)
        commands[gid] = {"action": "attack", "controllerId": rid,
                         "targetPos": [{"x": cell[0], "y": cell[1]} for cell in targets]}
        self.context[label + "_state"] = "attack_proposed"
        self.context[label + "_selected_weapon"] = gid
        if not hasattr(w, "defense_status"):
            w.defense_status = {}
        w.defense_status.update(statuses)
        w.defense_status[gid] = "attack_proposed"
        return True

    def _safe_move(self, w, commands, game, person, goal):
        reserved = self._reserved(commands) | set(getattr(w, "move_avoid", {}).get(str(person["id"]), ()))
        route = w.route(person, {goal}, reserved=reserved)
        if route.steps and endangered(w, person, route.steps[0]):
            self.context["unsafe_return_step"] = str(person["id"])
            return False
        # Preserve the normal move planner's blocked-route/yield registration.
        return game._put_move(w, commands, person, {goal})

    def _handoff_actions(self, w, commands, game):
        existing = set(commands)
        super()._handoff_actions(w, commands, game)
        for rid in set(commands) - existing:
            command = commands[rid]
            person = w.own.get(rid)
            if (person and command.get("action") == "move"
                    and endangered(w, person, pos(command["targetPos"][0]))):
                del commands[rid]
                self.context["state"] = "handoff_wait_for_safe_step"

    def step(self, w, commands, game, excluded=()):
        if not w.night:
            return False
        if self.assigned_round != w.round:
            self.assign(w, commands)
        if self.evacuate:
            rid, cell = self.evacuate
            if rid in w.own and rid not in _used(commands):
                game._put_move(w, commands, w.own[rid], {cell})
        self._handoff_actions(w, commands, game)
        person = w.own.get(self.primary)
        if person is None:
            self.context["state"] = "no_operator"
        elif self.primary in _used(commands) | {str(rid) for rid in excluded}:
            self.context["state"] = "operator_action_reserved"
        elif self.stand is None:
            self.context["state"] = "no_reachable_control_position"
        elif pos(person) != self.stand and not self.handoff:
            moved = self._safe_move(w, commands, game, person, self.stand)
            self.context["state"] = "travel" if moved else "travel_blocked"
        else:
            escape = self._escape(w, person, commands)
            if escape is not None:
                game._put_move(w, commands, person, {escape})
                self.context["state"] = "operator_escape"
            else:
                self._fire(w, commands, game, self.primary, "main")
                self.context["state"] = self.context.get("main_state", "attack_disabled")
        return True

    def support_step(self, w, commands, game, takeover_only=False):
        """Fire only; maintenance gets its own opportunity before positioning."""
        if not w.night or self.support_id is None or self.support_id == self.primary:
            return False
        person = w.own.get(self.support_id)
        if person is None or self.support_id in _used(commands):
            return False
        # A personal escape has priority, even when this method is used alone.
        escape = self._escape(w, person, commands)
        if escape is not None:
            self.context["support_state"] = "escape_required"
            return False
        _, valid = self._projected_health(w, commands)
        main_fired = any(command.get("action") == "attack"
                         and str(command.get("controllerId")) == self.primary
                         for command in valid.values())
        if takeover_only:
            if main_fired:
                return False
        else:
            main = w.own.get(self.primary)
            urgent = (bool(getattr(w, "wall_urgent", False)) or endangered(w, person)
                      or bool(main and endangered(w, main)))
            if not urgent:
                self.context["support_state"] = "maintenance_or_standby"
                return False
        fired = self._fire(w, commands, game, self.support_id, "support")
        if fired:
            self.context["support_reason"] = "takeover" if takeover_only else "urgent_extra_fire"
        return fired

    def support_return(self, w, commands, game):
        person = w.own.get(self.support_id)
        if (person is None or self.support_stand is None or self.support_id in _used(commands)
                or not (w.night or self.support_returning) or pos(person) == self.support_stand):
            return False
        if endangered(w, person, self.support_stand):
            self.context["support_state"] = "stand_unsafe"
            return False
        moved = self._safe_move(w, commands, game, person, self.support_stand)
        self.context["support_state"] = "return" if moved else "return_blocked"
        return moved
