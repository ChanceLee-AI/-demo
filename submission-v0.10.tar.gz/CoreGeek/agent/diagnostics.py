"""Bounded battle observations; action legality is not evidence of damage or kills."""
import json
import logging
from collections import Counter

from . import VERSION
from .defense import number
from .world import PEOPLE, WEAPONS, dist, pos

LOG = logging.getLogger("futurewar")
MAX_LOG_BYTES = 24576
MAX_ROBOTS = 64
MAX_TASK_LOG_CHARS = 8000


def _compact_task(value, text_limit, depth=0):
    """The task trace owns body budgets; this bounds aggregate status events."""
    if isinstance(value, str):
        return value if len(value) <= text_limit else value[:text_limit] + "[truncated]"
    if depth >= 6:
        return "[truncated]"
    if isinstance(value, dict):
        return {str(k)[:80]: _compact_task(v, text_limit, depth + 1)
                for k, v in list(value.items())[:40]}
    if isinstance(value, (list, tuple)):
        return [_compact_task(v, text_limit, depth + 1) for v in value[-16:]]
    return value


def emit(event, report):
    """Bound logs as valid JSON; an unavailable sink must not affect decisions."""
    try:
        data = json.dumps(report, ensure_ascii=False, separators=(",", ":"), allow_nan=False)
        if event == "task" and len(event) + 1 + len(data) > MAX_TASK_LOG_CHARS:
            for limit in (512, 128, 32, 0):
                compact = _compact_task(report, limit)
                compact.update(log_truncated=True, original_record_chars=len(data))
                bounded = json.dumps(compact, ensure_ascii=False, separators=(",", ":"), allow_nan=False)
                if len(event) + 1 + len(bounded) <= MAX_TASK_LOG_CHARS:
                    data = bounded
                    break
            else:
                data = json.dumps({"version": VERSION, "round": report.get("round"),
                                   "task_token": str(report.get("task_token", ""))[:80],
                                   "log_truncated": True, "reason": "status_record_too_large"})
        if len(data.encode("utf-8")) > MAX_LOG_BYTES:
            # Keep core observations even for unusually large synthetic inputs.
            compact = dict(report)
            for key in ("robots", "robot_changes", "mine_estimates", "events", "loss_groups"):
                if isinstance(compact.get(key), list):
                    compact[key] = compact[key][:8]
            compact["log_truncated"] = True
            data = json.dumps(compact, ensure_ascii=False, separators=(",", ":"), allow_nan=False)
            if len(data.encode("utf-8")) > MAX_LOG_BYTES:
                data = json.dumps({"version": VERSION, "round": report.get("round"),
                                   "log_truncated": True, "reason": "record_too_large"})
        LOG.info("%s %s", event, data)
    except Exception:
        pass


class BattleDiagnostics:
    def __init__(self):
        self.last_round = None
        self.previous = {}
        self.pending_attacks = {}
        self.metrics = Counter()
        self.loss_groups = []
        self.last_report = None
        self.previous_robots = {}
        self.previous_resources = None
        self.pending_economy = {}
        self.last_economy_report = None
        self.last_wall_report = None
        self.last_medical_report = None
        self.survival_trace = None

    def observe(self, w, response, game=None, tasks=None):
        if self.last_round is not None and w.round <= self.last_round:
            return
        raw_roles = (w.raw.get("teamOur") or {}).get("roles", [])
        present = {str(r["id"]): r for r in raw_roles if isinstance(r, dict) and "id" in r}
        results = w.raw.get("lastRoundRoleActionResults") or {}
        results = {str(k): v for k, v in results.items()} if isinstance(results, dict) else {}
        feedback = {}
        for gid, controller in self.pending_attacks.items():
            value = results.get(gid) if w.round == self.last_round + 1 else None
            status = "legal" if value is True else "rejected" if value is False else "missing"
            self.metrics["attack_feedback_" + status] += 1
            feedback[gid] = {"controller": controller, "status": status}

        units = {rid: {"type": r.get("roleType"), "hp": r.get("health", 0),
                       "pos": list(pos(r)), "level": r.get("level", 1)}
                 for rid, r in w.own.items() if r.get("roleType") in PEOPLE + WEAPONS + ("station",)}
        losses, base_loss = [], 0
        for rid, before in self.previous.items():
            now = units.get(rid)
            if now is None:
                explicit = present.get(rid)
                reason = "dead" if explicit and explicit.get("health", 1) <= 0 else "absent"
                losses.append({"id": rid, "type": before["type"], "observation": reason})
            if before["type"] == "station":
                # A missing base is recorded separately; absence alone is not HP=0.
                after_hp = now["hp"] if now else present.get(rid, {}).get("health")
                if isinstance(after_hp, (int, float)):
                    base_loss += max(0, before["hp"] - after_hp)
        if losses:
            self.loss_groups.append({"observed_round": w.round, "units": losses})
            self.loss_groups = self.loss_groups[-12:]

        sent = {str(gid): str(c["controllerId"]) for gid, c in response["roleCommandMap"].items()
                if c.get("action") == "attack" and "controllerId" in c}
        self.metrics["attacks_sent"] += len(sent)
        self.pending_attacks = sent
        previous_round = self.last_round
        self.previous, self.last_round = units, w.round
        assignments = {str(rid): {"weapon_id": str(a["weapon_id"]), "pos": list(a["pos"])}
                       for rid, a in getattr(w, "defense_assignments", {}).items()}
        score = (w.raw.get("teamOur") or {}).get("totalScore", 0)
        robot_rows, changes, omitted, changes_omitted = self._robots(w)
        report = {"version": VERSION, "round": w.round, "day": w.day,
                  "night": w.night, "gold": w.gold, "score": score, "units": units,
                  "assignments": assignments, "attacks_sent": sent,
                  "refuges": {str(rid): list(cell) for rid, cell in getattr(w, "defense_refuges", {}).items()},
                  "previous_attack_feedback": feedback, "base_hp_loss": base_loss,
                  "losses_observed": losses, "loss_groups": self.loss_groups,
                  "shots": {str(gid): {"controller": str(c["controllerId"]),
                                         "targets": c.get("targetPos", [])}
                            for gid, c in response["roleCommandMap"].items()
                            if c.get("action") == "attack" and "controllerId" in c},
                  "guns": self._guns(w, response, game),
                  "defense_decisions": {
                      str(rid): dict(details,
                                     move_sent=response["roleCommandMap"].get(str(rid), {}).get("action") == "move")
                      for rid, details in getattr(w, "defense_risk", {}).items()},
                  "robots": robot_rows, "robots_omitted": omitted,
                  "robot_changes": changes, "robot_changes_omitted": changes_omitted,
                  "metrics": dict(self.metrics)}
        self.last_report = report
        # First-night preparation and combat need useful detail without model text.
        milestone = w.turn in (0, 59, 64, 69, 70, 129) or (w.night and (w.turn - 70) % 10 == 0)
        changed = bool(losses or base_loss or any(f["status"] == "rejected" for f in feedback.values()))
        if w.night or milestone or changed:
            emit("battle", report)
        for name in ("rotation", "night_economy"):
            context = getattr(w, name + "_context", None)
            if isinstance(context, dict) and (w.night or milestone or context.get("events")):
                emit(name, dict(context, version=VERSION, round=w.round, day=w.day,
                                night=w.night, gold=w.gold))
        self._economy(w, response, game, previous_round)
        self._walls(w, response, game)
        self._medical(w, response, game)
        if game is not None and getattr(game, "survival", False):
            if self.survival_trace is None:
                from .survival_trace import SurvivalTrace
                self.survival_trace = SurvivalTrace()
            self.survival_trace.observe(w, response, game, emit)
        resources = (w.gold, score)
        if resources != self.previous_resources:
            before = self.previous_resources
            delta = {"gold": w.gold - before[0], "score": score - before[1]} if before else None
            emit("resources", {"version": VERSION, "round": w.round, "gold": w.gold,
                               "score": score, "observed_delta": delta,
                               "since_round": previous_round})
        self.previous_resources = resources
        task_report = getattr(tasks, "last_report", None)
        if isinstance(task_report, dict) and task_report.get("round") == w.round:
            if getattr(tasks, "active", None) or task_report.get("events"):
                emit("task", dict(task_report, version=VERSION))

    def _medical(self, w, response, game):
        context = getattr(w, "medical_context", None)
        if not isinstance(context, dict):
            return
        sent = {str(rid): dict(command) for rid, command in response["roleCommandMap"].items()
                if command.get("action") in ("buy", "use")
                and command.get("name") in ("Medicine", "medicine")}
        report = dict(context, version=VERSION, round=w.round, day=w.day,
                      night=w.night, gold=w.gold, sent=sent,
                      observed_roles={str(p["id"]): {
                          "hp": p.get("health"), "pos": list(pos(p)),
                          "medicine": sum(item in ("Medicine", "medicine") for item in p.get("backpack", []))}
                          for p in w.people})
        self.last_medical_report = report
        if sent or context.get("events") or context.get("plan") or w.turn % 5 == 0:
            emit("medical", report)

    def _walls(self, w, response, game):
        layout = getattr(game, "layout", None)
        construction = getattr(game, "construction", None)
        if layout is None or construction is None:
            return
        actual = {pos(r) for r in w.own.values() if r.get("roleType") == "wall"}
        sent = {str(rid): dict(c) for rid, c in response["roleCommandMap"].items()
                if c.get("action") == "build"}
        report = dict(getattr(w, "wall_work", {}) or {}, version=VERSION, round=w.round,
                      day=w.day, night=w.night, target_count=len(layout.targets),
                      observed_completed=len(actual.intersection(layout.targets)),
                      observed_positions=[list(p) for p in sorted(actual)],
                      gate=list(layout.gate) if layout.gate is not None else None,
                      layout_reason=layout.reason,
                      reserved_stone=getattr(w, "reserved_stone", {}),
                      construction_sent=sent, previous_construction_events=construction.events,
                      failures_today=construction.failures_today("wall"),
                      disabled_types=sorted(construction.disabled_kinds),
                      uncertain_paused_types=sorted(construction.paused_kinds))
        self.last_wall_report = report
        if w.night or w.turn % 5 == 0 or sent or construction.events:
            emit("walls", report)

    def _robots(self, w):
        rows, changes = [], []
        current = {str(r["id"]): r for r in w.robots if "id" in r}
        for rid, before in self.previous_robots.items():
            now = current.get(rid)
            if now is None:
                changes.append({"id": rid, "observation": "absent", "previous_hp": before})
            elif now.get("health") != before:
                changes.append({"id": rid, "observation": "hp_changed", "previous_hp": before,
                                "hp": now.get("health")})
        footprint = w.footprint(w.station) if w.station else set()
        def distance(robot):
            return min((dist(robot, c) for c in footprint), default=999)
        relevant = [r for r in w.robots if distance(r) <= number(r.get("attackRange"), 3) + 1
                    or any(dist(g, r) <= g.get("attackRange", 0) for g in w.weapons)]
        relevant.sort(key=lambda r: (distance(r), str(r.get("id", ""))))
        robot_power = {"smallRobot": 5, "middleRobot": 10, "largeRobot": 20, "bossRobot": 40}
        for robot in relevant[:MAX_ROBOTS]:
            rows.append({"id": str(robot.get("id", "")), "type": robot.get("roleType"),
                         "pos": list(pos(robot)), "hp": robot.get("health"),
                         "target_team": robot.get("targetTeam"),
                         "attack_range": number(robot.get("attackRange"), 3),
                         "attack_power": number(robot.get("attackPower"), robot_power.get(robot.get("roleType"), 10)),
                         "state": robot.get("abnormalState", "")})
        # No kill counter: attacks by the opponent and dawn removal are possible.
        self.previous_robots = {rid: r.get("health") for rid, r in list(current.items())[:512]}
        return (rows, changes[:MAX_ROBOTS], max(0, len(relevant) - MAX_ROBOTS),
                max(0, len(changes) - MAX_ROBOTS))

    @staticmethod
    def _guns(w, response, game):
        commands, result = response["roleCommandMap"], {}
        details = getattr(w, "defense_status", {})
        used = {str(c["controllerId"]) for c in commands.values() if "controllerId" in c}
        for gun in w.weapons:
            gid = str(gun["id"])
            controller = next((rid for rid, a in w.defense_assignments.items()
                               if a["weapon_id"] == gid), None)
            cooldown = gun.get("cooldown")
            if cooldown is None and gun.get("roleType") == "rocket":
                last = getattr(game, "last_shot", {}).get(gid, -100)
                cooldown = max(0, 4 - (w.round - last))
            command = commands.get(gid, {})
            if getattr(game, "continuous", False):
                shared = getattr(w, "rotation_primary", None)
                if command.get("action") == "attack":
                    controller = str(command.get("controllerId"))
                elif shared in w.own and w.near(w.own[shared], gun):
                    controller = shared
            if command.get("action") == "attack":
                reason = "attack_sent"
                if gun.get("cooldown") is None:
                    cooldown = 0
            elif not w.night:
                reason = "daylight"
            elif controller is None:
                reason = "no_controller"
            elif controller in commands or controller in used:
                reason = "controller_" + commands.get(controller, {}).get("action", "occupied")
            elif cooldown and cooldown > 0:
                reason = "cooldown"
            elif controller not in w.own or not w.near(w.own[controller], gun):
                reason = "not_at_gun"
            elif gid not in details and w.expired():
                reason = "local_budget"
            else:
                reason = details.get(gid, "no_effective_target")
                if reason == "attack_sent":
                    reason = "attack_filtered"
            result[gid] = {"controller": controller, "cooldown": cooldown,
                           "reason": reason, "range": gun.get("attackRange"),
                           "power": gun.get("attackPower"),
                           "move_reason": getattr(w, "defense_move_reasons", {}).get(controller)
                           if commands.get(controller, {}).get("action") == "move" else None}
        return result

    def _economy(self, w, response, game, previous_round):
        context = dict(getattr(game, "economy_context", {}) or {})
        results = w.raw.get("lastRoundRoleActionResults") or {}
        results = {str(k): v for k, v in results.items()} if isinstance(results, dict) else {}
        feedback = {rid: {"action": command["action"],
                          "status": ("legal" if results.get(rid) is True else
                                     "rejected" if results.get(rid) is False else "missing")
                          if previous_round == w.round - 1 else "missing"}
                    for rid, command in self.pending_economy.items()}
        sent = {str(rid): dict(c) for rid, c in response["roleCommandMap"].items()
                if c.get("action") in ("collect", "sell", "buy", "use")}
        self.pending_economy = sent
        report = dict(context, version=VERSION, round=w.round, gold=w.gold,
                      score=(w.raw.get("teamOur") or {}).get("totalScore", 0),
                      observed_workers={str(p["id"]): {"pos": list(pos(p)),
                                                       "stock": dict(Counter(p.get("backpack", [])))}
                                        for p in w.workers},
                      sent=sent, previous_action_feedback=feedback)
        self.last_economy_report = report
        idle = any(str(p["id"]) not in response["roleCommandMap"] for p in w.workers)
        if (getattr(game, "continuous", False) and w.night or
                (not w.night and (w.turn % 5 == 0 or idle or context.get("events"))) or sent or feedback):
            emit("economy", report)
