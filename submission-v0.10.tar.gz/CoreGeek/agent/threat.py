"""Bounded potential damage, never a claim about the judge's robot AI.

No building shielding or same-turn kill cancellation is assumed. The extra
one-cell envelope is a conservative warning, not a predicted robot trajectory.
"""
from .defense import number
from .world import dist, pos


POWER = {"smallRobot": 5, "middleRobot": 10, "largeRobot": 20, "bossRobot": 40}


def maximum_health(role):
    for key in ("maxHealth", "maxHp", "healthMax"):
        value = role.get(key)
        if isinstance(value, (int, float)) and value > 0:
            return value
    return 220 if role.get("roleType") == "worker" else 200


def health_margin(role):
    return maximum_health(role) * 0.2


def _damage(w, cell, future=False):
    key = (pos(cell), bool(future))
    cache = getattr(w, "_threat_damage", None)
    if cache is None:
        cache = w._threat_damage = {}
    if key not in cache:
        cache[key] = sum(number(robot.get("attackPower"), POWER.get(robot.get("roleType"), 10))
                         for robot in w.robots
                         if (future or robot.get("abnormalState") != "dizzy")
                         and dist(robot, cell) <= number(robot.get("attackRange"), 3) + int(future))
    return cache[key]


def current_damage(w, cell):
    return _damage(w, cell)


def next_damage(w, cell):
    return _damage(w, cell, True)


def two_turn_damage(w, cell):
    return current_damage(w, cell) + next_damage(w, cell)


def endangered(w, role, cell=None):
    damage = two_turn_damage(w, pos(role) if cell is None else cell)
    return damage > 0 and damage >= number(role.get("health"), 1) - health_margin(role)


def medicine_helps(w, role):
    return (number(role.get("health")) < maximum_health(role)
            and two_turn_damage(w, pos(role)) < maximum_health(role) - health_margin(role))


def safe_escape(w, role, commands, forbidden=()):
    if not endangered(w, role):
        return None
    reserved = {pos(cell) for command in commands.values() if command.get("action") in ("move", "build")
                for cell in command.get("targetPos", [])}
    rid = str(role["id"])
    blocked = (w.occupied | reserved | set(forbidden)
               | set(getattr(w, "move_avoid", {}).get(rid, ())))
    here = two_turn_damage(w, pos(role))
    options = [cell for cell in w.neighbors(pos(role))
               if cell not in blocked and current_damage(w, cell) < number(role.get("health"), 1)
               and two_turn_damage(w, cell) < here]
    return min(options, key=lambda cell: (two_turn_damage(w, cell), current_damage(w, cell), cell)) if options else None


def _tiers(w):
    cached = getattr(w, "_threat_tiers", None)
    if cached is not None:
        return cached
    operator_ids = set(getattr(w, "gunner_roles", ()))
    operator_ids.update(rid for rid in (getattr(w, "rotation_primary", None), getattr(w, "support_id", None)) if rid)
    if w.pioneer:
        operator_ids.add(str(w.pioneer["id"]))
    operators = [w.own[rid] for rid in operator_ids if rid in w.own and endangered(w, w.own[rid])]
    keys = set(getattr(w, "maintenance_targets", ()))
    walls = [r for r in w.own.values() if r.get("roleType") == "wall" and pos(r) in keys]
    cached = {}
    for robot in w.robots:
        reach = number(robot.get("attackRange"), 3) + 1
        threatening = any(dist(robot, role) <= reach for role in operators)
        defensive = (not robot.get("targetTeam") or robot.get("targetTeam") == w.team_type)
        front = (any(dist(robot, wall) <= reach for wall in walls)
                 or (w.station and min(dist(robot, cell) for cell in w.footprint(w.station)) <= reach))
        cached[str(robot["id"])] = 0 if threatening else 1 if front and defensive else 2
    w._threat_tiers = cached
    return cached


def damage_score(w, damage, health):
    """Lexicographic urgency, fractional attack-power removal, then damage.

    A kill earns its full attack-power value. Fractional progress approximates
    required hits without blindly favouring either the highest HP or a crowd.
    This score does not alter any survival estimate for the current response.
    """
    tiers = _tiers(w)
    scores = [0.0, 0.0, 0.0]
    effective, kills = 0.0, 0
    for robot in w.robots:
        rid = str(robot["id"])
        hp = number(health.get(rid))
        hit = min(hp, number(damage.get(rid)))
        if hp <= 0 or hit <= 0:
            continue
        power = number(robot.get("attackPower"), POWER.get(robot.get("roleType"), 10))
        weight = 1.0 if not robot.get("targetTeam") or robot.get("targetTeam") == w.team_type else 0.25
        if robot.get("abnormalState") == "dizzy":
            weight *= 0.8
        scores[tiers.get(rid, 2)] += weight * power * (hit / hp + int(hit >= hp))
        effective += hit * weight
        kills += hit >= hp
    return tuple(scores) + (effective, kills)


def score_value(score):
    """Rotation's legacy scalar interface, preserving urgency lexicographically."""
    return score[0] * 1e12 + score[1] * 1e6 + score[2] * 1e2 + score[3] + score[4]
