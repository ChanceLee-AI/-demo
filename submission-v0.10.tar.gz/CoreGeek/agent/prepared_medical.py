"""Daytime personal medicine stocks and early healing for the survival policy."""
from .medical import MedicalPlanner, MEDICINES, occupied_roles, travel_distance, wounded
from .threat import endangered, maximum_health, medicine_helps, safe_escape, two_turn_damage
from .world import action, pos


class PreparedMedicalPlanner(MedicalPlanner):
    @staticmethod
    def _returns(w, role):
        return (role.get("roleType") == "pioneer"
                or (w.day >= 3 and str(role["id"]) == getattr(w, "support_id", None)))

    def _trip(self, w, role):
        choices, rid = [], str(role["id"])
        for shop in w.zones:
            if w.expired():
                break
            if shop.get("neutralType") != "weaponShop":
                continue
            goals = {cell for cell in w.adjacent(shop)
                     if self.avoided_stands.get((rid, pos(shop), cell), 0) <= w.round}
            old = self.plan
            preferred = old.get("stand") if old and old["role"] == rid and pos(old["shop"]) == pos(shop) else None
            route = self._route(w, role, role, {preferred}) if preferred in goals else None
            if route is None or not route.reachable:
                route = self._route(w, role, role, goals)
            if not route.reachable:
                continue
            home_turns, margin = 0, 0
            if self._returns(w, role):
                home = self._home(w, role, route.goal)
                if not home.reachable:
                    continue
                home_turns, margin = travel_distance(home), w.return_margin
            # One purchase and a possible immediate healing action; stocks do
            # not force an otherwise economic worker to return to the base.
            turns = travel_distance(route) + 2 + home_turns
            if turns + margin <= w.daylight_left:
                choices.append({"shop": shop, "stand": route.goal, "turns": turns,
                                "home_turns": home_turns})
        old_shop = pos(self.plan["shop"]) if self.plan and self.plan["role"] == rid else None
        return min(choices, key=lambda trip: (pos(trip["shop"]) != old_shop, trip["turns"], pos(trip["shop"]))) if choices else None

    @staticmethod
    def _should_heal(w, role, commands=None):
        if role.get("health", 0) >= maximum_health(role):
            return False
        danger = endangered(w, role)
        if not wounded(role) and not danger:
            return False
        if danger and not medicine_helps(w, role):
            if safe_escape(w, role, commands or {}) is not None:
                return False
        return True

    def prepare(self, w):
        if self.round == w.round:
            self._publish(w)
            return
        self.round = w.round
        self.context = {"round": w.round, "roles": {}, "reserved_gold": 0,
                        "plan": None, "events": self._observe(w), "proactive_stocks": w.day >= 2}
        candidates = []
        for role in w.people:
            rid = str(role["id"])
            if self._busy(w, role):
                continue
            name = next((n for n in MEDICINES if n in (role.get("backpack") or [])), None)
            if name:
                if self._allowed(w, rid, "use") and self._should_heal(w, role):
                    self.context["roles"][rid] = {"stage": "use_owned", "name": name,
                                                  "hp": role["health"], "two_turn_damage": two_turn_damage(w, role)}
                continue
            if w.night or not (w.day >= 2 or wounded(role)):
                continue
            reason = None
            if len(role.get("backpack") or []) >= role.get("backPackCapability", 100 if role.get("roleType") == "worker" else 40):
                reason = "backpack_full"
            elif not self._allowed(w, rid, "buy") or not self._allowed(w, rid, "use"):
                reason = "medicine_action_disabled_or_paused"
            else:
                candidates.append(role)
            if reason:
                self.context["events"].append({"role": rid, "event": reason})
        name = next((n for n in MEDICINES if n in w.shop), None)
        guard = self._cash_guard(w) if not w.night else 0
        self.context["cash_guard"] = guard
        old_plan, choices = self.plan, []
        self.funding_goal = None
        if name:
            for role in candidates:
                if w.expired():
                    break
                trip = self._trip(w, role)
                if trip is None:
                    continue
                rid = str(role["id"])
                priority = (0 if rid == getattr(w, "rotation_primary", None) or role.get("roleType") == "pioneer"
                            else 1 if rid == getattr(w, "support_id", None) else 2)
                choices.append((priority, not (old_plan and old_plan["role"] == rid),
                                role["health"] / maximum_health(role), trip["turns"], rid, trip))
        if choices:
            _, _, _, _, rid, trip = min(choices, key=lambda item: item[:-1])
            self.funding_goal = {"kind": "medicine", "price": w.shop[name], "reserve": guard,
                                 "name": name, "role": rid}
        if choices and w.shop[name] <= w.gold - guard:
            self.plan = {"role": rid, "name": name, "price": w.shop[name], "stand": trip["stand"],
                         "shop": trip["shop"], "turns": trip["turns"], "home_turns": trip["home_turns"], "cash_guard": guard}
            self.context["reserved_gold"] = w.shop[name]
            self.context["roles"][rid] = {"stage": "buy", "name": name, "hp": w.own[rid]["health"]}
            self.context["plan"] = dict(self.plan)
        else:
            self.plan = None
            if candidates:
                reason = "medicine_unavailable" if name is None else (
                    "insufficient_observed_cash" if w.shop[name] > w.gold - guard else "medical_route_or_time")
                self.context["events"].append({"event": reason})
        self._publish(w)

    def use_owned(self, w, commands, held=()):
        used = occupied_roles(commands) | set(held)
        for rid, plan in self.context.get("roles", {}).items():
            role = w.own.get(rid)
            if (role and plan["stage"] == "use_owned" and rid not in used
                    and plan["name"] in (role.get("backpack") or []) and self._should_heal(w, role, commands)):
                commands[rid] = action("use", name=plan["name"])
