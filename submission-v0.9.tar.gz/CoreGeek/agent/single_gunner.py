"""Persistent one-gunner responsibility; other living workers remain economic."""
from .defense import exposure
from .medical import maximum_health
from .rotation import RocketRotation, _used
from .world import dist, pos


class SingleGunnerRotation(RocketRotation):
    def __init__(self):
        super().__init__()
        self.replacement = None
        self.replacement_reason = None
        self.stand = None
        self.pioneer_goal = None
        self.false_streak = {}
        self.stalls = {}
        self.progress = None
        self.fault_wait = False
        self.handoff = False
        self.evacuate = None
        self.assigned_round = None

    def _observe(self, w):
        if self.observed_round == w.round:
            return
        pending = list(self.pending.items())
        old_day = self.day
        super()._observe(w)
        for gid, sent in pending:
            if sent["round"] >= w.round:
                continue
            rid = sent["controller"]
            outcome = self._result(w, gid) if sent["round"] + 1 == w.round else None
            self.false_streak[rid] = self.false_streak.get(rid, 0) + 1 if outcome is False else 0
            if outcome is True and rid == self.replacement and self.fault_wait:
                self.fault_wait = False
                if w.pioneer:
                    self.false_streak[str(w.pioneer["id"])] = 0
        if self.progress:
            sent = self.progress
            person = w.own.get(sent["role"])
            count = 0
            if person and sent["round"] + 1 == w.round:
                route = w.plan_route(person, pos(person), {sent["goal"]})
                before, after = sent["distance"], route.distance
                stalled = (pos(person) == sent["pos"] if before is None or after is None else after >= before)
                if stalled and pos(person) != sent["goal"]:
                    count = self.stalls.get(sent["role"], 0) + 1
            self.stalls[sent["role"]] = count
            self.progress = None
        if old_day != w.day or not w.night:
            self.false_streak.clear()
            self.stalls.clear()

    @staticmethod
    def _guns(w):
        return sorted((gun for gun in w.weapons if gun.get("roleType") == "rocket"), key=lambda gun: str(gun["id"]))

    def _best_stand(self, w, person, previous=None, actual=False, ignore_people=(), require_route=True):
        if person is None:
            return None
        guns = self._guns(w)
        anchor = getattr(w, "rocket_anchor", None)
        anchor = tuple(anchor) if anchor is not None else None
        cells = {cell for gun in guns for cell in w.adjacent(gun)}
        if not cells:
            if anchor is not None and w.in_bounds(anchor) and anchor not in w.static:
                cells = {anchor}
            elif w.station:
                cells = w.adjacent(w.station)
        cells -= set(getattr(w, "wall_planned", ()))
        options = []
        for cell in sorted(cells):
            if w.expired():
                break
            route = (w.route(person, {cell}, ignore_people=ignore_people) if actual
                     else w.plan_route(person, pos(person), {cell}))
            if not route.reachable and require_route:
                continue
            risk = exposure(w, cell)
            coverage = sum(w.near(cell, gun) for gun in guns)
            score = (risk >= person.get("health", 1), -coverage, cell != anchor, cell != previous,
                     route.total_distance if route.total_distance is not None else 10000, risk, cell)
            options.append((score, cell))
        return min(options)[1] if options else None

    def _bind_one(self, w, rid, stand):
        if rid is None or stand is None:
            return
        guns = [gun for gun in self._guns(w) if w.near(stand, gun)]
        if guns:
            previous = w.defense_assignments.get(rid, {}).get("weapon_id")
            gid = previous if any(str(gun["id"]) == previous for gun in guns) else str(guns[0]["id"])
            w.defense_assignments[rid] = {"weapon_id": gid, "pos": stand}
            w.defense_refuges.pop(rid, None)
        else:
            w.defense_assignments.pop(rid, None)
            w.defense_refuges[rid] = stand

    def _publish_single(self, w, state=None):
        guns = self._guns(w)
        person = w.own.get(self.primary)
        covered = [str(gun["id"]) for gun in guns if self.stand is not None and w.near(self.stand, gun)]
        ready = bool(person and self.stand is not None and pos(person) == self.stand and covered)
        verified = self.verified.get(self.primary, set()).intersection(covered)
        gunner_roles = {self.primary} if self.primary in w.own else set()
        if self.handoff and w.pioneer:
            gunner_roles.add(str(w.pioneer["id"]))
        if self.evacuate and self.evacuate[0] in w.own:
            gunner_roles.add(self.evacuate[0])
        w.gunner_roles = gunner_roles
        w.economic_roles = {str(worker["id"]) for worker in w.workers} - ({self.replacement} if self.replacement else set())
        w.rotation_primary = self.primary
        w.rotation_ready = ready
        w.rotation_verified = bool(w.night and ready and set(covered).issubset(verified))
        w.rotation_failed = bool(self.false_streak.get(self.primary, 0) >= 2)
        w.rotation_protected_roles = set(gunner_roles)
        self.context = {"primary": self.primary, "anchor": self.stand,
                        "weapons": [str(gun["id"]) for gun in guns], "covered_weapons": covered,
                        "ready": ready, "verified": w.rotation_verified, "verified_guns": sorted(verified),
                        "failed": w.rotation_failed, "replacement": self.replacement,
                        "replacement_reason": self.replacement_reason, "handoff": self.handoff,
                        "economic_roles": sorted(w.economic_roles), "gunner_roles": sorted(gunner_roles),
                        "false_streak": self.false_streak.get(self.primary, 0),
                        "stalled_rounds": self.stalls.get(self.primary, 0), "events": list(self.events),
                        "state": state or ("ready" if ready else "return")}
        w.rotation_context = self.context

    def prepare(self, w):
        self._observe(w)
        if not w.night:
            self.replacement = None
            self.replacement_reason = None
            self.fault_wait = self.handoff = False
            self.evacuate = None
        if self.replacement not in w.own:
            self.replacement = None
        pioneer = w.pioneer
        pioneer_id = str(pioneer["id"]) if pioneer else None
        choice = self._best_stand(w, pioneer, self.pioneer_goal)
        if choice is None:
            # Keep a real control objective even when a pioneer starts in an
            # unreachable component. Three observed blocked turns may then
            # select a worker who actually can reach it; budget exhaustion is
            # still excluded from the progress failure counter.
            choice = self._best_stand(w, pioneer, self.pioneer_goal, require_route=False)
        if choice is not None:
            self.pioneer_goal = choice
        elif self.pioneer_goal is not None and self.pioneer_goal in w.static:
            self.pioneer_goal = None
        if (pioneer_id is not None and not self.replacement and getattr(w, "rocket_layout_ready", False)
                and self.pioneer_goal == getattr(w, "rocket_anchor", None)):
            # These are future route/cost metadata, not worker recall orders.
            # Preserve the layout's complete matching: one gun may have only
            # the shared anchor as an interior square, so assigning that gun
            # to a worker otherwise puts its return goal on a future wall and
            # incorrectly makes the last stone/construction trip too long.
            self._bind_planned(w, pioneer_id, self.pioneer_goal, self._guns(w))
        self._bind_one(w, pioneer_id, self.pioneer_goal)
        self.primary = self.replacement or pioneer_id
        person = w.own.get(self.primary)
        if self.replacement:
            choice = self._best_stand(w, person, self.stand)
            if choice is not None:
                self.stand = choice
        else:
            self.stand = self.pioneer_goal
        self._bind_one(w, self.primary, self.stand)
        self._publish_single(w)

    @staticmethod
    def _reserved(commands):
        return {pos(cell) for command in commands.values() if command.get("action") in ("move", "build")
                for cell in command.get("targetPos", [])}

    def _escape(self, w, person, commands):
        if person is None or exposure(w, pos(person)) < person.get("health", 1):
            return None
        blocked = w.occupied | self._reserved(commands) | set(getattr(w, "wall_planned", ()))
        choices = [cell for cell in w.neighbors(pos(person)) if cell not in blocked
                   and exposure(w, cell) < person.get("health", 1)]
        return min(choices, key=lambda cell: (exposure(w, cell), cell)) if choices else None

    def _choose_replacement(self, w, commands, ignore_pioneer=True):
        choices = []
        for worker in w.workers:
            rid = str(worker["id"])
            if rid in _used(commands) or rid in getattr(w, "medical_roles", set()):
                continue
            ignored = {str(w.pioneer["id"])} if w.pioneer and ignore_pioneer else set()
            stand = self._best_stand(w, worker, actual=True, ignore_people=ignored)
            if stand is None or not any(w.near(stand, gun) for gun in self._guns(w)):
                continue
            # Only a pioneer actually occupying the destination has an
            # explicit yield before replacement. Do not ignore its body along
            # an unrelated narrow transit route and call that route reachable.
            if ignored and pos(w.pioneer) != stand:
                ignored = set()
                if not w.route(worker, {stand}).reachable:
                    stand = self._best_stand(w, worker, actual=True)
                    if stand is None or not any(w.near(stand, gun) for gun in self._guns(w)):
                        continue
            route = w.route(worker, {stand}, ignore_people=ignored)
            if not route.reachable:
                continue
            choices.append((route.distance, -worker.get("health", 0) / maximum_health(worker), rid, stand))
        return min(choices)[2:] if choices else (None, None)

    def _recoverable(self, w, commands):
        pioneer = w.pioneer
        if (not pioneer or self.fault_wait or str(pioneer["id"]) in _used(commands)
                or getattr(w, "task_busy", False) or self.pioneer_goal is None
                or exposure(w, pos(pioneer)) >= pioneer.get("health", 1)
                or exposure(w, self.pioneer_goal) >= pioneer.get("health", 1)):
            return False
        route = w.plan_route(pioneer, pos(pioneer), {self.pioneer_goal})
        return route.reachable

    def assign(self, w, commands):
        """Lock exactly one gunner responsibility before either worker acts."""
        if self.assigned_round == w.round:
            self._publish_single(w)
            return
        self.assigned_round = w.round
        self.handoff = False
        self.evacuate = None
        if not w.night:
            self._publish_single(w, "day_tasks")
            return
        pioneer = w.pioneer
        pioneer_id = str(pioneer["id"]) if pioneer else None
        disabled = "attack" in getattr(w, "disabled_actions", set())
        if self.replacement:
            if not disabled and self._recoverable(w, commands):
                if pos(pioneer) == self.pioneer_goal:
                    self.replacement = None
                    self.replacement_reason = None
                    self.false_streak[pioneer_id] = 0
                    self.stalls[pioneer_id] = 0
                    self.primary, self.stand = pioneer_id, self.pioneer_goal
                else:
                    self.handoff = True
            self._bind_one(w, self.primary, self.stand)
            self._publish_single(w, "handoff" if self.handoff else "replacement")
            return
        reason = None
        if not disabled and self._guns(w):
            if pioneer is None:
                reason = "pioneer_dead"
            elif pioneer_id not in _used(commands):
                escape = self._escape(w, pioneer, commands)
                if escape is not None:
                    reason = "lethal_reposition"
                    self.evacuate = pioneer_id, escape
                elif self.false_streak.get(pioneer_id, 0) >= 2:
                    reason = "two_explicit_failures"
                elif self.stalls.get(pioneer_id, 0) >= 3:
                    reason = "three_rounds_no_progress"
        if reason:
            replacement, stand = self._choose_replacement(w, commands)
            if replacement is not None and pioneer is not None and pos(pioneer) == stand:
                blocked = w.occupied | self._reserved(commands) | set(getattr(w, "wall_planned", ()))
                passing = [cell for cell in w.neighbors(stand) if cell not in blocked
                           and exposure(w, cell) < pioneer.get("health", 1)]
                if passing:
                    self.evacuate = pioneer_id, min(passing, key=lambda cell: (exposure(w, cell), cell))
                else:
                    replacement, stand = self._choose_replacement(w, commands, ignore_pioneer=False)
            if replacement is not None:
                self.replacement = self.primary = replacement
                self.replacement_reason = reason
                self.stand = stand
                self.fault_wait = reason == "two_explicit_failures"
        self._bind_one(w, self.primary, self.stand)
        self._publish_single(w, "replacement" if self.replacement else "normal")

    def _handoff_actions(self, w, commands, game):
        pioneer = w.pioneer
        worker = w.own.get(self.replacement)
        if not self.handoff or pioneer is None or worker is None:
            return
        pid, wid = str(pioneer["id"]), str(worker["id"])
        goal = self.pioneer_goal
        if pid in _used(commands) or goal is None:
            return
        if pos(worker) == goal and dist(pioneer, goal) <= 1:
            blocked = w.occupied | self._reserved(commands) | set(getattr(w, "wall_planned", ()))
            options = [cell for cell in w.neighbors(goal) if cell not in blocked
                       and exposure(w, cell) < worker.get("health", 1)]
            if options and wid not in _used(commands):
                target = min(options, key=lambda cell: (-sum(w.near(cell, gun) for gun in self._guns(w)),
                                                        exposure(w, cell), cell))
                game._put_move(w, commands, worker, {target})
                self.context["state"] = "handoff_yield"
            return
        if goal not in w.occupied:
            game._put_move(w, commands, pioneer, {goal})
            self.context["state"] = "handoff_enter"
        else:
            staging = set(w.neighbors(goal)) - w.static - self._reserved(commands)
            staging = {cell for cell in staging if exposure(w, cell) < pioneer.get("health", 1)}
            if pos(pioneer) not in staging:
                game._put_move(w, commands, pioneer, staging)
            self.context["state"] = "handoff_approach"

    def step(self, w, commands, game, excluded=()):
        if not w.night:
            return False
        if self.assigned_round != w.round:
            self.assign(w, commands)
        if self.evacuate:
            rid, goal = self.evacuate
            if rid in w.own and rid not in _used(commands):
                game._put_move(w, commands, w.own[rid], {goal})
        self._handoff_actions(w, commands, game)
        person = w.own.get(self.primary)
        if person is None:
            self.context["state"] = "no_operator"
            return True
        if self.primary in _used(commands) | {str(rid) for rid in excluded}:
            self.context["state"] = "operator_action_reserved"
            return True
        if self.stand is None:
            self.context["state"] = "no_reachable_control_position"
            return True
        if pos(person) != self.stand and not self.handoff:
            moved = game._put_move(w, commands, person, {self.stand})
            self.context["state"] = "travel" if moved else "travel_blocked"
            return True
        if "attack" in getattr(w, "disabled_actions", set()):
            self.context["state"] = "attack_disabled"
            return True
        escape = self._escape(w, person, commands)
        if escape is not None:
            game._put_move(w, commands, person, {escape})
            self.context["state"] = "operator_escape"
            return True
        health = {str(robot["id"]): max(0, robot.get("health", 1)) for robot in w.robots}
        candidates, statuses = [], {}
        for gun in self._guns(w):
            gid = str(gun["id"])
            if gid in commands or not w.near(person, gun):
                statuses[gid] = "not_available_to_primary"
                continue
            cooldown = gun.get("cooldown")
            if cooldown is None:
                cooldown = max(0, 4 - (w.round - self.last_shot.get(gid, -100)))
            if cooldown > 0:
                statuses[gid] = "cooldown"
                continue
            targets, damage = game._aim(w, dict(gun, cooldown=0), health)
            score = self._value(w, damage, health)
            if not targets or score <= 0:
                statuses[gid] = "no_effective_target"
                continue
            statuses[gid] = "ready"
            candidates.append((-score, self.last_shot.get(gid, -100), gid, targets))
        self.context["weapons_status"] = statuses
        if not candidates:
            self.context["state"] = "cooldown_or_no_target"
            return True
        _, _, gid, targets = min(candidates)
        commands[gid] = {"action": "attack", "controllerId": self.primary,
                         "targetPos": [{"x": cell[0], "y": cell[1]} for cell in targets]}
        self.context["state"] = "attack_proposed"
        self.context["selected_weapon"] = gid
        if not hasattr(w, "defense_status"):
            w.defense_status = {}
        w.defense_status.update(statuses)
        w.defense_status[gid] = "attack_proposed"
        return True

    def record(self, w, final_commands):
        super().record(w, final_commands)
        if self.progress and self.progress["round"] == w.round:
            return
        person = w.own.get(self.primary)
        state = self.context.get("state")
        own_command = final_commands.get(self.primary, {})
        if (w.night and person and self.stand is not None and pos(person) != self.stand
                and state in ("travel", "travel_blocked", "no_reachable_control_position")
                and own_command.get("action") in (None, "move")):
            route = w.plan_route(person, pos(person), {self.stand})
            if route.status != "budget_exhausted":
                self.progress = {"round": w.round, "role": self.primary, "pos": pos(person),
                                 "goal": self.stand, "distance": route.distance}
        elif self.primary is not None:
            self.stalls[self.primary] = 0
