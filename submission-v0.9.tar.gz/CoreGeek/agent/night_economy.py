"""Short, recallable worker trips while a verified pioneer operates the rockets.

This planner has its own night deadline. It never changes World's daylight or
reuses daytime actions by pretending the observation is daytime.
"""
from collections import Counter
import re

from .defense import exposure
from .economy import MINERALS, mine_key, sellable_inventory
from .medical import maximum_health, occupied_roles
from .world import PathResult, action, dist, pos


class NightEconomy:
    def __init__(self):
        self.jobs = {}
        self.pending = {}
        self.round = None
        self.day = None
        self.previous_health = {}
        self.losses = []
        self.disabled = False
        self.disabled_reason = ""
        self.first_release_round = None
        self.last_alarm_round = None
        self.quiet_rounds = 0
        self.last_step = None
        self.cooldown = {}
        self.bad_mines = {}
        self.context = {}
        self._world = None
        self._risk = set()
        self.previous_gold = None

    @staticmethod
    def _backup(w, rid):
        assignment = getattr(w, "defense_assignments", {}).get(str(rid))
        return tuple(assignment["pos"]) if assignment and assignment.get("pos") is not None else None

    @staticmethod
    def _healthy(role):
        if not role:
            return False
        if role.get("roleType") == "station":
            maximum = role.get("maxHealth", 1500 * max(1, int(role.get("level", 1))))
        else:
            maximum = maximum_health(role)
        return role.get("health", 0) > maximum / 2

    def _event(self, event, **fields):
        events = self.context.setdefault("events", [])
        if len(events) < 16:
            events.append(dict(event=event, **fields))

    def _publish(self, w):
        w.night_economy_roles = set(self.jobs)
        self.context.update(round=w.round, day=w.day, night=w.night, disabled=self.disabled,
                            disabled_reason=self.disabled_reason, quiet_rounds=self.quiet_rounds,
                            first_release_round=self.first_release_round,
                            workers={rid: {key: job[key] for key in (
                                "stage", "started", "deadline", "backup", "mine", "remaining",
                                "reason", "return_turns", "stalled") if key in job}
                                     for rid, job in self.jobs.items()})
        w.night_economy_context = self.context

    def prepare(self, w):
        if self.round == w.round:
            self._publish(w)
            return
        self.context = {"events": []}
        self.losses = []
        gold_delta = w.gold - self.previous_gold if self.round is not None and self.round + 1 == w.round else None
        self.context.update(observed_team_gold_delta=gold_delta, collected_count=0,
                            sale_inventory_confirmed=0, expected_sale_value=0)
        self.previous_gold = w.gold
        now = {str(role["id"]): role.get("health", 0) for role in w.people + ([w.station] if w.station else [])}
        if self.round is not None and self.round + 1 == w.round:
            self.losses = [rid for rid, hp in self.previous_health.items() if now.get(rid, 0) < hp]
        self.previous_health = now
        if not w.night or self.day != w.day:
            self.jobs.clear()
            self.pending.clear()
            self.first_release_round = self.last_alarm_round = None
            self.quiet_rounds = 0
            self.cooldown.clear()
            self.bad_mines.clear()
        else:
            results = w.raw.get("lastRoundRoleActionResults") or {}
            results = {str(key): value for key, value in results.items()} if isinstance(results, dict) else {}
            valid_sales = []
            for rid, sent in self.pending.items():
                job, worker = self.jobs.get(rid), w.own.get(rid)
                if not job or sent["round"] + 1 != w.round:
                    continue
                if not worker:
                    continue
                stock = Counter(worker.get("backpack") or [])
                if sent["action"] == "collect":
                    gained = max(0, stock[sent["mineral"]] - sent["stock"].get(sent["mineral"], 0))
                    job["remaining"] = max(0, job.get("remaining", 0) - gained)
                    success = gained > 0 and results.get(rid) is not False
                    self._event("collect_observed", role_id=rid, gained=gained, confirmed=success)
                    self.context["collected_count"] += gained
                    if not success:
                        self.bad_mines[job.get("mine")] = w.round + 5
                        self._return_one(w, rid, "collect_not_confirmed")
                elif sent["action"] == "sell":
                    decrease = sent["stock"].get(sent["name"], 0) - stock[sent["name"]]
                    success = decrease >= sent["num"] and results.get(rid) is not False
                    self._event("sale_observed", role_id=rid, mineral=sent["name"],
                                decrease=decrease, inventory_confirmed=success,
                                expected_sale_value=sent.get("sale_value", 0))
                    self.context["expected_sale_value"] += sent.get("sale_value", 0)
                    if success:
                        self.context["sale_inventory_confirmed"] += sent["num"]
                        valid_sales.append(sent.get("sale_value", 0))
                    if not success:
                        self._return_one(w, rid, "sale_not_confirmed")
                elif sent["action"] == "move" and pos(worker) == sent.get("position"):
                    job["last_blocked_step"] = pos(sent["targetPos"][0])
            if self.context["expected_sale_value"]:
                expected = sum(valid_sales)
                cash_confirmed = bool(expected and gold_delta is not None and gold_delta >= expected)
                self.context["sale_batch_cash_confirmed"] = cash_confirmed
                self.context["confirmed_sale_batch_value"] = expected if cash_confirmed else 0
                self._event("sale_batch_observed", expected_inventory_matched_value=expected,
                            observed_team_gold_delta=gold_delta, cash_confirmed=cash_confirmed)
            self.pending.clear()
            for rid, job in list(self.jobs.items()):
                worker = w.own.get(rid)
                if not worker:
                    self.jobs.pop(rid, None)
                    self._event("worker_lost", role_id=rid)
                    continue
                marker = (pos(worker), tuple(sorted(Counter(worker.get("backpack") or []).items())))
                same = job.get("observed_round", -2) + 1 == w.round and job.get("marker") == marker
                job["stalled"] = job.get("stalled", 0) + 1 if same else 0
                job["observed_round"], job["marker"] = w.round, marker
                if job["stalled"] >= 3 and job["stage"] == "return":
                    job["return_avoid"] = job.get("last_blocked_step")
                    job["return_avoid_until"] = w.round + 3
                    job["stalled"] = 0
                    self._event("return_route_replan", role_id=rid, reason="three_rounds_no_progress",
                                deadline=job["deadline"])
                elif job["stalled"] >= 3:
                    job["replan"] = True
                    job["avoid_stand"] = job.get("mine_stand") if job["stage"] == "mine" else job.get("sale_stand")
                    job["stalled"] = 0
                    self._event("trip_replan", role_id=rid, reason="three_rounds_no_progress", deadline=job["deadline"])
        self.round, self.day = w.round, w.day
        self._publish(w)

    def _risk_cells(self, w):
        if self._world is w:
            return self._risk
        self._world = w
        risk = set()
        for robot in w.robots:
            reach = max(0, int(robot.get("attackRange", 3))) + 2
            x, y = pos(robot)
            risk.update((xx, yy) for xx in range(max(0, x - reach), min(w.width, x + reach + 1))
                        for yy in range(max(0, y - reach), min(w.height, y + reach + 1)))
        self._risk = risk
        return risk

    def _route(self, w, worker, start, goals, reserved=(), dynamic=False, safe=True):
        """Risk-aware paths keep hypothetical obstacles in both search modes."""
        start = pos(start)
        goals = {pos(cell) for cell in goals if w.in_bounds(cell)}
        friendly = {pos(role) for role in w.people}
        blocked = w.static | (w.occupied if dynamic else w.occupied - friendly) | set(reserved)
        primary = w.own.get(str(getattr(w, "rotation_primary", "")))
        if primary and str(primary["id"]) != str(worker["id"]):
            blocked.add(pos(primary))  # The active gunner is not temporary traffic.
        if safe:
            blocked |= self._risk_cells(w)
        if start in w.static or not goals or not w.in_bounds(start):
            return PathResult("unreachable")
        blocked.discard(start)  # A newly endangered worker may move out of danger.
        goals -= blocked
        if w.expired():
            return PathResult("budget_exhausted")
        if start in goals:
            return PathResult("arrived", [], goal=start)
        if not goals:
            return PathResult("unreachable")
        steps, complete = w._search(start, goals, blocked, ("night_economy", start, frozenset(blocked)))
        if steps is None:
            return PathResult("unreachable" if complete else "budget_exhausted")
        others = {pos(role) for role in w.people if str(role["id"]) != str(worker["id"])}
        delay = 2 if not dynamic and others.intersection(steps) else 0
        route = PathResult("reachable", steps, goal=steps[-1], delay=delay)
        route.planning_status = "blocked" if delay else "reachable"
        return route

    def _home(self, w, worker, start, backup):
        if backup is None:
            return PathResult("unreachable")
        start = pos(start)
        if start not in self._risk_cells(w) and backup not in self._risk_cells(w):
            # A fixed backup lets all candidate stands share one BFS tree.
            reverse = self._route(w, worker, backup, {start})
            if not reverse.reachable:
                return reverse
            steps = list(reversed([backup] + reverse.steps))[1:]
            route = PathResult("reachable" if steps else "arrived", steps, goal=backup)
            other_people = {pos(role) for role in w.people if str(role["id"]) != str(worker["id"])}
            route.planning_status = "blocked" if other_people.intersection(steps) else route.status
        else:
            route = self._route(w, worker, start, {backup})
        if route.reachable and route.distance:
            route.delay = max(route.delay, 2)  # Future standby traffic may return before this trip.
        return route

    def _return_one(self, w, rid, reason):
        job = self.jobs.get(rid)
        if job:
            if job["stage"] != "return":
                self._event("recall", role_id=rid, reason=reason, deadline=job["deadline"])
            job["stage"], job["reason"] = "return", reason
            self.cooldown[rid] = max(self.cooldown.get(rid, 0), w.round + 5)

    def _alarm(self, w, commands):
        primary = str(getattr(w, "rotation_primary", ""))
        pioneer = w.own.get(primary)
        if not self._healthy(w.station):
            return "base_not_healthy"
        if self.losses:
            key = str(w.station["id"]) if w.station else ""
            if key in self.losses:
                return "base_hp_loss"
            if primary in self.losses:
                return "primary_hp_loss"
            if any(rid not in w.own or rid in self.jobs and not self._healthy(w.own.get(rid)) for rid in self.losses):
                return "worker_death_or_half_health"
        for robot in w.robots:
            target = robot.get("targetTeam")
            our_or_unknown = target not in ("challenger", "defender") or target == w.team_type
            if our_or_unknown and min(dist(robot, cell) for cell in w.footprint(w.station)) <= robot.get("attackRange", 3) + 2:
                return "base_robot_buffer"
        if self.jobs:
            if (not getattr(w, "rotation_ready", False) or not getattr(w, "rotation_verified", False)
                    or getattr(w, "rotation_failed", False)):
                return "rotation_unavailable"
            if not pioneer or pioneer.get("roleType") != "pioneer" or not self._healthy(pioneer):
                return "primary_unavailable"
            if primary in occupied_roles(commands):
                return "primary_action_reserved"
            risk = self._risk_cells(w)
            for rid, job in self.jobs.items():
                worker = w.own.get(rid)
                if not self._healthy(worker):
                    return "worker_half_health"
                if job["stage"] == "return":
                    continue
                if pos(worker) in risk or any(cell in risk for cell in job.get("route_cells", ())):
                    return "worker_route_risk"
                backup = self._backup(w, rid)
                home = self._home(w, worker, worker, backup)
                if backup != job["backup"] or not home.reachable or home.total_distance > 10:
                    return "return_route_unavailable"
        return ""

    def _eligible(self, w, commands):
        primary = str(getattr(w, "rotation_primary", ""))
        pilot = w.own.get(primary)
        return bool(len(w.weapons) == 3 and getattr(w, "rotation_ready", False)
                    and getattr(w, "rotation_verified", False) and not getattr(w, "rotation_failed", False)
                    and w.pioneer and primary == str(w.pioneer["id"]) and self._healthy(pilot)
                    and primary not in occupied_roles(commands) and self._healthy(w.station)
                    and (self.last_alarm_round is None or w.round - self.last_alarm_round >= 5))

    def _work_goals(self, w, worker, target, backup, excluded=()):
        """Check every interaction square; the nearest outward square can be a bad return."""
        goals = w.adjacent(target) - self._risk_cells(w) - set(excluded)
        feasible = set()
        for cell in sorted(goals):
            if w.expired():
                break
            home = self._home(w, worker, cell, backup)
            if home.reachable and home.total_distance <= 10:
                feasible.add(cell)
        return feasible

    def _trip(self, w, worker, game, deadline, claims, avoid_stand=None):
        rid, backup = str(worker["id"]), self._backup(w, str(worker["id"]))
        if backup is None or backup in self._risk_cells(w):
            return None
        vendors = [zone for zone in w.zones if zone.get("neutralType") == "vendor"]
        stock = sellable_inventory(w, worker)
        disabled = getattr(w, "disabled_actions", set())
        options = []
        stands = {cell for other, job in self.jobs.items() if other != rid
                  for cell in (job.get("mine_stand"), job.get("sale_stand")) if cell is not None}
        if "sell" in disabled or "move" in disabled:
            return None
        for vendor in vendors:
            goals = self._work_goals(w, worker, vendor, backup, stands | ({avoid_stand} if avoid_stand else set()))
            outward = self._route(w, worker, worker, goals)
            if not outward.reachable:
                continue
            home = self._home(w, worker, outward.goal, backup)
            if not home.reachable or home.total_distance > 10:
                continue
            sold = {kind: stock[kind] for kind in MINERALS if stock[kind] and w.prices.get(kind, 0) > 0}
            value = sum(stock[kind] * w.prices[kind] for kind in sold)
            turns = outward.total_distance + len(sold) + home.total_distance
            if value and w.round + turns <= deadline:
                options.append((value / float(turns + 1), value, -turns,
                                {"stage": "sell", "mine": None, "remaining": 0, "vendor": pos(vendor),
                                 "sale_stand": outward.goal, "backup": backup, "return_turns": home.total_distance,
                                 "route_cells": outward.steps + home.steps}))
        capacity = max(0, worker.get("backPackCapability", 100) - len(worker.get("backpack") or []))
        if "collect" not in disabled and capacity:
            mines = [zone for zone in w.zones if zone.get("neutralType") in MINERALS
                     and w.prices.get(zone["neutralType"], 0) > 0]
            mines.sort(key=lambda mine: (dist(worker, mine), pos(mine)))
            for mine in mines:
                if w.expired():
                    break
                key = mine_key(mine)
                if (self.bad_mines.get(key, 0) > w.round or game.economy.blocked_until.get(key, 0) > w.round
                        or game._mine_closed(key[0], w.day)):
                    continue
                available = min(capacity, max(0, game.economy.mines.get(key, 0) - claims.get(key, 0)))
                if not available:
                    continue
                goals = self._work_goals(w, worker, mine, backup, stands | ({avoid_stand} if avoid_stand else set()))
                outward = self._route(w, worker, worker, goals)
                if not outward.reachable:
                    continue
                mine_home = self._home(w, worker, outward.goal, backup)
                if not mine_home.reachable or mine_home.total_distance > 10:
                    continue
                for vendor in vendors:
                    sale_goals = self._work_goals(w, worker, vendor, backup, stands)
                    sale = self._route(w, worker, outward.goal, sale_goals)
                    if not sale.reachable:
                        continue
                    home = self._home(w, worker, sale.goal, backup)
                    if not home.reachable or home.total_distance > 10:
                        continue
                    for amount in range(1, available + 1):
                        projected = dict(worker, backpack=list(worker.get("backpack") or []) + [key[0]] * amount)
                        sellable = sellable_inventory(w, projected)
                        sold = {kind: sellable[kind] for kind in MINERALS if sellable[kind] and w.prices.get(kind, 0) > 0}
                        value = sum(count * w.prices[kind] for kind, count in sold.items())
                        turns = outward.total_distance + amount + sale.total_distance + len(sold) + home.total_distance
                        if value and w.round + turns <= deadline:
                            options.append((value / float(turns + 1), value, -turns,
                                            {"stage": "mine", "mine": key, "remaining": amount,
                                             "mine_stand": outward.goal, "vendor": pos(vendor), "sale_stand": sale.goal,
                                             "backup": backup, "return_turns": mine_home.total_distance,
                                             "route_cells": outward.steps + sale.steps + home.steps}))
        return max(options, key=lambda item: item[:3])[3] if options else None

    def _move(self, w, commands, worker, goals):
        if "move" in getattr(w, "disabled_actions", set()):
            return False
        reserved = {pos(cell) for command in commands.values() if command.get("action") in ("move", "build")
                    for cell in command.get("targetPos", ())}
        reserved |= set(getattr(w, "move_avoid", {}).get(str(worker["id"]), ()))
        job = self.jobs.get(str(worker["id"]), {})
        avoid = job.get("return_avoid") if job.get("return_avoid_until", 0) > w.round else None
        if avoid is not None:
            reserved.add(avoid)
        route = self._route(w, worker, worker, goals, reserved=reserved, dynamic=True)
        if route.steps:
            commands[str(worker["id"])] = action("move", route.steps[0])
            return True
        if not route.reachable and route.status != "budget_exhausted":
            future = self._route(w, worker, worker, goals, reserved=reserved)
            if not future.reachable and avoid is not None:
                reserved.discard(avoid)
                future = self._route(w, worker, worker, goals, reserved=reserved)
            if future.steps:
                w.blocked_routes.append((str(worker["id"]), future.steps))
                job["last_blocked_step"] = future.steps[0]
                # A distant idle actor must not make the entire free prefix idle.
                # Only this next cell is executed; no swaps or occupied-cell moves.
                if future.steps[0] not in w.occupied | reserved | self._risk_cells(w):
                    commands[str(worker["id"])] = action("move", future.steps[0])
                    return True
        return False

    def _recall(self, w, commands, rid, job):
        worker = w.own.get(rid)
        if not worker or rid in occupied_roles(commands):
            return
        backup = self._backup(w, rid) or job["backup"]
        if pos(worker) == backup:
            self.jobs.pop(rid, None)
            self.cooldown[rid] = max(self.cooldown.get(rid, 0), w.round + 1)
            self._event("returned", role_id=rid, deadline=job["deadline"], late=w.round > job["deadline"])
            return
        if self._move(w, commands, worker, {backup}):
            job["reason"] = "safe_return"
            return
        # If the safe route only has transient traffic, request yielding and hold.
        future = self._home(w, worker, worker, backup)
        if future.reachable and pos(worker) not in self._risk_cells(w):
            job["reason"] = "return_wait_traffic"
            return
        reserved = {pos(cell) for command in commands.values() if command.get("action") == "move"
                    for cell in command.get("targetPos", ())}
        choices = [cell for cell in w.neighbors(pos(worker)) if cell not in w.occupied | reserved
                   and cell not in getattr(w, "move_avoid", {}).get(rid, set())]
        connections = {cell: self._route(w, worker, cell, {backup}, safe=False) for cell in choices}
        choices = [cell for cell in choices if connections[cell].reachable]
        current_risk = exposure(w, pos(worker))
        if choices:
            safest = min(choices, key=lambda cell: (exposure(w, cell), cell in self._risk_cells(w),
                                                   connections[cell].total_distance, cell))
            if exposure(w, safest) <= current_risk and "move" not in getattr(w, "disabled_actions", set()):
                commands[rid] = action("move", safest)
                job["reason"] = "least_risk_escape"
                return
        job["reason"] = "no_safe_escape"

    def _work(self, w, commands, rid, job, game, claims):
        worker = w.own.get(rid)
        if not worker or rid in occupied_roles(commands):
            return
        if job.get("replan"):
            candidate = self._trip(w, worker, game, job["deadline"], claims, job.get("avoid_stand"))
            if candidate:
                job.update(candidate)
                job.pop("replan", None)
            else:
                self._return_one(w, rid, "replan_not_feasible")
        home = self._home(w, worker, worker, job["backup"])
        if not home.reachable or w.round + home.total_distance >= job["deadline"]:
            self._return_one(w, rid, "fixed_trip_deadline")
        if job["stage"] == "mine":
            mine = next((zone for zone in w.zones if zone.get("neutralType") in MINERALS and mine_key(zone) == job["mine"]), None)
            if (job["remaining"] <= 0 or "collect" in getattr(w, "disabled_actions", set())
                    or len(worker.get("backpack") or []) >= worker.get("backPackCapability", 100)):
                job["stage"] = "sell"
            elif mine is None or game.economy.mines.get(job["mine"], 0) <= 0:
                self._return_one(w, rid, "mine_disappeared")
            else:
                sale = self._route(w, worker, job["mine_stand"], {job["sale_stand"]})
                after_sale = self._home(w, worker, job["sale_stand"], job["backup"])
                onward = self._route(w, worker, worker, {job["mine_stand"]})
                projected = dict(worker, backpack=list(worker.get("backpack") or []) + [job["mine"][0]])
                sale_stock = sellable_inventory(w, projected)
                sale_actions = sum(bool(sale_stock[kind] and w.prices.get(kind, 0)) for kind in MINERALS)
                if (not onward.reachable or not sale.reachable or not after_sale.reachable or
                        w.round + onward.total_distance + 1 + sale.total_distance + sale_actions + after_sale.total_distance > job["deadline"]):
                    job["stage"] = "sell"
                elif pos(worker) == job["mine_stand"] and w.near(worker, mine):
                    commands[rid] = action("collect", pos(mine))
                    job["reason"] = "collect"
                    return
                else:
                    job["reason"] = "mine_travel" if self._move(w, commands, worker, {job["mine_stand"]}) else "mine_wait_traffic"
                    return
        if job["stage"] == "sell":
            vendor = next((zone for zone in w.zones if zone.get("neutralType") == "vendor" and pos(zone) == job["vendor"]), None)
            stock = sellable_inventory(w, worker)
            sold = [kind for kind in MINERALS if stock[kind] and w.prices.get(kind, 0) > 0]
            if "sell" in getattr(w, "disabled_actions", set()):
                self._return_one(w, rid, "sale_disabled")
            elif not vendor or not sold:
                self._return_one(w, rid, "trade_complete" if vendor else "vendor_disappeared")
            else:
                route = self._route(w, worker, worker, {job["sale_stand"]})
                after = self._home(w, worker, job["sale_stand"], job["backup"])
                if (not route.reachable or not after.reachable or
                        w.round + route.total_distance + len(sold) + after.total_distance > job["deadline"]):
                    self._return_one(w, rid, "sale_deadline")
                elif pos(worker) == job["sale_stand"] and w.near(worker, vendor):
                    kind = max(sold, key=lambda item: stock[item] * w.prices[item])
                    commands[rid] = action("sell", name=kind, num=stock[kind])
                    job["reason"] = "sell"
                    return
                else:
                    job["reason"] = "vendor_travel" if self._move(w, commands, worker, {job["sale_stand"]}) else "vendor_wait_traffic"
                    return
        if job["stage"] == "return":
            self._recall(w, commands, rid, job)

    def step(self, w, commands, game):
        self.prepare(w)
        if not w.night or getattr(game, "strategy", "rocket") != "rocket":
            self._publish(w)
            return
        if self.last_step == w.round:
            self._publish(w)
            return
        self.last_step = w.round
        alarm = self._alarm(w, commands)
        if self.disabled:
            alarm = "night_instruction_disabled"
        if alarm:
            self.last_alarm_round, self.quiet_rounds = w.round, 0
            self.context["alarm"] = alarm
            for rid in self.jobs:
                self._return_one(w, rid, alarm)
        else:
            self.quiet_rounds += 1
        for rid, job in list(self.jobs.items()):
            claims = Counter()
            for other, plan in self.jobs.items():
                if other != rid and plan["stage"] == "mine":
                    claims[plan["mine"]] += plan["remaining"]
            if job["stage"] == "return":
                self._recall(w, commands, rid, job)
            else:
                self._work(w, commands, rid, job, game, claims)
        if not self.jobs:
            self.first_release_round = None
        remaining = max(0, 130 - w.turn)
        release_second = self.first_release_round is None or w.round - self.first_release_round >= 3 and self.quiet_rounds >= 3
        if (not alarm and not self.disabled and remaining > 5 and self._eligible(w, commands)
                and len(self.jobs) < 2 and release_second and not w.expired()):
            claims = Counter()
            for job in self.jobs.values():
                if job["stage"] == "mine":
                    claims[job["mine"]] += job["remaining"]
            candidates = []
            for worker in w.workers:
                rid = str(worker["id"])
                if (rid in self.jobs or rid in occupied_roles(commands) or self.cooldown.get(rid, 0) > w.round
                        or not self._healthy(worker) or self._backup(w, rid) != pos(worker)):
                    continue
                deadline = w.round + min(30, remaining - 5)
                plan = self._trip(w, worker, game, deadline, claims)
                if plan:
                    candidates.append((plan["return_turns"], rid, worker, plan))
            if candidates:
                _, rid, worker, plan = min(candidates, key=lambda item: item[:2])
                plan.update(started=w.round, deadline=w.round + min(30, remaining - 5), stalled=0,
                            observed_round=w.round,
                            marker=(pos(worker), tuple(sorted(Counter(worker.get("backpack") or []).items()))))
                self.jobs[rid] = plan
                if self.first_release_round is None:
                    self.first_release_round = w.round
                self._event("worker_released", role_id=rid, deadline=plan["deadline"],
                            return_turns=plan["return_turns"], quota=plan["remaining"])
                self._work(w, commands, rid, plan, game, claims)
        self._publish(w)

    def record(self, w, commands):
        """Called with final validated actions only; never count an intent twice."""
        self.pending = {}
        if not w.night:
            return
        for rid, command in commands.items():
            rid = str(rid)
            worker = w.own.get(rid)
            if rid not in self.jobs or not worker or command.get("action") not in ("collect", "sell", "move"):
                continue
            item = dict(command, round=w.round, night=True, position=pos(worker),
                        stock=dict(Counter(worker.get("backpack") or [])))
            if command["action"] == "collect":
                zone = next((zone for zone in w.zones if pos(zone) == pos(command["targetPos"][0])), None)
                if not zone:
                    continue
                item["mineral"] = zone["neutralType"]
            elif command["action"] == "sell":
                item["sale_value"] = w.prices.get(command["name"], 0) * command["num"]
            self.pending[rid] = item

    def reject(self, w, prior, description):
        """Scope rejected night collection/trading to this experiment, not daytime."""
        prior = {str(rid): command for rid, command in (prior or {}).items()}
        suspects = {rid: sent for rid, sent in self.pending.items()
                    if sent.get("night") and sent["round"] + 1 == w.round and rid in prior and
                    sent["action"] in ("collect", "sell", "move") and prior[rid].get("action") == sent["action"]}
        if not suspects:
            return False
        description = str(description)
        named = {verb for verb in ("collect", "sell", "move", "attack", "buy", "build", "use", "submitAnswer", "acceptTask")
                 if re.search(r"(?<![A-Za-z])" + verb + r"(?![A-Za-z])", description, re.I)}
        identities = set(prior) | set(w.own) | {
            str(cmd["controllerId"]) for cmd in prior.values() if cmd.get("controllerId") is not None}
        identified = {rid for rid in identities
                      if re.search(r"(?<!\d)" + re.escape(rid) + r"(?!\d)", description)}
        if identified:
            matched = bool(identified.intersection(suspects)) and identified <= set(suspects)
            if named:
                matched = matched and named <= {suspects[rid]["action"] for rid in identified if rid in suspects}
        elif named:
            matching = {rid for rid, cmd in prior.items() if cmd.get("action") in named}
            matched = bool(matching) and named <= {"collect", "sell", "move"} and matching <= set(suspects)
        else:
            # A False action result is ordinary execution feedback, not attribution
            # of a simultaneous instruction error. Only a single final action is clear.
            matched = len(prior) == 1 and set(prior) <= set(suspects)
        if not matched:
            return False
        self.disabled, self.disabled_reason = True, str(description)[:200] or "night_instruction_error"
        for rid in self.jobs:
            self._return_one(w, rid, "night_instruction_error")
        self._publish(w)
        return True
