"""Continuous worker income with one observation ledger across day and night."""
from collections import Counter
import heapq
import itertools
import re

from .defense import exposure, number
from .economy import EconomyPlanner, MINERALS, mine_key, sellable_inventory
from .medical import occupied_roles
from .world import PathResult, action, dist, pos


class ContinuousEconomy(EconomyPlanner):
    batch_size = 6

    def __init__(self):
        super().__init__()
        self.night_disabled = False
        self.night_disabled_reason = ""
        self.final_pending = {}
        self.proposed = {}
        self.proposed_round = None
        self.active = set()

    def observe(self, w):
        if self.last_round == w.round:
            w.economy_context = self.context
            return
        before = {rid: dict(plan) for rid, plan in self.plans.items()}
        old_pending = self.pending
        # A builder collecting the same stone deposit updates its real yield,
        # but must not consume the paused economic batch's quota.
        paused = {rid: plan for rid, plan in before.items()
                  if plan.get("paused") or (rid in old_pending and not old_pending[rid].get("economic", False))}
        for rid in paused:
            self.plans.pop(rid, None)
        super().observe(w)
        for rid, plan in paused.items():
            if rid in w.own:
                self.plans[rid] = plan
        collected, sales, expected, valid_value = 0, 0, 0, 0
        feedback = w.raw.get("lastRoundRoleActionResults") or {}
        feedback = {str(k): value for k, value in feedback.items()} if isinstance(feedback, dict) else {}
        for rid, sent in old_pending.items():
            worker = w.own.get(rid)
            if not worker or sent["round"] + 1 != w.round or not sent.get("economic"):
                continue
            stock = Counter(worker.get("backpack") or [])
            if sent["action"] == "collect":
                key = sent["mine"]
                gained = max(0, stock[key[0]] - sent["stock"].get(key[0], 0))
                collected += gained
                if rid not in self.plans and gained and rid in before:
                    # The last ore can disappear together with the fulfilled batch.
                    self.plans[rid] = dict(before[rid], mode="sell", mine=None, remaining=0)
            elif sent["action"] == "sell":
                value = sent.get("sale_value", 0)
                expected += value
                decrease = sent["stock"].get(sent["name"], 0) - stock[sent["name"]]
                if decrease >= sent.get("num", 0) and feedback.get(rid) is not False:
                    sales += sent.get("num", 0)
                    valid_value += value
        for rid, plan in list(self.plans.items()):
            worker = w.own.get(rid)
            if not worker:
                self.plans.pop(rid, None)
                continue
            if plan.get("mode") == "mine" and (plan.get("remaining", 0) <= 0 or
                    plan.get("mine") not in self.mines or self.mines.get(plan.get("mine"), 0) <= 0):
                if any(sellable_inventory(w, worker).values()):
                    plan.update(mode="sell", mine=None, remaining=0)
                    plan.pop("stand", None)
                else:
                    self.plans.pop(rid, None)
        delta = self.context.get("gold_delta")
        cash_confirmed = bool(valid_value and delta is not None and delta >= valid_value)
        self.context.update(policy="continuous", night=w.night, night_disabled=self.night_disabled,
                            night_disabled_reason=self.night_disabled_reason, collected_count=collected,
                            sale_inventory_confirmed=sales, expected_sale_value=expected,
                            observed_team_gold_delta=delta, sale_batch_cash_confirmed=cash_confirmed,
                            confirmed_sale_batch_value=valid_value if cash_confirmed else 0)
        w.economy_context = self.context

    def record(self, w, commands):
        super().record(w, commands)
        for rid, sent in self.pending.items():
            command = commands.get(rid, commands.get(w.own[rid]["id"], {}))
            sent["economic"] = self.proposed_round == w.round and self.proposed.get(rid) == command
            if sent["action"] == "sell":
                sent["num"] = command.get("num", 0)
                sent["sale_value"] = w.prices.get(sent["name"], 0) * sent["num"]

    def record_final(self, w, commands):
        self.record(w, commands)
        self.final_pending = {}
        for rid, command in commands.items():
            rid = str(rid)
            if (w.night and self.proposed_round == w.round and self.proposed.get(rid) == command
                    and command.get("action") in ("move", "collect", "sell")):
                self.final_pending[rid] = dict(command, round=w.round, night=True)

    @staticmethod
    def _risk(w, cell):
        damage = exposure(w, cell)
        buffer = 0.0
        for robot in w.robots:
            if robot.get("abnormalState") == "dizzy":
                continue
            reach = number(robot.get("attackRange"), 3)
            if reach + 1 < dist(robot, cell) <= reach + 2:
                defaults = {"smallRobot": 5, "middleRobot": 10, "largeRobot": 20, "bossRobot": 40}
                buffer += number(robot.get("attackPower"), defaults.get(robot.get("roleType"), 10)) * 0.25
        return damage, buffer

    def _route(self, w, worker, start, goals, reserved=(), dynamic=False):
        start, rid = pos(start), str(worker["id"])
        goals = {pos(cell) for cell in goals if w.in_bounds(cell)}
        friendly = {pos(person) for person in w.people}
        blocked = w.static | (w.occupied if dynamic else w.occupied - friendly) | set(reserved)
        primary = w.own.get(str(getattr(w, "rotation_primary", "")))
        if primary and str(primary["id"]) != rid:
            blocked.add(pos(primary))
        blocked.discard(start)
        goals -= blocked
        if w.expired():
            return PathResult("budget_exhausted")
        if not goals or start in w.static or not w.in_bounds(start):
            return PathResult("unreachable")
        if start in goals:
            route = PathResult("arrived", [], goal=start)
            route.risk = sum(self._risk(w, start))
            return route
        if not w.robots:
            steps, complete = w._search(start, goals, blocked, ("continuous", start, frozenset(blocked)))
            if steps is None:
                return PathResult("unreachable" if complete else "budget_exhausted")
            route = PathResult("reachable", steps, goal=steps[-1])
            route.risk = 0.0
            return route
        # Lexicographic Dijkstra: expected damage (including a soft outer buffer)
        # takes precedence over distance. Only immediately lethal cells are banned.
        cache = getattr(w, "_continuous_routes", None)
        if cache is None:
            cache = w._continuous_routes = {}
        hp = number(worker.get("health"), 1)
        key = (start, frozenset(blocked), hp)
        if key not in cache:
            costs, parents, queue, complete = {start: (0.0, 0)}, {start: None}, [(0.0, 0, start)], True
            visits = 0
            risks = getattr(w, "_continuous_risks", None)
            if risks is None:
                risks = w._continuous_risks = {}
            while queue:
                risk, distance, cell = heapq.heappop(queue)
                if costs.get(cell) != (risk, distance):
                    continue
                visits += 1
                if visits % 32 == 0 and w.expired():
                    complete = False
                    break
                for nxt in w.neighbors(cell):
                    if nxt in blocked:
                        continue
                    if nxt not in risks:
                        risks[nxt] = self._risk(w, nxt)
                    damage, buffer = risks[nxt]
                    if damage >= hp:
                        continue
                    new = (risk + damage + buffer, distance + 1)
                    if nxt not in costs or new < costs[nxt]:
                        costs[nxt], parents[nxt] = new, cell
                        heapq.heappush(queue, (new[0], new[1], nxt))
            cache[key] = costs, parents, complete
        costs, parents, complete = cache[key]
        reachable = goals.intersection(costs)
        if not reachable:
            return PathResult("unreachable" if complete else "budget_exhausted")
        goal = min(reachable, key=lambda cell: (costs[cell], cell))
        steps, cell = [], goal
        while cell != start:
            steps.append(cell)
            cell = parents[cell]
        route = PathResult("reachable", list(reversed(steps)), goal=goal)
        route.risk = costs[goal][0]
        return route

    def route(self, w, worker, start, goals, reserved=(), dynamic=False):
        """Shared risk-aware routing for temporary yielding, never a return-to-base policy."""
        return self._route(w, worker, start, goals, reserved, dynamic)

    @staticmethod
    def allowed_next(w, worker, cell, reserved=()):
        cell = pos(cell)
        return bool(w.in_bounds(cell) and dist(worker, cell) == 1 and cell not in w.occupied | set(reserved)
                    and cell not in getattr(w, "move_avoid", {}).get(str(worker["id"]), set())
                    and exposure(w, cell) < worker.get("health", 1))

    def _outward(self, w, worker, target, mode):
        rid = str(worker["id"])
        goals = w.adjacent(target)
        avoided = self.avoid_stands.get(rid)
        if avoided and avoided[1] > w.round:
            goals.discard(avoided[0])
        if pos(worker) in goals and exposure(w, pos(worker)) < worker.get("health", 1):
            return self._route(w, worker, worker, {pos(worker)})
        plan = self.plans.get(rid, {})
        matches = plan.get("mode") == mode and (plan.get("mine") == mine_key(target) if mode == "mine"
                                               else plan.get("vendor") == pos(target))
        if matches and plan.get("stand") in goals:
            retained = self._route(w, worker, worker, {plan["stand"]})
            if retained.reachable and getattr(retained, "risk", 0) == 0:
                return retained
        return self._route(w, worker, worker, goals)

    def _choices(self, w, worker, closed, liquidate):
        rid, stock = str(worker["id"]), sellable_inventory(w, worker)
        disabled = getattr(w, "disabled_actions", set())
        plan = self.plans.get(rid, {})
        capacity = max(0, worker.get("backPackCapability", 100) - len(worker.get("backpack") or []))
        sold = {kind: stock[kind] for kind in MINERALS if stock[kind] and w.prices.get(kind, 0) > 0}
        income = sum(count * w.prices[kind] for kind, count in sold.items())
        wait = {"mode": "wait", "mine_key": None, "harvest": 0, "income": 0, "score": 0,
                "stand": None, "risk": 0, "travel": 0, "reason": "no_feasible_economic_route"}
        choices, failures = [wait], Counter()
        if w.expired():
            wait["reason"] = "budget_exhausted"
            return choices
        vendors = sorted((zone for zone in w.zones if zone.get("neutralType") == "vendor"),
                         key=lambda zone: (dist(worker, zone), pos(zone)))[:2]
        if not vendors:
            wait["reason"] = "no_vendor"
        force_sell = bool(income and (liquidate or capacity == 0 or sum(stock.values()) >= self.batch_size or plan.get("mode") == "sell"
                                     or not plan or plan.get("remaining", 0) <= 0))
        if income and "sell" not in disabled:
            for vendor in vendors:
                outward = self._outward(w, worker, vendor, "sell")
                if not outward.reachable:
                    failures["vendor:" + outward.status] += 1
                    continue
                turns = outward.distance + len(sold)
                choices.append(dict(mode="sell", mine_key=None, harvest=0, income=income,
                                    vendor=vendor, stand=outward.goal, risk=getattr(outward, "risk", 0),
                                    travel=outward.distance, score=income / float(turns + 1),
                                    reason="upgrade_funding_sale" if liquidate else "cash_in_inventory"))
        if force_sell and len(choices) > 1:
            return choices
        if "collect" in disabled or not capacity:
            wait["reason"] = "collect_disabled" if "collect" in disabled else "backpack_full"
            return choices
        stable = plan.get("mine") if plan.get("mode") == "mine" and plan.get("remaining", 0) else None
        mines = [zone for zone in w.zones if zone.get("neutralType") in MINERALS
                 and self.available_yield(w, mine_key(zone)) > 0
                 and self.blocked_until.get(mine_key(zone), 0) <= w.round
                 and not closed(zone["neutralType"], w.day) and w.prices.get(zone["neutralType"], 0) > 0]
        mines.sort(key=lambda zone: (mine_key(zone) != stable, not w.near(worker, zone), dist(worker, zone), pos(zone)))
        if not mines:
            wait["reason"] = "no_priced_collectible_mine"
        stable_choices = []
        for mine in mines[:4]:
            if w.expired():
                break
            key = mine_key(mine)
            outward = self._outward(w, worker, mine, "mine")
            if not outward.reachable:
                failures["mine:" + outward.status] += 1
                continue
            maximum = min(max(0, self.batch_size - sum(stock.values())), capacity, self.available_yield(w, key))
            if key == stable:
                maximum = min(maximum, plan["remaining"])
            for vendor in vendors:
                sale = self._route(w, worker, outward.goal, w.adjacent(vendor))
                if not sale.reachable:
                    failures["sale:" + sale.status] += 1
                    continue
                if "sell" in disabled:
                    continue
                for amount in range(1, maximum + 1):
                    projected = dict(worker, backpack=list(worker.get("backpack") or []) + [key[0]] * amount)
                    after = sellable_inventory(w, projected)
                    value = sum(after[kind] * w.prices.get(kind, 0) for kind in MINERALS)
                    incremental = value - income
                    if incremental <= 0:
                        continue
                    turns = outward.distance + amount + sale.distance + sum(bool(after[k] and w.prices.get(k, 0)) for k in MINERALS)
                    choice = dict(mode="mine", mine_key=key, harvest=amount, income=value,
                                  mine=mine, vendor=vendor, stand=outward.goal,
                                  risk=getattr(outward, "risk", 0) + getattr(sale, "risk", 0),
                                  travel=outward.distance + sale.distance,
                                  score=value / float(turns + 1), reason="continuous_batch")
                    choices.append(choice)
                    if key == stable:
                        stable_choices.append(choice)
        if stable_choices and not liquidate:
            choices = [wait] + stable_choices
        wait["route_failures"] = dict(failures)
        if w.expired():
            wait["reason"] = "budget_exhausted"
        return choices

    def _alternatives(self, w, worker, choices, contested):
        """A shared nearest interaction square must not idle an otherwise useful worker."""
        alternatives, cached = [], {}
        for choice in choices:
            if choice["stand"] not in contested or choice["stand"] == pos(worker) or w.expired():
                continue
            target = choice.get("mine") if choice["mode"] == "mine" else choice.get("vendor")
            if not target:
                continue
            key = (choice["mode"], pos(target), pos(choice["vendor"]))
            if key not in cached:
                goals = w.adjacent(target) - {choice["stand"]}
                avoided = self.avoid_stands.get(str(worker["id"]))
                if avoided and avoided[1] > w.round:
                    goals.discard(avoided[0])
                outward = self._route(w, worker, worker, goals)
                sale = (self._route(w, worker, outward.goal, w.adjacent(choice["vendor"]))
                        if outward.reachable and choice["mode"] == "mine" else None)
                cached[key] = outward, sale
            outward, sale = cached[key]
            if not outward.reachable or sale is not None and not sale.reachable:
                continue
            travel = outward.distance + (sale.distance if sale else 0)
            projected = list(worker.get("backpack") or []) + ([choice["mine_key"][0]] * choice["harvest"] if choice["mine_key"] else [])
            stock = sellable_inventory(w, dict(worker, backpack=projected))
            sales = sum(bool(stock[k] and w.prices.get(k, 0)) for k in MINERALS)
            alternatives.append(dict(choice, stand=outward.goal, travel=travel,
                                     risk=getattr(outward, "risk", 0) + (getattr(sale, "risk", 0) if sale else 0),
                                     score=choice["income"] / float(travel + choice["harvest"] + sales + 1)))
        return choices + alternatives

    def _move(self, w, commands, worker, goals):
        if "move" in getattr(w, "disabled_actions", set()):
            return False
        rid = str(worker["id"])
        reserved = {pos(cell) for command in commands.values() if command.get("action") in ("move", "build")
                    for cell in command.get("targetPos", ())}
        reserved |= set(getattr(w, "move_avoid", {}).get(rid, ()))
        route = self._route(w, worker, worker, goals, reserved, dynamic=True)
        if not route.steps and route.status != "budget_exhausted":
            route = self._route(w, worker, worker, goals, reserved)
            if route.steps:
                w.blocked_routes.append((rid, route.steps))
        if route.steps and route.steps[0] not in w.occupied | reserved:
            if exposure(w, route.steps[0]) < worker.get("health", 1):
                commands[rid] = action("move", route.steps[0])
                return True
        return False

    def _escape(self, w, commands, worker):
        """Immediate survival only affects this worker; no base or pilot alarm."""
        rid, hp = str(worker["id"]), worker.get("health", 1)
        if exposure(w, pos(worker)) < hp:
            return False
        reserved = {pos(cell) for command in commands.values() if command.get("action") in ("move", "build")
                    for cell in command.get("targetPos", ())}
        cells = [cell for cell in w.neighbors(pos(worker)) if cell not in w.occupied | reserved
                 and exposure(w, cell) < hp and cell not in getattr(w, "move_avoid", {}).get(rid, set())]
        if cells and "move" not in getattr(w, "disabled_actions", set()):
            best = min(cells, key=lambda cell: (self._risk(w, cell), cell))
            commands[rid] = action("move", best)
            self.note(rid, "evade", "immediate_lethal_risk", expected_damage=exposure(w, pos(worker)))
        else:
            self.note(rid, "wait", "no_nonlethal_escape", expected_damage=exposure(w, pos(worker)))
        return True

    def step(self, w, commands, workers, budget, goal, closed, move=None, defend=None):
        self.observe(w)
        self.refresh_inventory(w)
        self.proposed_round, self.proposed = w.round, {}
        used = occupied_roles(commands)
        workers = sorted((worker for worker in workers if str(worker["id"]) not in used), key=lambda worker: str(worker["id"]))[:2]
        self.active = {str(worker["id"]) for worker in workers}
        for rid, plan in self.plans.items():
            plan["paused"] = rid not in self.active
        for worker in w.workers:
            rid = str(worker["id"])
            if rid not in self.active:
                row = self.context.get("workers", {}).get(rid, {})
                if row.get("mode") in (None, "unassigned", "mine", "sell", "wait"):
                    self.note(rid, "paused", "assigned_other_work")
        available = []
        for worker in workers:
            rid = str(worker["id"])
            if self._escape(w, commands, worker):
                if rid in commands:
                    self.proposed[rid] = dict(commands[rid])
                continue
            if w.night and self.night_disabled:
                self.note(rid, "wait", "night_instruction_disabled")
                continue
            available.append(worker)
        gap = max(0, goal["price"] + goal.get("reserve", 0) - budget) if goal else 0
        liquid = sum(sum(sellable_inventory(w, worker)[k] * w.prices.get(k, 0) for k in MINERALS)
                     for worker in available)
        self.context["upgrade"].update(cash_gap=gap, joint_inventory_value=liquid,
                                       reason="joint_inventory_liquidation" if gap and liquid >= gap else "continuous_income")
        options = [self._choices(w, worker, closed, bool(gap and liquid >= gap)) for worker in available]
        if len(options) == 2:
            contested = ({choice["stand"] for choice in options[0]} & {choice["stand"] for choice in options[1]}) - {None}
            if contested:
                options = [self._alternatives(w, worker, choices, contested) for worker, choices in zip(available, options)]
        best, best_rank = None, None
        for choices in itertools.product(*options):
            if w.expired():
                break
            claims = Counter()
            stands = []
            for choice in choices:
                if choice["mine_key"]:
                    claims[choice["mine_key"]] += choice["harvest"]
                if choice["stand"] is not None:
                    stands.append(choice["stand"])
            if len(stands) != len(set(stands)) or any(count > self.available_yield(w, key) for key, count in claims.items()):
                continue
            rank = (sum(choice["mode"] != "wait" for choice in choices),
                    -sum(choice["risk"] for choice in choices), sum(choice["score"] for choice in choices),
                    sum(choice["income"] for choice in choices), -sum(choice["travel"] for choice in choices))
            if best_rank is None or rank > best_rank:
                best, best_rank = choices, rank
        if best is None:
            for worker in available:
                self.note(worker["id"], "wait", "budget_exhausted" if w.expired() else "no_joint_assignment")
        else:
            for worker, choice, offered in zip(available, best, options):
                rid, mode = str(worker["id"]), choice["mode"]
                if mode == "wait":
                    reason = "shared_resource_or_stand_reserved" if len(offered) > 1 else choice["reason"]
                    self.note(rid, mode, reason, route_failures=choice.get("route_failures", {}))
                    continue
                self.plans[rid] = dict(mode=mode, mine=choice["mine_key"], remaining=choice["harvest"],
                                       stand=choice["stand"], vendor=pos(choice["vendor"]), paused=False)
                self.note(rid, mode, choice["reason"], stand=list(choice["stand"]),
                          collect_turns=choice["harvest"], expected_income=choice["income"],
                          travel_turns=choice["travel"], expected_route_damage=choice["risk"])
                target = choice["mine"] if mode == "mine" else choice["vendor"]
                if w.near(worker, target):
                    if mode == "mine":
                        commands[rid] = action("collect", pos(target))
                    else:
                        stock = sellable_inventory(w, worker)
                        kind = max((k for k in MINERALS if stock[k] and w.prices.get(k, 0) > 0),
                                   key=lambda k: stock[k] * w.prices[k])
                        commands[rid] = action("sell", name=kind, num=stock[kind])
                elif not self._move(w, commands, worker, {choice["stand"]}):
                    self.note(rid, mode, "budget_exhausted" if w.expired() else mode + "_path_blocked")
                if rid in commands:
                    self.proposed[rid] = dict(commands[rid])
        w.economy_context = self.context

    def reject(self, w, prior, description):
        prior = {str(rid): command for rid, command in (prior or {}).items()}
        suspects = {rid: sent for rid, sent in self.final_pending.items() if sent["round"] + 1 == w.round
                    and rid in prior and prior[rid].get("action") == sent["action"]}
        if not suspects:
            return False
        text = str(description)
        verbs = ("collect", "sell", "move", "attack", "buy", "build", "use", "submitAnswer", "acceptTask")
        named = {verb for verb in verbs if re.search(r"(?<![A-Za-z])" + verb + r"(?![A-Za-z])", text, re.I)}
        identities = set(prior) | set(w.own) | {str(cmd["controllerId"]) for cmd in prior.values() if cmd.get("controllerId") is not None}
        identified = {rid for rid in identities if re.search(r"(?<!\d)" + re.escape(rid) + r"(?!\d)", text)}
        if identified:
            matched = bool(identified.intersection(suspects)) and identified <= set(suspects)
            if named:
                matched = matched and named <= {suspects[rid]["action"] for rid in identified if rid in suspects}
        elif named:
            matching = {rid for rid, cmd in prior.items() if cmd.get("action") in named}
            matched = bool(matching) and named <= {"collect", "sell", "move"} and matching <= set(suspects)
        else:
            matched = len(prior) == 1 and set(prior) <= set(suspects)
        if not matched:
            return False
        self.night_disabled, self.night_disabled_reason = True, text[:200] or "night_instruction_error"
        self.context.update(night_disabled=True, night_disabled_reason=self.night_disabled_reason)
        return True
