"""One operator rotates three rockets; sent and confirmed attacks stay separate."""
import itertools

from .world import dist, pos


def _used(commands):
    return {str(key) for key in commands} | {
        str(command["controllerId"]) for command in commands.values()
        if command.get("controllerId") is not None
    }


class RocketRotation:
    def __init__(self):
        self.primary = None
        self.last_shot = {}
        self.pending = {}
        self.verified = {}
        self.failures = set()
        self.observed_round = None
        self.day = None
        self.alive = set()
        self.events = []
        self.context = {}
        self.backup_assignments = {}

    @staticmethod
    def _result(w, identifier):
        values = w.raw.get("lastRoundRoleActionResults")
        if not isinstance(values, dict):
            return None
        if identifier in values:
            return values[identifier]
        try:
            return values.get(int(identifier))
        except (TypeError, ValueError):
            return None

    def _observe(self, w):
        if self.observed_round == w.round:
            return
        if self.observed_round is not None and w.round < self.observed_round:
            return
        self.observed_round = w.round
        self.events = []
        alive = {str(person["id"]) for person in w.people}
        for controller in self.alive - alive:
            self.verified.pop(controller, None)
        self.alive = alive
        for gid, pending in list(self.pending.items()):
            if pending["round"] >= w.round:
                continue
            del self.pending[gid]
            result = self._result(w, gid) if pending["round"] + 1 == w.round else None
            if result is True:
                if pending["controller"] in alive and pending["day"] == w.day and w.night:
                    self.verified.setdefault(pending["controller"], set()).add(gid)
                self.failures.discard(gid)
                event = "attack_confirmed"
            else:
                self.failures.add(gid)
                self.verified.get(pending["controller"], set()).discard(gid)
                event = "attack_rejected" if result is False else "attack_unconfirmed"
                if result is False and self.last_shot.get(gid) == pending["round"]:
                    previous = pending["previous"]
                    if previous is None:
                        self.last_shot.pop(gid, None)
                    else:
                        self.last_shot[gid] = previous
            self.events.append({"event": event, "weapon": gid,
                                "controller": pending["controller"], "sent_round": pending["round"]})
        if self.day != w.day or not w.night:
            self.verified.clear()
            self.failures.clear()
        self.day = w.day

    @staticmethod
    def _layout(w):
        if not getattr(w, "rocket_layout_ready", False):
            return None, []
        try:
            anchor = pos(w.rocket_anchor)
            sites = [pos(site) for site in w.rocket_sites]
        except (AttributeError, TypeError, ValueError, KeyError, IndexError):
            return None, []
        if (len(set(sites)) != 3 or not w.in_bounds(anchor) or anchor in w.static
                or any(dist(anchor, site) != 1 for site in sites)):
            return None, []
        by_site = {pos(gun): gun for gun in w.weapons if gun.get("roleType") == "rocket"}
        return anchor, [by_site[site] for site in sites if site in by_site]

    def _choose_primary(self, w, anchor, excluded=()):
        if anchor is None:
            return None
        excluded = {str(identifier) for identifier in excluded}
        people = [person for person in w.people if str(person["id"]) not in excluded]
        candidates = []
        for person in people:
            route = w.plan_route(person, pos(person), {anchor})
            if route.total_distance is not None:
                candidates.append((person.get("roleType") != "pioneer", route.total_distance,
                                   str(person["id"])))
        return min(candidates)[2] if candidates else None

    @staticmethod
    def _evading(w, primary):
        person = w.own.get(primary)
        risk = getattr(w, "defense_risk", {}).get(primary, {})
        if not w.night or person is None or risk.get("estimated_damage", 0) < person.get("health", 1):
            return False
        assignment = w.defense_assignments.get(primary)
        target = w.defense_refuges.get(primary)
        if target is None and assignment:
            target = assignment["pos"]
        if target is None or tuple(target) == pos(person):
            return False
        route = w.route(person, {tuple(target)})
        return bool(route.reachable and route.steps)

    def _bind_planned(self, w, primary, anchor, guns):
        """Use the layout's entire gun/stand matching, not isolated free cells.

        One gun can have the shared anchor as its only interior operator square.
        Giving that gun to a backup would force the backup onto a future wall.
        """
        try:
            sites = tuple(pos(cell) for cell in w.rocket_sites)
            slots = tuple(pos(cell) for cell in w.rocket_backup_slots)
        except (AttributeError, TypeError, KeyError, IndexError, ValueError):
            return False
        if (len(sites) != 3 or len(slots) != 3 or len(set(slots)) != 3 or slots.count(anchor) != 1
                or any(dist(site, slot) != 1 or slot in w.static for site, slot in zip(sites, slots))):
            return False
        by_site = {pos(gun): gun for gun in guns}
        main_site = sites[slots.index(anchor)]
        main_gun = by_site.get(main_site)
        if main_gun is not None:
            w.defense_assignments[primary] = {"weapon_id": str(main_gun["id"]), "pos": anchor}
            w.defense_refuges.pop(primary, None)
        else:
            # Return planning uses the common square before its matching gun
            # has been constructed. Do not take another backup's matched gun.
            w.defense_assignments.pop(primary, None)
            w.defense_refuges[primary] = anchor
        available = [(str(by_site[site]["id"]), slot) for site, slot in zip(sites, slots)
                     if slot != anchor and site in by_site]
        people = sorted((person for person in w.people if str(person["id"]) != primary),
                        key=lambda person: str(person["id"]))
        count = min(len(available), len(people))
        route_cost = {}
        for person in people:
            rid = str(person["id"])
            for gid, slot in available:
                route = w.plan_route(person, pos(person), {slot})
                route_cost[rid, gid] = route.total_distance
        best = None
        for selected in itertools.combinations(people, count):
            for pairs in itertools.permutations(available, count):
                rows, inaccessible, changes, distance = [], 0, 0, 0
                for person, (gid, slot) in zip(selected, pairs):
                    rid = str(person["id"])
                    cost = route_cost[rid, gid]
                    old = self.backup_assignments.get(rid, w.defense_assignments.get(rid))
                    same = bool(old and old.get("weapon_id") == gid and tuple(old.get("pos", ())) == slot)
                    inaccessible += cost is None
                    changes += not same
                    distance += cost if cost is not None else 10000
                    rows.append((rid, gid, slot))
                score = (inaccessible, changes, distance, tuple(rows))
                if best is None or score < best[0]:
                    best = score, rows
        chosen = {rid: {"weapon_id": gid, "pos": slot} for rid, gid, slot in best[1]} if best else {}
        for person in people:
            rid = str(person["id"])
            w.defense_assignments.pop(rid, None)
            if rid in chosen:
                w.defense_assignments[rid] = chosen[rid]
                w.defense_refuges.pop(rid, None)
            elif w.defense_refuges.get(rid) == anchor:
                w.defense_refuges.pop(rid, None)
        self.backup_assignments = {rid: dict(value) for rid, value in chosen.items()}
        return True

    def _bind(self, w, primary, anchor, guns):
        if primary is None:
            return
        if self._bind_planned(w, primary, anchor, guns):
            return
        assignment = w.defense_assignments.get(primary)
        gun_ids = {str(gun["id"]) for gun in guns}
        if guns:
            prior_gun = assignment.get("weapon_id") if assignment else None
            chosen = prior_gun if prior_gun in gun_ids else str(guns[0]["id"])
            w.defense_assignments[primary] = {"weapon_id": chosen, "pos": anchor}
            w.defense_refuges.pop(primary, None)
        else:
            w.defense_assignments.pop(primary, None)
            w.defense_refuges[primary] = anchor
        # Daytime return, tasks and standby workers must not compete for the
        # common square. Keep backup operators on their own nearby gun squares.
        occupied_stands = {anchor}
        for rid, backup in sorted(w.defense_assignments.items()):
            if rid == primary:
                continue
            cell = tuple(backup["pos"])
            if cell not in occupied_stands:
                occupied_stands.add(cell)
                continue
            gun = w.own.get(backup["weapon_id"])
            person = w.own.get(rid)
            if gun is None or person is None:
                continue
            candidates = w.adjacent(gun) - occupied_stands - set(getattr(w, "wall_planned", ()))
            feasible = []
            for candidate in candidates:
                path = w.plan_route(person, pos(person), {candidate})
                if path.total_distance is not None:
                    feasible.append((path.total_distance, candidate))
            if feasible:
                backup["pos"] = min(feasible)[1]
                occupied_stands.add(backup["pos"])
            else:
                # An unavailable backup square must not silently reserve the
                # main operator's anchor. Root's ordinary defence may replan.
                w.defense_assignments.pop(rid, None)
                w.defense_refuges.pop(rid, None)

    def _publish(self, w, anchor, guns, state=None):
        identifiers = {str(gun["id"]) for gun in guns}
        person = w.own.get(self.primary)
        evading = self._evading(w, self.primary)
        ready = bool(anchor is not None and len(guns) == 3 and person and pos(person) == anchor and not evading)
        verified = self.verified.get(self.primary, set()) & identifiers
        self.context = {"primary": self.primary, "anchor": anchor,
                        "weapons": [str(gun["id"]) for gun in guns],
                        "ready": ready, "verified_guns": sorted(verified),
                        "verified": bool(w.night and ready and len(verified) == 3),
                        "failed": bool(self.failures & identifiers),
                        "pending": sorted(self.pending), "events": list(self.events),
                        "state": state or ("ready" if ready else "assemble" if anchor is not None else "fallback")}
        w.rotation_primary = self.primary
        w.rotation_ready = ready
        w.rotation_verified = self.context["verified"]
        w.rotation_failed = self.context["failed"]
        w.rotation_protected_roles = {self.primary} if self.primary is not None and not evading else set()
        w.rotation_context = self.context

    def prepare(self, w):
        self._observe(w)
        anchor, guns = self._layout(w)
        self.primary = self._choose_primary(w, anchor)
        evading = self._evading(w, self.primary)
        if not evading:
            self._bind(w, self.primary, anchor, guns)
        self._publish(w, anchor, guns, "operator_evading" if evading else None)

    @staticmethod
    def _value(w, damage, health):
        total = 0.0
        for robot in w.robots:
            rid = str(robot["id"])
            amount, remaining = damage.get(rid, 0), health.get(rid, 0)
            if amount <= 0 or remaining <= 0:
                continue
            base_distance = min((dist(robot, cell) for cell in w.footprint(w.station)), default=20) if w.station else 20
            near_person = min((dist(robot, person) for person in w.people), default=20)
            weight = 1 + 8.0 / (base_distance + 1) + 2.0 / (near_person + 1)
            if robot.get("targetTeam") and robot["targetTeam"] != w.team_type:
                weight *= 0.25
            if robot.get("abnormalState") == "dizzy":
                weight *= 0.8
            total += min(remaining, amount) * weight
            if amount >= remaining:
                total += 10 * weight
        return total

    def step(self, w, commands, game, excluded=()):
        """True means normal rotation handled defence, including a quiet turn.

        False allows the caller's multi-operator defence fallback. Existing
        emergency actions and excluded economic workers are never commandeered.
        """
        if not w.night:
            return False
        anchor, guns = self._layout(w)
        if anchor is None or len(guns) != 3:
            self._publish(w, anchor, guns, "fallback")
            w.rotation_protected_roles = set()
            return False
        used = _used(commands) | {str(identifier) for identifier in excluded}
        self.primary = self._choose_primary(w, anchor, used)
        if self._evading(w, self.primary):
            self._publish(w, anchor, guns, "operator_evading")
            return False
        if any(str(person["id"]) in used and pos(person) == anchor for person in w.people):
            # Medicine/upgrade consumes the pioneer action but does not free
            # its square. Keep both backups' existing gun matches so each can
            # still fire nearby, instead of assigning one the occupied-only
            # anchor gun and silently losing that backup's shot as well.
            self._publish(w, anchor, guns, "operator_anchor_busy")
            w.rotation_protected_roles = set()
            return False
        self._bind(w, self.primary, anchor, guns)
        self._publish(w, anchor, guns)
        person = w.own.get(self.primary)
        if person is None:
            self.context["state"] = "operator_unavailable"
            return False
        if pos(person) != anchor:
            moved = game._put_move(w, commands, person, {anchor})
            self.context["state"] = "operator_return" if moved else "operator_return_blocked"
            if not moved:
                w.rotation_protected_roles = set()
            return False
        if "attack" in getattr(w, "disabled_actions", set()):
            self.context["state"] = "attack_disabled"
            return True
        health = {str(robot["id"]): max(0, robot.get("health", 1)) for robot in w.robots}
        candidates, statuses = [], {}
        for gun in guns:
            gid = str(gun["id"])
            if gid in commands:
                statuses[gid] = "already_used"
                continue
            # Explicit platform cooldown, including zero, overrides inferred
            # timing. Inference starts only after a final returned attack.
            cooldown = gun.get("cooldown")
            if cooldown is None:
                cooldown = max(0, 4 - (w.round - self.last_shot.get(gid, -100)))
            if cooldown > 0:
                statuses[gid] = "cooldown"
                continue
            aimed_gun = dict(gun, cooldown=0)
            targets, damage = game._aim(w, aimed_gun, health)
            if not targets:
                statuses[gid] = "no_effective_target"
                continue
            score = self._value(w, damage, health)
            if score <= 0:
                statuses[gid] = "no_effective_target"
                continue
            candidates.append((-score, self.last_shot.get(gid, -100), gid, targets))
            statuses[gid] = "ready"
        self.context["weapons_status"] = statuses
        if not candidates:
            self.context["state"] = "cooldown_or_no_target"
            return True
        _, _, gid, targets = min(candidates)
        commands[gid] = {"action": "attack", "controllerId": self.primary,
                         "targetPos": [{"x": cell[0], "y": cell[1]} for cell in targets]}
        self.context["state"] = "attack_proposed"
        self.context["selected_weapon"] = gid
        if not hasattr(w, "defense_status"):
            w.defense_status = {}
        w.defense_status.update(statuses)
        w.defense_status[gid] = "attack_proposed"
        return True

    def record(self, w, final_commands):
        """Commit final attacks once; never reserve cooldown during selection."""
        for gid, command in final_commands.items():
            gid = str(gid)
            gun = w.own.get(gid)
            if not gun or gun.get("roleType") != "rocket" or command.get("action") != "attack":
                continue
            if self.pending.get(gid, {}).get("round") == w.round:
                continue
            self.pending[gid] = {"round": w.round, "day": w.day,
                                 "controller": str(command.get("controllerId")),
                                 "previous": self.last_shot.get(gid)}
            self.last_shot[gid] = w.round
        if hasattr(w, "rotation_context"):
            w.rotation_context["sent_attacks"] = [
                {"weapon": str(gid), "controller": str(command.get("controllerId"))}
                for gid, command in final_commands.items()
                if command.get("action") == "attack" and w.own.get(str(gid), {}).get("roleType") == "rocket"
            ]
