"""Joint first-ring rocket sites, common controller and connected wall opening.

Candidate generation is exhaustive: on a complete 2x2 footprint the twelve
first-ring cells admit exactly eight (anchor, three neighbouring sites) pairs.
Small local floods reject disconnected openings before full-map path checks.
"""
from itertools import combinations

from .layout import FortLayout
from .world import dist, pos


class RocketLayout(FortLayout):
    def __init__(self):
        super().__init__()
        self.sites = ()
        self.anchor = None
        self.backup_slots = ()
        self.rocket_ready = False
        self.failed_sites = set()
        self.locked_gate = None
        self._plan_signature = None
        self._fallback = FortLayout()

    @staticmethod
    def candidates(w):
        ring = FortLayout.ring(w, 1)
        return tuple((anchor, sites) for anchor in ring
                     for sites in combinations(tuple(p for p in ring
                                                      if p != anchor and dist(p, anchor) <= 1), 3))

    @staticmethod
    def _local_connected(w, anchor, inner, gate):
        allowed = inner | {gate}
        seen, queue = {anchor}, [anchor]
        for current in queue:
            for nxt in w.neighbors(current):
                if nxt in allowed and nxt not in seen:
                    seen.add(nxt)
                    queue.append(nxt)
        return allowed.issubset(seen)

    @staticmethod
    def _slots(w, sites, anchor, inner, gate):
        controls = inner | {gate}
        choices = [sorted((p for p in controls if dist(p, site) == 1),
                          key=lambda p: (p != anchor, p == gate, p)) for site in sites]

        def assign(index, used, result):
            if index == len(choices):
                return tuple(result)
            for cell in choices[index]:
                if cell not in used:
                    found = assign(index + 1, used | {cell}, result + [cell])
                    if found:
                        return found
            return ()

        return assign(0, set(), [])

    def _evaluate(self, w, anchor, sites, gate, order):
        if w.expired():
            return None
        proposed = set(sites)
        static = w.static | proposed
        inner = set(self.ring(w, 1)) - static
        if anchor not in inner or gate in static:
            return None
        if not self._local_connected(w, anchor, inner, gate):
            return None
        slots = self._slots(w, sites, anchor, inner, gate)
        if len(slots) != 3:
            return None
        targets = tuple(p for p in order if p != gate)
        before, _, complete = self._tree(w, anchor, w.static)
        if not complete:
            return None
        after, depths, complete = self._tree(w, anchor, static | set(targets))
        if (not complete or gate not in after or not inner.issubset(after)
                or not set(self.ring(w, 3)).intersection(after)):
            return None
        if any(goals.intersection(before) and not goals.intersection(after)
               for goals in self._destinations(w)):
            return None
        vendors = [w.adjacent(z).intersection(after) for z in w.zones
                   if z.get("neutralType") == "vendor"]
        vendor_cost = min((2 * depths[p] for goals in vendors for p in goals), default=10 ** 6)
        # A static route models construction travel without temporary people.
        # A worker initially on a future site may first step away from it.
        worker_depths = []
        for worker in w.workers:
            _, distances, complete = self._tree(w, pos(worker), static - {pos(worker)})
            if not complete:
                return None
            worker_depths.append(distances)
        construction = 0
        for site in sites:
            if site in w.static:
                continue
            stands = set(w.neighbors(site)) - static
            distance = min((tree[p] for tree in worker_depths for p in stands if p in tree),
                           default=10 ** 6)
            if distance == 10 ** 6 and w.workers:
                return None
            construction += distance
        score = (vendor_cost, construction, sites, anchor, gate)
        return score, targets, inner, slots

    def _fallback_prepare(self, w, order):
        self.rocket_ready, self.sites, self.anchor, self.backup_slots = False, (), None, ()
        if self.locked_gate is not None:
            self.gate = self.locked_gate
            self.targets = tuple(p for p in order if p != self.gate)
            self.inner = set(self.ring(w, 1)) - w.static
            self.ready = (self.gate not in w.static
                          and self._complete_layout_safe(w, self.targets, self.gate))
            self.reason = "rocket_fallback_locked" if self.ready else "rocket_locked_gate_unsafe"
        else:
            self._fallback.prepare(w)
            self.targets, self.gate = self._fallback.targets, self._fallback.gate
            self.inner, self.ready = set(self._fallback.inner), self._fallback.ready
            self.reason = "rocket_fallback_" + self._fallback.reason

    def prepare(self, w):
        self._sync(w)
        base = tuple(sorted(w.footprint(w.station))) if w.station else None
        if base != self._base:
            self._base, self._plan_signature = base, None
            self.locked_gate, self.gate, self.sites, self.anchor = None, None, (), None
            self._fallback = FortLayout()
        present_walls = {pos(r) for r in w.own.values() if r.get("roleType") == "wall"}
        if present_walls and self.gate is not None:
            self.locked_gate = self.gate
        fixed = w.static - present_walls
        order = tuple(p for p in self.wall_order(w) if p not in fixed)
        # Ordinary construction/destruction of an expected wall does not alter
        # the complete hypothetical graph, so it need not repeat the search.
        signature = (base, frozenset(fixed), frozenset(present_walls - set(self.targets)),
                     tuple(sorted((r.get("roleType"), pos(r)) for r in w.weapons)),
                     frozenset(self.failed_sites), self.locked_gate)
        if signature != self._plan_signature:
            current = None
            weapons = {pos(g) for g in w.weapons}
            eligible = (base and len(w.weapons) <= 3
                        and all(g.get("roleType") == "rocket" for g in w.weapons))
            if eligible:
                candidates = self.candidates(w)
                # Once selected, valid geometry remains stable across workers'
                # daily movement, partial builds and stone respawns.
                if self.sites:
                    candidates = ((self.anchor, self.sites),) + tuple(
                        c for c in candidates if c != (self.anchor, self.sites))
                best = None
                for anchor, sites in candidates:
                    if w.expired():
                        break
                    if (not weapons.issubset(sites) or anchor in w.static
                            or (set(sites) - weapons).intersection(w.static | set(self.failed_sites))):
                        continue
                    gates = (self.locked_gate,) if self.locked_gate is not None else order
                    for gate in gates:
                        if gate is None or gate in present_walls or gate not in order:
                            continue
                        value = self._evaluate(w, anchor, sites, gate, order)
                        if value is None:
                            continue
                        if sites == self.sites and anchor == self.anchor and gate == self.gate:
                            current = (anchor, sites, gate, value)
                            break
                        if best is None or value[0] < best[3][0]:
                            best = (anchor, sites, gate, value)
                    if current:
                        break
                current = current or best
            if current:
                self.anchor, self.sites, self.gate, value = current
                _, self.targets, self.inner, self.backup_slots = value
                self.rocket_ready, self.ready, self.reason = True, True, "rocket_shared_ready"
                if present_walls:
                    self.locked_gate = self.gate
            else:
                self._fallback_prepare(w, order)
                if present_walls and self.gate is not None:
                    self.locked_gate = self.gate
            if not w.expired():
                self._plan_signature = signature
        self._publish(w)

    def _publish(self, w):
        super()._publish(w)
        w.rocket_sites = tuple(self.sites)
        w.rocket_anchor = self.anchor
        w.rocket_backup_slots = tuple(self.backup_slots)
        w.rocket_layout_ready = self.rocket_ready

    def weapon_sites(self, w):
        if self.rocket_ready:
            return tuple(p for p in self.sites if p not in w.static)
        return super().weapon_sites(w)

    def prospective_weapon_safe(self, w, candidate):
        if self.rocket_ready:
            return pos(candidate) in self.sites and pos(candidate) not in w.static
        return super().prospective_weapon_safe(w, candidate)

    def record(self, w, commands):
        if self.gate is not None and any(c.get("action") == "build" and c.get("name") == "wall"
                                         for c in commands.values()):
            self.locked_gate = self.gate
