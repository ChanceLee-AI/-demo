"""Two-worker, observation-based income plans; forecasts never become spendable gold."""
import itertools
from collections import Counter

from .world import action, dist, pos


MINERALS = ("stone", "iron", "copper")


def _reservation(mapping, key):
    try:
        return max(0, int((mapping or {}).get(key, 0)))
    except (TypeError, ValueError, OverflowError):
        return 0


def sellable_inventory(w, worker):
    """Observed mineral stock less this worker's reserved construction stone."""
    backpack = Counter(worker.get("backpack") or [])
    stock = Counter({kind: backpack[kind] for kind in MINERALS if backpack[kind]})
    reserved = _reservation(getattr(w, "reserved_stone", {}), str(worker["id"]))
    stock["stone"] = max(0, stock["stone"] - reserved)
    return stock


def mine_key(zone):
    return (zone["neutralType"],) + pos(zone)


class EconomyPlanner:
    def __init__(self):
        self.last_round = None
        self.last_gold = None
        self.pending = {}
        self.mines = {}
        self.blocked_until = {}
        self.plans = {}
        self.context = {}

    def observe(self, w):
        if self.last_round == w.round:
            return
        visible = {mine_key(z) for z in w.zones if z.get("neutralType") in MINERALS}
        # Ten is an initial upper estimate, not knowledge of other miners' work.
        self.mines = {key: self.mines.get(key, 10) for key in visible}
        self.blocked_until = {key: until for key, until in self.blocked_until.items()
                              if key in visible and until > w.round}
        events = []
        results = w.raw.get("lastRoundRoleActionResults") or {}
        results = {str(k): value for k, value in results.items()} if isinstance(results, dict) else {}
        for rid, previous in self.pending.items():
            if previous["round"] + 1 != w.round:
                continue
            role = w.own.get(rid)
            if not role:
                self.plans.pop(rid, None)
                continue
            stock = Counter(role.get("backpack", []))
            delta = {kind: stock[kind] - previous["stock"].get(kind, 0)
                     for kind in MINERALS if stock[kind] != previous["stock"].get(kind, 0)}
            verb = previous["action"]
            if verb in ("collect", "sell", "buy", "use"):
                event = {"role_id": rid, "action": verb, "feedback": results.get(rid), "stock_delta": delta}
                if previous.get("name"):
                    event["name"] = previous["name"]
                events.append(event)
            if verb == "collect":
                key = previous["mine"]
                gained = max(0, delta.get(key[0], 0))
                if key in self.mines:
                    self.mines[key] = max(0, self.mines[key] - gained)
                plan = self.plans.get(rid)
                if gained:
                    if plan and plan.get("mine") == key:
                        plan["remaining"] = max(0, plan["remaining"] - gained)
                else:
                    # No inventory gain is enough to stop repeating this collect;
                    # it is not proof that the mine was depleted or permanently closed.
                    self.blocked_until[key] = w.round + 5
                    self.plans.pop(rid, None)
            elif verb == "sell" and not any(stock[kind] for kind in MINERALS):
                self.plans.pop(rid, None)
        self.plans = {rid: plan for rid, plan in self.plans.items()
                      if rid in w.own and (plan.get("mine") is None or
                                          plan["mine"] in visible and self.mines[plan["mine"]] > 0)}
        self.context = {
            "round": w.round, "gold": w.gold,
            "gold_delta": None if self.last_gold is None else w.gold - self.last_gold,
            "prices": dict(w.prices), "daylight_left": w.daylight_left,
            "upgrade": {}, "events": events, "workers": {},
            "mine_estimates": [{"kind": key[0], "pos": list(key[1:]), "remaining_estimate": count}
                               for key, count in sorted(self.mines.items())],
        }
        for role in w.workers:
            stock = Counter(role.get("backpack", []))
            self.context["workers"][str(role["id"])] = {
                "pos": list(pos(role)), "stock": {key: value for key, value in stock.items() if value},
                "inventory_value": sum(stock[k] * w.prices.get(k, 0) for k in MINERALS),
                "mode": "unassigned", "reason": "not_scheduled",
            }
        self.last_round, self.last_gold = w.round, w.gold
        self.refresh_inventory(w)

    def refresh_inventory(self, w):
        """Reservations may be published after observe; read them at use time."""
        for role in w.workers:
            row = self.context.get("workers", {}).get(str(role["id"]))
            if row is not None:
                stock = Counter(role.get("backpack") or [])
                sellable = sellable_inventory(w, role)
                row["reserved_stone"] = stock["stone"] - sellable["stone"]
                row["sellable_value"] = sum(sellable[k] * w.prices.get(k, 0) for k in MINERALS)

    def note(self, rid, mode, reason, **details):
        row = self.context.get("workers", {}).get(str(rid))
        if row is not None:
            row.update(mode=mode, reason=reason, **details)

    def record(self, w, commands):
        """Replace provisional actions with the actual validated response when called again."""
        self.refresh_inventory(w)
        self.pending = {}
        for row in self.context.get("workers", {}).values():
            row.pop("action", None)
            row.pop("target", None)
        zones = {pos(z): z for z in w.zones if z.get("neutralType") in MINERALS}
        for rid, command in commands.items():
            role = w.own.get(str(rid))
            if not role or role.get("roleType") != "worker":
                continue
            verb = command.get("action")
            record = {"round": w.round, "action": verb, "stock": dict(Counter(role.get("backpack", []))),
                      "name": command.get("name")}
            if verb == "collect":
                targets = command.get("targetPos") or []
                zone = zones.get(pos(targets[0])) if targets else None
                if not zone:
                    continue
                record["mine"] = mine_key(zone)
            self.pending[str(rid)] = record
            row = self.context.get("workers", {}).get(str(rid))
            if row is not None:
                row["action"] = verb
                if command.get("targetPos"):
                    row["target"] = [list(pos(p)) for p in command["targetPos"]]

    @staticmethod
    def upgrade_trip(w, worker, start, target):
        """Actual path lengths for shop, building and the worker's own control cell."""
        rid = str(worker["id"])
        choices = []
        shops = sorted((z for z in w.zones if z.get("neutralType") == "weaponShop"),
                       key=lambda z: (dist(start, z), pos(z)))[:2]
        for shop in shops:
            if w.expired():
                break
            outbound = w.route(start, w.adjacent(shop), ignore_people={rid})
            if not outbound.reachable:
                continue
            delivery = w.route(outbound.goal, w.adjacent(target), ignore_people={rid})
            if not delivery.reachable:
                continue
            home = w.return_route(delivery.goal, ignore_people={rid})
            if not home.reachable:
                continue
            choices.append({"shop": shop, "outbound": outbound,
                            "turns": outbound.distance + delivery.distance + home.distance + 2,
                            "home_turns": home.distance})
        return min(choices, key=lambda x: (x["turns"], pos(x["shop"]))) if choices else None

    def _options(self, w, worker, closed, goal_gap, liquid_enough):
        rid = str(worker["id"])
        stock = sellable_inventory(w, worker)
        occupied_capacity = len(worker.get("backpack", []))
        disabled = getattr(w, "disabled_actions", set())
        home = w.return_route(worker)
        options = [{"mode": "wait", "income": 0, "harvest": 0, "mine_key": None,
                    "finish": home.goal if home.reachable else pos(worker),
                    "finish_turns": home.distance if home.reachable else 0,
                    "home_turns": 0 if home.reachable else None, "travel_turns": home.distance,
                    "score": 0.0, "reason": "no_feasible_economic_route"}]
        if w.expired():
            options[0]["reason"] = "budget_exhausted"
            return options
        vendors = sorted((z for z in w.zones if z.get("neutralType") == "vendor"),
                         key=lambda z: (dist(worker, z), pos(z)))[:2]
        if not vendors:
            options[0]["reason"] = "no_vendor"
        sellable = {k: stock[k] for k in MINERALS if stock[k] and w.prices.get(k, 0) > 0}
        income = sum(count * w.prices[k] for k, count in sellable.items())
        if "sell" not in disabled and income:
            for vendor in vendors:
                outward = w.route(worker, w.adjacent(vendor))
                if not outward.reachable:
                    continue
                back = w.return_route(outward.goal, ignore_people={rid})
                if not back.reachable:
                    continue
                turns = outward.distance + len(sellable)
                if turns + back.distance + w.return_margin <= w.daylight_left:
                    options.append({"mode": "sell", "income": income, "harvest": 0, "mine_key": None,
                                    "vendor": vendor, "finish": outward.goal, "finish_turns": turns,
                                    "home_turns": back.distance, "sell_turns": len(sellable),
                                    "travel_turns": outward.distance,
                                    "score": income / float(turns + back.distance + 1), "reason": "cash_in_inventory"})
        if "collect" in disabled or liquid_enough or occupied_capacity >= worker.get("backPackCapability", 100):
            if "collect" in disabled:
                options[0]["reason"] = "collect_disabled"
            elif liquid_enough:
                options[0]["reason"] = "joint_inventory_liquidation"
            else:
                options[0]["reason"] = "backpack_full"
            return options
        capacity = max(0, worker.get("backPackCapability", 100) - occupied_capacity)
        plan = self.plans.get(rid)
        stable = plan.get("mine") if plan and plan.get("remaining", 0) else None
        if plan and (plan.get("mode") == "sell" or plan.get("remaining") == 0) and income:
            return options
        mines = [z for z in w.zones if z.get("neutralType") in MINERALS
                 and self.available_yield(w, mine_key(z)) > 0 and self.blocked_until.get(mine_key(z), 0) <= w.round
                 and not closed(z["neutralType"], w.day) and w.prices.get(z["neutralType"], 0) > 0]
        mines.sort(key=lambda z: (mine_key(z) != stable, dist(worker, z), pos(z)))
        selected = [z for z in mines if mine_key(z) == stable]
        for kind in MINERALS:
            nearest = next((z for z in mines if z["neutralType"] == kind), None)
            if nearest is not None and nearest not in selected:
                selected.append(nearest)
        for mine in mines:
            if len(selected) >= 4:
                break
            if mine not in selected:
                selected.append(mine)
        if not selected:
            options[0]["reason"] = "no_priced_collectible_mine"
        elif vendors:
            options[0]["reason"] = "economic_route_or_time"
        stable_options = []
        for mine in selected:
            if w.expired():
                break
            key = mine_key(mine)
            outward = w.route(worker, w.adjacent(mine))
            if not outward.reachable:
                continue
            maximum = min(self.available_yield(w, key), capacity)
            if key == stable:
                maximum = min(maximum, plan["remaining"])
            mineral = key[0]
            price = w.prices[mineral]
            # When selling was explicitly disabled, gather only if a safe home
            # trip remains; inventory is held for another day and credited as zero.
            if "sell" in disabled:
                back = w.return_route(outward.goal, ignore_people={rid})
                limit = w.daylight_left - outward.distance - (back.distance or 0) - w.return_margin
                amount = min(maximum, limit) if back.reachable else 0
                if amount > 0:
                    options.append({"mode": "mine", "income": 0, "harvest": amount, "mine_key": key,
                                    "mine": mine, "finish": outward.goal,
                                    "finish_turns": outward.distance + amount, "home_turns": back.distance,
                                    "sell_turns": 0, "travel_turns": outward.distance,
                                    "score": price * amount / float(outward.distance + amount + back.distance + 1),
                                    "reason": "hold_inventory_sell_disabled"})
                continue
            for vendor in vendors:
                if w.expired():
                    break
                sale = w.route(outward.goal, w.adjacent(vendor), ignore_people={rid})
                if not sale.reachable:
                    continue
                back = w.return_route(sale.goal, ignore_people={rid})
                if not back.reachable:
                    continue
                travel = outward.distance + sale.distance
                limit = min(maximum, w.daylight_left - travel - back.distance - w.return_margin)
                if limit <= 0:
                    continue
                # Keep the mine stable, but let its quota shrink when a second
                # worker becomes available to share the same observed deposit.
                amounts = range(1, limit + 1)
                for amount in amounts:
                    projected = dict(worker, backpack=list(worker.get("backpack", [])) + [mineral] * amount)
                    after_collect = sellable_inventory(w, projected)
                    sold = {k: after_collect[k] for k in MINERALS if after_collect[k] and w.prices.get(k, 0) > 0}
                    value = sum(count * w.prices[k] for k, count in sold.items())
                    sell_turns = len(sold)
                    turns = travel + sell_turns + amount
                    if not value or turns + back.distance + w.return_margin > w.daylight_left:
                        continue
                    option = {"mode": "mine", "income": value, "harvest": amount, "mine_key": key,
                              "mine": mine, "vendor": vendor, "finish": sale.goal, "finish_turns": turns,
                              "home_turns": back.distance, "sell_turns": sell_turns,
                              "travel_turns": outward.distance + sale.distance,
                              "remaining_inventory": occupied_capacity + amount - sum(sold.values()),
                              "score": value / float(turns + back.distance + 1), "reason": "income_cycle"}
                    options.append(option)
                    if key == stable:
                        stable_options.append(option)
        if stable_options:
            # Preserve a feasible mine until its observed quota is met. A funded
            # upgrade can still interrupt it through the joint liquidation check.
            options = [o for o in options if o["mode"] == "wait"] + stable_options
        return options

    def available_yield(self, w, key):
        # Wall workers are outside the economic pair, but use the same deposit.
        return max(0, self.mines.get(key, 0) -
                   _reservation(getattr(w, "wall_mine_reservations", {}), key))

    @staticmethod
    def remaining_inventory(w, worker, choice):
        if "remaining_inventory" in choice:
            return choice["remaining_inventory"]
        remaining = len(worker.get("backpack", []))
        if choice["mode"] == "sell":
            stock = sellable_inventory(w, worker)
            remaining -= sum(stock[k] for k in MINERALS if w.prices.get(k, 0) > 0)
        elif choice["mode"] == "mine":
            remaining += choice["harvest"]
        return remaining

    def step(self, w, commands, workers, budget, goal, closed, move, defend):
        self.refresh_inventory(w)
        if not workers:
            return
        workers = sorted(workers, key=lambda p: str(p["id"]))[:2]
        gap = max(0, goal["price"] + goal["reserve"] - budget) if goal else 0
        liquid = sum(sum(sellable_inventory(w, p)[k] * w.prices.get(k, 0) for k in MINERALS)
                     for p in workers)
        options = [self._options(w, p, closed, gap, bool(goal and gap and liquid >= gap)) for p in workers]
        if goal and gap and liquid >= gap and sum(max(c["income"] for c in choices) for choices in options) < gap:
            # Stock behind an unusable route cannot finance the goal. The other
            # worker may still safely earn the missing income independently.
            options = [self._options(w, p, closed, gap, False) for p in workers]
        # Cache each possible courier's complete route once, not per combination.
        trips = {}
        if goal:
            for worker, choices in zip(workers, options):
                rid = str(worker["id"])
                for choice in choices:
                    if w.expired():
                        break
                    key = (rid, choice["finish"])
                    if key not in trips:
                        trips[key] = self.upgrade_trip(w, worker, choice["finish"], goal["target"])
        best, best_key, completion = None, None, None
        for choices in itertools.product(*options):
            if w.expired():
                break
            claims = Counter()
            for choice in choices:
                if choice["mine_key"]:
                    claims[choice["mine_key"]] += choice["harvest"]
            if any(amount > self.available_yield(w, key) for key, amount in claims.items()):
                continue
            total = sum(c["income"] for c in choices)
            finish = None
            courier = None
            if goal and total >= gap:
                # Income arrives on the observation after the corresponding sell.
                receipts = sorted((c["finish_turns"], c["income"]) for c in choices if c["income"])
                available, funded_at = 0, 0
                for when, value in receipts:
                    if available >= gap:
                        break
                    available += value
                    funded_at = when
                for worker, choice in zip(workers, choices):
                    rid = str(worker["id"])
                    if self.remaining_inventory(w, worker, choice) >= worker.get("backPackCapability", 100):
                        continue
                    trip = trips.get((rid, choice["finish"]))
                    if trip is None:
                        continue
                    end = max(funded_at, choice["finish_turns"]) + trip["turns"] + w.return_margin
                    if end <= w.daylight_left and (finish is None or end < finish):
                        finish, courier = end, rid
            rank = ((1, -finish, total, sum(c["score"] for c in choices)) if finish is not None else
                    (0, sum(c["score"] for c in choices), total, -sum(c["finish_turns"] for c in choices)))
            if best_key is None or rank > best_key:
                best, best_key, completion = choices, rank, (finish, courier)
        if goal:
            upgrade = self.context["upgrade"]
            upgrade.update(target_id=str(goal["target"]["id"]), voucher=goal["name"], price=goal["price"],
                           reserve=goal["reserve"], cash_gap=gap, joint_inventory_value=liquid,
                           reason="fundable_cycle" if completion and completion[0] is not None else
                           ("accumulating_or_no_upgrade_window" if gap else "cash_ready_no_upgrade_window"))
            if completion and completion[0] is not None:
                upgrade.update(trip_turns=completion[0], worker_id=completion[1])
        if best is None:
            for worker in workers:
                self.note(worker["id"], "wait", "budget_exhausted" if w.expired() else "no_feasible_economic_route")
                defend(w, commands, [worker])
            return
        for worker, choice, choices in zip(workers, best, options):
            rid = str(worker["id"])
            details = {key: choice[key] for key in ("sell_turns", "home_turns", "travel_turns") if key in choice}
            details["collect_turns"] = choice["harvest"]
            if choice.get("vendor"):
                details["vendor"] = list(pos(choice["vendor"]))
            if choice.get("mine"):
                details["mine"] = {"kind": choice["mine_key"][0], "pos": list(pos(choice["mine"]))}
            reason = "joint_plan_wait" if choice["mode"] == "wait" and len(choices) > 1 else choice["reason"]
            self.note(rid, choice["mode"], reason, **details)
            if choice["mode"] == "mine":
                self.plans[rid] = {"mode": "mine", "mine": choice["mine_key"], "remaining": choice["harvest"]}
                if w.near(worker, choice["mine"]):
                    commands[rid] = action("collect", pos(choice["mine"]))
                elif not move(w, commands, worker, w.adjacent(choice["mine"])):
                    self.note(rid, "mine", "mine_path_blocked")
            elif choice["mode"] == "sell":
                self.plans[rid] = {"mode": "sell", "mine": None, "remaining": 0}
                if w.near(worker, choice["vendor"]):
                    stock = sellable_inventory(w, worker)
                    kind = max((k for k in MINERALS if stock[k] and w.prices.get(k, 0) > 0),
                               key=lambda k: stock[k] * w.prices[k])
                    commands[rid] = action("sell", name=kind, num=stock[kind])
                elif not move(w, commands, worker, w.adjacent(choice["vendor"])):
                    self.note(rid, "sell", "vendor_path_blocked")
            else:
                defend(w, commands, [worker])
