"""Two-worker material batches and a persistent, observed perimeter build plan."""
from collections import Counter

from .economy import mine_key
from .world import action, dist, pos


BATCH_SIZE = 6


class FortificationPlanner:
    def __init__(self):
        self.plans = {}
        self.known_targets = set()
        self.report = {}

    @staticmethod
    def _stock(worker):
        return Counter(worker.get("backpack") or []).get("stone", 0)

    def reserve(self, w, construction):
        """Reserve existing material, including at night and on a paused workday."""
        targets = set(getattr(w, "wall_targets", ()))
        if targets:
            self.known_targets = targets
        standing = {pos(role) for role in w.own.values() if role.get("roleType") == "wall"}
        remaining = self.known_targets - standing
        disabled = ("wall" in construction.disabled_kinds | getattr(construction, "paused_kinds", set())
                    or "build" in getattr(w, "disabled_actions", set()))
        if not w.station or disabled:
            remaining = set()
        budget = len(remaining)
        reservations = {}
        for worker in sorted(w.workers, key=lambda role: str(role["id"])):
            amount = min(self._stock(worker), budget)
            reservations[str(worker["id"])] = amount
            budget -= amount
        w.reserved_stone = reservations
        if not remaining:
            self.plans.clear()
        live = {str(worker["id"]) for worker in w.workers}
        self.plans = {rid: plan for rid, plan in self.plans.items() if rid in live}
        self.report = {"round": w.round, "target_count": len(self.known_targets),
                       "standing": len(self.known_targets & standing), "remaining": len(remaining),
                       "reserved_stone": dict(reservations), "workers": {},
                       "reason": "disabled" if disabled else "complete" if not remaining else "pending"}
        w.wall_work = self.report

    @staticmethod
    def _home_goals(w, worker):
        rid = str(worker["id"])
        assigned = w.defense_assignments.get(rid)
        if assigned:
            return {tuple(assigned["pos"])}
        if rid in w.defense_refuges:
            return {tuple(w.defense_refuges[rid])}
        objects = w.weapons or ([w.station] if w.station else [])
        return {cell for obj in objects for cell in w.adjacent(obj)}

    def _tour(self, w, worker, start, targets, count, add_walls=()):
        """Short greedy delivery tour; each prefix includes its own safe return."""
        layout = w.wall_layout
        available, future = set(targets), set(add_walls)
        current, elapsed, first = pos(start), 0, None
        options = []
        order = {cell: index for index, cell in enumerate(layout.targets)}
        for _ in range(min(BATCH_SIZE, count, len(available))):
            if w.expired():
                break
            choices = []
            for cell in sorted(available, key=lambda cell: order.get(cell, len(order))):
                if w.expired():
                    break
                if cell == current or cell in w.static | future:
                    continue
                # The target becomes a wall only after arriving at its control
                # square. All candidates share the same pre-build static graph.
                route = layout.route(w, current, w.adjacent(cell) - future - {cell}, add_walls=future)
                if route.reachable:
                    choices.append((route.distance, order.get(cell, len(order)), cell, route))
            if not choices:
                break
            _, _, cell, route = min(choices, key=lambda item: item[:2])
            elapsed += route.distance + 1
            current = route.goal
            future.add(cell)
            available.remove(cell)
            if first is None:
                first = cell
            home = layout.route(w, current, self._home_goals(w, worker), add_walls=future)
            if home.reachable:
                options.append({"count": len(future) - len(set(add_walls)), "turns": elapsed + home.distance,
                                "first": first, "home_turns": home.distance})
        return options

    def _note(self, economy, worker, reason, **details):
        rid = str(worker["id"])
        self.report["workers"][rid] = dict(reason=reason, **details)
        economy.note(rid, "wall", reason, **details)

    def _build(self, w, commands, worker, targets, construction, economy, move, claimed, additions, stands):
        rid, current = str(worker["id"]), pos(worker)
        old = self.plans.get(rid, {})
        destinations = {pos(cell) for command in commands.values() if command.get("action") == "move"
                        for cell in command.get("targetPos", [])}
        candidates = [cell for cell in targets if cell not in claimed | additions | destinations
                      and cell not in w.occupied and not construction.avoided("wall", cell, w)]
        order = {cell: index for index, cell in enumerate(w.wall_layout.targets)}
        choices = []
        for cell in candidates:
            if w.expired():
                break
            goals = w.adjacent(cell) - additions - stands - {cell}
            route = w.route(worker, goals, reserved=additions | destinations)
            if cell == old.get("target") and old.get("stand") in goals:
                retained = w.route(worker, {old["stand"]}, reserved=additions | destinations)
                if retained.reachable:
                    route = retained
            if route.reachable and not (route.distance and "move" in getattr(w, "disabled_actions", set())):
                choices.append((cell != old.get("target"), route.distance, order.get(cell, len(order)), cell, goals, route))
        for _, _, _, cell, goals, route in sorted(choices, key=lambda item: item[:3]):
            if w.expired():
                break
            if not w.wall_layout.safe(w, additions | {cell}, commands):
                continue
            home = w.wall_layout.route(w, route.goal, self._home_goals(w, worker), add_walls=additions | {cell})
            if not home.reachable or route.distance + 1 + home.distance + w.return_margin > w.daylight_left:
                continue
            self.plans[rid] = {"mode": "build", "target": cell, "stand": route.goal}
            claimed.add(cell)
            stands.add(route.goal)
            if dist(worker, cell) <= 1:
                commands[rid] = action("build", cell, name="wall")
                additions.add(cell)
                self._note(economy, worker, "build_wall", target=list(cell), home_turns=home.distance)
                return True
            if move(w, commands, worker, {route.goal}):
                self._note(economy, worker, "deliver_material", target=list(cell), home_turns=home.distance)
                return True
            self._note(economy, worker, "wall_route_blocked", target=list(cell))
            return True
        self.plans.pop(rid, None)
        self._note(economy, worker, "no_safe_wall_window")
        return False

    def step(self, w, commands, workers, economy, construction, move, closed):
        """Return only workers committed to feasible wall work this round."""
        w.wall_mine_reservations = {}
        if w.night or not workers:
            return set()
        layout = getattr(w, "wall_layout", None)
        if not layout or not layout.ready or not construction.available("wall", w):
            self.report["reason"] = "layout_unavailable" if not layout or not layout.ready else "construction_paused"
            return set()
        standing = {pos(role) for role in w.own.values() if role.get("roleType") == "wall"}
        targets = set(layout.targets) - standing
        if not targets:
            self.report["reason"] = "complete"
            self.plans.clear()
            return set()
        targets = {cell for cell in targets if not construction.avoided("wall", cell, w)}
        if not targets:
            self.report["reason"] = "construction_paused"
            return set()
        self.report["reason"] = "fortifying"
        workers = sorted(workers, key=lambda worker: (self.plans.get(str(worker["id"]), {}).get("mode") != "mine", str(worker["id"])))
        stocks = {str(worker["id"]): self._stock(worker) for worker in w.workers}
        deficit = max(0, len(targets) - sum(stocks.values()))
        committed, claimed, additions, stands = set(), set(), set(), set()
        mine_reserved = Counter()
        # Mining reservations include all remaining yields in a worker's current
        # batch. They are promises, not decrements of observed mine inventory.
        usable = {mine_key(zone): zone for zone in w.zones if zone.get("neutralType") == "stone"
                  and economy.mines.get(mine_key(zone), 0) > 0
                  and economy.blocked_until.get(mine_key(zone), 0) <= w.round}
        if closed("stone", w.day) or "collect" in getattr(w, "disabled_actions", set()):
            usable = {}
        for index, worker in enumerate(workers):
            if w.expired():
                break
            rid, stock = str(worker["id"]), stocks[str(worker["id"])]
            old = self.plans.get(rid, {})
            old_mine = old.get("mine")
            keep_batch = old.get("mode") == "mine" and old_mine in usable and stock < old.get("batch_goal", 0)
            if stock and not keep_batch:
                if self._build(w, commands, worker, targets, construction, economy, move, claimed, additions, stands):
                    committed.add(rid)
                continue
            if deficit <= 0 or not usable:
                if stock and self._build(w, commands, worker, targets, construction, economy, move, claimed, additions, stands):
                    committed.add(rid)
                else:
                    self.plans.pop(rid, None)
                    self._note(economy, worker, "materials_allocated" if deficit <= 0 else "no_stone_mine")
                continue
            capacity = max(0, worker.get("backPackCapability", 100) - len(worker.get("backpack", [])))
            new_goal = min(BATCH_SIZE, stock + (deficit + len(workers) - index - 1) // (len(workers) - index))
            quota = min(capacity, deficit, max(0, (old.get("batch_goal", stock) if keep_batch else new_goal) - stock))
            candidates = sorted(usable.items(), key=lambda pair: (pair[0] != old_mine if keep_batch else False,
                                                                 dist(worker, pair[1]), pair[0]))
            selected = None
            for key, mine in candidates:
                if w.expired():
                    break
                harvest = min(quota, max(0, economy.mines.get(key, 0) - mine_reserved[key]))
                if harvest <= 0:
                    continue
                goals = w.adjacent(mine) - stands - additions
                route = w.route(worker, goals)
                if not route.reachable or route.distance and "move" in getattr(w, "disabled_actions", set()):
                    continue
                # Preserve the collection square as well as the mine, avoiding
                # two workers oscillating between opposite preferred stands.
                previous_stand = old.get("stand")
                if key == old_mine and previous_stand in goals:
                    retained = w.route(worker, {previous_stand})
                    if retained.reachable:
                        route = retained
                tours = self._tour(w, worker, route.goal, targets - claimed, stock + harvest, additions)
                for amount in range(harvest, 0, -1):
                    delivery = next((tour for tour in tours if tour["count"] == stock + amount), None)
                    if delivery and route.distance + amount + delivery["turns"] + w.return_margin <= w.daylight_left:
                        selected = key, mine, route, amount, delivery
                        break
                if selected:
                    break
            if selected is None:
                if stock and self._build(w, commands, worker, targets, construction, economy, move, claimed, additions, stands):
                    committed.add(rid)
                else:
                    self.plans.pop(rid, None)
                    self._note(economy, worker, "no_material_round_trip")
                continue
            key, mine, route, amount, delivery = selected
            total_turns = route.distance + amount + delivery["turns"]
            stands.add(route.goal)
            mine_reserved[key] += amount
            deficit -= amount
            self.plans[rid] = {"mode": "mine", "mine": key, "stand": route.goal,
                               "batch_goal": stock + amount}
            if route.distance == 0:
                commands[rid] = action("collect", pos(mine))
                self._note(economy, worker, "collect_material", batch_goal=stock + amount,
                           remaining_collect=amount, mine=list(pos(mine)), home_turns=delivery["home_turns"],
                           total_turns=total_turns, estimated_finish_round=w.round + total_turns - 1,
                           return_margin=w.return_margin)
                committed.add(rid)
            elif move(w, commands, worker, {route.goal}):
                self._note(economy, worker, "seek_material", batch_goal=stock + amount,
                           remaining_collect=amount, mine=list(pos(mine)), home_turns=delivery["home_turns"],
                           total_turns=total_turns, estimated_finish_round=w.round + total_turns - 1,
                           return_margin=w.return_margin)
                committed.add(rid)
            else:
                self._note(economy, worker, "material_route_blocked", mine=list(pos(mine)))
                committed.add(rid)
        w.wall_mine_reservations = dict(mine_reserved)
        return committed
