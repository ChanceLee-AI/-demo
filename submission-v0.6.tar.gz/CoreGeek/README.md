# 《未来战争》Agent v0.6

v0.6 参考官方 Demo，采用加特林、电磁、火箭各一座，三炮后两名工人优先采石完成第二圈围墙。保留任务解题、返程、稳定操炮、平台库验证和依赖审计。沿用平台已成功运行的 SDK：顶层 **CoreGeek/**，入口 **CoreGeek/main3.py**。本版比赛收益和首夜生存仍需平台试跑验证。

## 提交与运行

上传 agent_demo/dist/submission-v0.6.tar.gz，不增加 SDK、python3sdk 或 agent_demo 外层，也不将 CoreGeek 内文件平铺到包根目录。

```text
submission-v0.6.tar.gz
└── CoreGeek/
    ├── main3.py
    ├── main.py
    ├── run.sh
    ├── VERSION
    ├── README.md
    └── agent/
```

解压后用平台传入端口启动，监听 0.0.0.0：

```bash
python3 CoreGeek/main3.py 8080
# 辅助入口
bash CoreGeek/run.sh 8080
```

没有第三方运行依赖，不在启动时安装软件或联网。归档为 UTF-8/LF，run.sh 权限 0755。运行版本来自包内常量，打包时校验 VERSION；每版生成 tar.gz、备用 ZIP、manifest 和 SHA256SUMS，历史包保持不变。

## 平台交互

平台 POST 当前状态，HTTP 响应直接包含三个字段：

```json
{"roleCommandMap": {}, "prompt": "", "executeCmd": ""}
```

正常请求填入角色动作，不增加 data 等包装层。prompt 和 executeCmd 由平台统一模型和任务沙盒处理，下一回合读取 llmResp、lastCmdResult；Agent 不需要模型密钥，也不在本机执行模型命令。同回合重复请求使用缓存。

main3.py/main.py 的 callback 与 module.app 共用一个 Engine 和互斥锁。有 Flask 时支持其 WSGI 路由，无 Flask 时提供标准 WSGI callable；直接运行使用标准库 HTTP 服务。v0.6 保持这些已验证入口。

## 库兼容与打包检查

正式入口 CoreGeek/main3.py 连接 main.py 和 Agent，必须保留。原始示例 docs/main3.py.py 只作参考，未进入归档。

Agent 服务仍仅使用标准库与平台已提供的可选 Flask，不自带第三方运行库。候选解题库为 requests、numpy、pandas、networkx、sympy、PIL（Pillow）、yaml（PyYAML）；提示词给出平台声明版本，但不保证任务沙盒具有相同环境。首次实际使用时在同条命令中确认导入，缺库采用已验证能力，不联网安装，不跨任务假定环境相同。收尾阶段禁止为探测库启动新命令。

打包器审计实际入包源码的导入，核对目标 Python 3.11 标准库、项目模块及声明的平台依赖；未知外部依赖、缺失本地模块和无法确认的动态导入会阻止打包。仅作为数据保存的沙盒命令不属于 Agent 导入。候选库常量在构建时与原始平台库清单校验，运行不读取 docs 文件。

## 本版比赛策略

- 新建顺序为加特林、电磁、火箭，优先官方第一圈炮位；不替换已有武器。落炮前检查不同内侧操控格的匹配，连续前三格导致炮手争位时，第三炮改用下一处可行第一圈位置。三炮后两工人优先完成第二圈围墙，通常 19 座并保留固定入口；固定障碍减少目标，临时人员占位只延后施工。
- 采石每人每批最多六块，共享矿点估计、材料需求、墙位及施工站位预约，按实际路程缩小批次。每次拟建墙联合检查通路，保持基地内外、商店、商人和原可达己方任务点连接。
- 围墙所需石头从实际出售、预计收入和联合可变现金一致扣除，容量按完整背包计算。当天暂停保留材料，完成或本场停用后释放；下一天优先补上未完成或被毁的墙。
- 无可执行墙工作时恢复原经济计划，围绕下一次升级安排采集和变现；出售所得须实际到账才可购买。
- 升级路线包含出售、购买、使用和指定战位返程，保留五回合余量。已有基地券可邻近使用；其余按时返程、补齐三炮、筑墙、交易购券的顺序安排，普通升级沿用基地二级、火箭和电磁优先，采用实际报价。夜间只允许附近持券角色应急升级，不远行购买。
- 任务分探索、收尾、提交、返程。命令必须留出返回结果、模型整理和提交的回合；收尾只使用已有证据，新可靠部分答案及时提交，不编造答案。
- 白天优先预留基地内侧合法操炮位置，布局与任务返程共用。夜间已能操炮且没有立即致命危险的角色保持工作。避险优先原炮旁单步移动，其他炮手继续开火，不为细小风险变化交换工作中的炮。保留原弹道和目标选择。
- 墙与三种炮分别追踪建造反馈，只记录最终发出的动作。墙普通失败当天跳格，四次明确失败暂停至次日；同格两次未确认也当天跳过。墙指令错误只停用墙，混合无法归因时暂停仍有嫌疑的类型。
- 明确标记 neutralType=land 的空地在统一地图入口过滤，保留原始请求；未知地形仍作障碍。
- 主动召唤机器人仍关闭，宝藏采购不得占用防守资金。不假设建筑一定阻挡机器人攻击。

## 日志与反馈

日志输出 stdout/stderr，两流合并可能重复；FUTUREWAR_LOG 可选增加文件输出，日志失败不影响响应。

- boot、connection、request、callback：保留入口、监听及首次请求诊断。
- walls：记录围墙目标、观察完成数、入口、采石/返场/建墙阶段、材料预留、返程估计、实际发送的建造和逐工人反馈；发送与确认建成分开。
- economy：每五个白昼回合、经济事件及空闲时记录库存、报价、资金缺口、规划和动作反馈。
- task：记录时限、阶段、命令状态、提交意图及反馈；失败摘要限长，不输出完整题面、命令或模型内容。
- battle：每个夜间回合记录炮位、操作者、攻击落点、冷却、未开火原因，及相关机器人位置、血量和变化，数量受限。
- resources：记录金币和总积分的观察变化。变化可能来自同回合多个事件，不强行归因。

attacks_sent 表示已发送，attack_feedback_legal 表示平台反馈为真，均不等于击杀。机器人消失记为 absent，天亮清场不计为我方击杀。结构化诊断单条 JSON 限制为 24 KiB，过大记录显式标注截断。

试跑后优先反馈围墙实际建成数量、入口是否可用、三炮是否持续工作、基地掉血与是否进入第 131 回合；同时关注金币下降和任务奖励。保留完整文本日志即可，无需手工整理。

## 开发验证

所有开发、测试和打包均在 agent_demo 内：

```bash
python -B -m unittest discover -s tests -v
python -B tools/check_fortifications.py
python -B tools/package.py
python -B tools/probe_sdk_entrypoints.py --archive dist/submission-v0.6.tar.gz --output dist/sdk-entrypoints-v0.6-baseline.json
python -B tools/smoke_package.py --archive dist/submission-v0.6.tar.gz
```

实际归档测试覆盖随机端口、含空格路径、不同工作目录、callback/WSGI/直接入口、1300 回合 HTTP 和双方有限行动场景。Flask 测试依赖位于 tools 下的两个隔离目录，均排除于提交包。

固定版本测试依赖独立位于 tools/.sdk-platform-deps：Flask 3.0.3、Werkzeug 3.0.4、Jinja2 3.1.4、MarkupSafe 2.1.5、itsdangerous 2.2.0、click 8.1.7、blinker 1.8.2，使用已确认的 Python 3.11.15 执行探针并通过 --flask-deps 指定该目录。现有 Python 3.14.6 与 tools/.sdk-test-deps 保留为另一套兼容检查。--output 可分别保存两套报告，报告记录实际解释器、库版本、导入位置和后端。

本机仍是 Windows，目标 Linux / Python 3.11.10 以平台运行验收为准；Python 3.11.15 与指定七库验证不等于完整平台环境验证。合成场景没有完整机器人行为、伤害或对手策略，不作为胜率证明。检查结果见 dist 内 v0.6 报告。
