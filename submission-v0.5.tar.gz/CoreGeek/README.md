# 《未来战争》Agent v0.5

v0.5 改进升级资金规划、任务答案收尾和夜间持续开火。沿用平台已成功运行的 SDK：顶层 **CoreGeek/**，入口 **CoreGeek/main3.py**。本版比赛收益和首夜生存仍需平台试跑验证。

## 提交与运行

上传 agent_demo/dist/submission-v0.5.tar.gz，不增加 SDK、python3sdk 或 agent_demo 外层，也不将 CoreGeek 内文件平铺到包根目录。

```text
submission-v0.5.tar.gz
└── CoreGeek/
    ├── main3.py
    ├── main.py
    ├── run.sh
    ├── VERSION
    ├── README.md
    └── agent/
```

解压后用平台传入端口启动，监听 0.0.0.0：

```bash
python3 CoreGeek/main3.py 8080
# 辅助入口
bash CoreGeek/run.sh 8080
```

没有第三方运行依赖，不在启动时安装软件或联网。归档为 UTF-8/LF，run.sh 权限 0755。运行版本来自包内常量，打包时校验 VERSION；每版生成 tar.gz、备用 ZIP、manifest 和 SHA256SUMS，历史包保持不变。

## 平台交互

平台 POST 当前状态，HTTP 响应直接包含三个字段：

```json
{"roleCommandMap": {}, "prompt": "", "executeCmd": ""}
```

正常请求填入角色动作，不增加 data 等包装层。prompt 和 executeCmd 由平台统一模型和任务沙盒处理，下一回合读取 llmResp、lastCmdResult；Agent 不需要模型密钥，也不在本机执行模型命令。同回合重复请求使用缓存。

main3.py/main.py 的 callback 与 module.app 共用一个 Engine 和互斥锁。有 Flask 时支持其 WSGI 路由，无 Flask 时提供标准 WSGI callable；直接运行使用标准库 HTTP 服务。v0.5 保持这些已验证入口。

## 本版策略

- 两工人围绕下一次升级联合安排采集、变现；库存足够补齐券价时可提前出售，矿点共享剩余产量估计。出售所得须实际到账才可购买。
- 升级路线包含出售、购买、使用和指定战位返程，保留五回合余量。优先三炮（两电磁、一火箭），再基地二级、火箭和电磁升级，采用实际报价。夜间只允许附近持券角色应急升级，不远行购买。
- 任务分探索、收尾、提交、返程。命令必须留出返回结果、模型整理和提交的回合；收尾只使用已有证据，新可靠部分答案及时提交，不编造答案。
- 已能操炮且没有立即致命危险的角色保持工作。避险优先原炮旁单步移动，其他炮手继续开火，不为细小风险变化交换工作中的炮。保留原弹道和目标选择。
- 主动召唤机器人仍关闭，宝藏采购不得占用防守资金。不假设建筑一定阻挡机器人攻击。

## 日志与反馈

日志输出 stdout/stderr，两流合并可能重复；FUTUREWAR_LOG 可选增加文件输出，日志失败不影响响应。

- boot、connection、request、callback：保留入口、监听及首次请求诊断。
- economy：每五个白昼回合、经济事件及空闲时记录库存、报价、资金缺口、规划和动作反馈。
- task：记录时限、阶段、命令状态、提交意图及反馈；失败摘要限长，不输出完整题面、命令或模型内容。
- battle：每个夜间回合记录炮位、操作者、攻击落点、冷却、未开火原因，及相关机器人位置、血量和变化，数量受限。
- resources：记录金币和总积分的观察变化。变化可能来自同回合多个事件，不强行归因。

attacks_sent 表示已发送，attack_feedback_legal 表示平台反馈为真，均不等于击杀。机器人消失记为 absent，天亮清场不计为我方击杀。结构化诊断单条 JSON 限制为 24 KiB，过大记录显式标注截断。

试跑后优先反馈版本及阵营、首次升级回合、任务提交与奖励、是否进入第 131 回合及首夜炮手/基地状态。保留完整文本日志即可，无需手工整理。

## 开发验证

所有开发、测试和打包均在 agent_demo 内：

```bash
python -B -m unittest discover -s tests -v
python -B tools/package.py
python -B tools/probe_sdk_entrypoints.py --archive dist/submission-v0.5.tar.gz
python -B tools/smoke_package.py --archive dist/submission-v0.5.tar.gz
```

实际归档测试覆盖随机端口、含空格路径、不同工作目录、callback/WSGI/直接入口、1300 回合 HTTP 和双方有限行动场景。Flask 测试依赖只在 tools/.sdk-test-deps，排除于提交包。

本地为 Windows / Python 3.14.6 / Git Bash；目标 Linux / Python 3.11.10 以平台运行验收为准。合成场景没有完整机器人行为、伤害或对手策略，不作为胜率证明。检查结果见 dist 内 v0.5 报告。
