"""A bounded opening move, acknowledged by the next observed position."""
from .world import action, pos, dist


class OpeningCheck:
    def __init__(self, enabled):
        self.done = not enabled
        self.attempts = 0
        self.pending = None
        self.failed = set()
        self.status = "pending" if enabled else "skipped"

    def step(self, w, commands):
        if self.done:
            return False
        if self.pending and w.round > self.pending["round"]:
            pending = self.pending
            self.pending = None
            person = w.own.get(pending["role"])
            if person and pos(person) == pending["target"]:
                self.done, self.status = True, "confirmed"
                return False
            self.failed.add((pending["role"], pending["start"], pending["target"]))
        if self.attempts >= 3 or w.night or w.raw.get("phaseTask"):
            self.done, self.status = True, "unconfirmed"
            return False
        mines = [z for z in w.zones if z.get("neutralType") in ("stone", "iron", "copper")]
        for worker in sorted(w.workers, key=lambda r: int(r["id"])):
            rid, start = str(worker["id"]), pos(worker)
            forbidden = {end for actor, origin, end in self.failed if actor == rid and origin == start}
            goals = {g for mine in mines for g in w.adjacent(mine)}
            route = w.path(worker, goals, forbidden) if goals else None
            target = route[0] if route else None
            if target is None:
                candidates = [p for p in w.neighbors(start) if p not in w.occupied and p not in forbidden]
                if candidates:
                    target = min(candidates, key=lambda p: (min((dist(p, m) for m in mines), default=0), p))
            if target is None or target in w.occupied or target in forbidden:
                continue
            commands[rid] = action("move", target)
            self.pending = {"round": w.round, "role": rid, "start": start, "target": target}
            self.attempts += 1
            self.status = "awaiting_position"
            return True
        self.done, self.status = True, "no_free_step"
        return False
