"""Normalized observations and conservative eight-direction path finding."""
import time
from collections import deque

PEOPLE = ("worker", "pioneer")
WEAPONS = ("railgun", "rocket", "gatling")
RANGES = {"railgun": (6, 8, 10), "rocket": (10, 15, 2147483647), "gatling": (3, 5, 7)}
DIRECTIONS = tuple((x, y) for x in (-1, 0, 1) for y in (-1, 0, 1) if x or y)


def pos(obj):
    if isinstance(obj, dict):
        obj = obj.get("pos", obj)
        return (int(obj["x"]), int(obj["y"]))
    return (int(obj[0]), int(obj[1]))


def dist(a, b):
    a, b = pos(a), pos(b)
    return max(abs(a[0] - b[0]), abs(a[1] - b[1]))


def action(verb, target=None, **kwargs):
    result = {"action": verb}
    if target is not None:
        x, y = pos(target)
        result["targetPos"] = [{"x": x, "y": y}]
    result.update(kwargs)
    return result


class PathResult:
    """A route outcome; suggested_steps for a blocked route are never executable."""
    def __init__(self, status, steps=None, distance=None, goal=None, suggested_steps=None):
        self.status = status
        self.steps = steps
        self.distance = len(steps) if steps is not None else distance
        self.goal = goal
        self.suggested_steps = suggested_steps or []

    @property
    def reachable(self):
        return self.status in ("arrived", "reachable")


def _alive(items):
    result = []
    for item in items or []:
        if not isinstance(item, dict):
            continue
        try:
            p = pos(item)
            if int(item.get("health", 1)) <= 0:
                continue
            role = dict(item)
            role["pos"] = {"x": p[0], "y": p[1]}
            kind = role.get("roleType", "")
            if kind in WEAPONS:
                level = min(3, max(1, int(role.get("level", 1))))
                role["level"] = level
                role.setdefault("attackRange", RANGES[kind][level - 1])
                role.setdefault("attackPower", 20 if kind == "rocket" else 10 * (level if kind == "railgun" else 1))
                # Missing rocket cooldown is inferred in the game module.
            result.append(role)
        except (KeyError, TypeError, ValueError, IndexError):
            continue
    return result


class World:
    def __init__(self, raw, origin=1, deadline=None):
        self.raw = raw
        self.round = int(raw["roundNo"])
        self.turn = max(0, self.round - origin) % 130
        self.day = max(0, self.round - origin) // 130 + 1
        self.night = self.turn >= 70
        self.daylight_left = max(0, 70 - self.turn)
        self.deadline = deadline if deadline is not None else float("inf")
        info = raw.get("mapInfo") or {}
        self.width = min(128, max(1, int(info.get("width", 41))))
        self.height = min(128, max(1, int(info.get("height", 32))))
        our = raw.get("teamOur") or {}
        self.team_type = our.get("type", "challenger")
        self.gold = max(0, int(our.get("goldNum", 0)))
        self.own = {str(r["id"]): r for r in _alive(our.get("roles", [])) if "id" in r}
        self.people = [r for r in self.own.values() if r.get("roleType") in PEOPLE]
        self.workers = [r for r in self.people if r["roleType"] == "worker"]
        self.pioneer = next((r for r in self.people if r["roleType"] == "pioneer"), None)
        self.station = next((r for r in self.own.values() if r.get("roleType") == "station"), None)
        self.weapons = [r for r in self.own.values() if r.get("roleType") in WEAPONS]
        self.enemy = _alive((raw.get("teamEnemy") or {}).get("roles", []))
        robots = raw.get("robot") or {}
        self.robots = _alive(robots.get("roles", []) if isinstance(robots, dict) else robots)
        self.zones = [z for z in info.get("zones", []) if isinstance(z, dict) and "pos" in z]
        self.prices = self._prices(raw.get("vendorShopList", []))
        self.shop = self._prices(raw.get("weaponShopList", []))
        self.static = set()
        for obj in list(self.own.values()) + self.enemy:
            if obj.get("roleType") not in PEOPLE:
                self.static.update(self.footprint(obj))
        for z in self.zones:
            self.static.add(pos(z))
        self.occupied = set(self.static)
        for obj in self.people + self.enemy + self.robots:
            self.occupied.update(self.footprint(obj))
        self._trees = {}
        self.move_avoid = {}
        self.blocked_routes = []

    @staticmethod
    def _prices(items):
        result = {}
        for item in items or []:
            try:
                result[str(item["name"])] = max(0, int(item["price"]))
            except (TypeError, ValueError, KeyError):
                pass
        return result

    def expired(self):
        return time.monotonic() >= self.deadline

    def in_bounds(self, p):
        x, y = pos(p)
        return 0 <= x < self.width and 0 <= y < self.height

    def footprint(self, obj):
        x, y = pos(obj)
        if isinstance(obj, dict) and obj.get("roleType") == "station":
            return {(x, y), (x + 1, y), (x, y - 1), (x + 1, y - 1)}
        return {(x, y)}

    def near(self, a, b):
        return min(dist(a, p) for p in self.footprint(b)) <= 1

    def neighbors(self, p):
        x, y = pos(p)
        return [(x + dx, y + dy) for dx, dy in DIRECTIONS if self.in_bounds((x + dx, y + dy))]

    def adjacent(self, obj):
        footprint = self.footprint(obj)
        cells = {n for p in footprint for n in self.neighbors(p)}
        return cells - footprint - self.static

    def _search(self, start, goals, blocked, key):
        if key not in self._trees:
            parents = {start: None}
            depths = {start: 0}
            queue = deque([start])
            count = 0
            complete = True
            while queue:
                current = queue.popleft()
                count += 1
                if count % 64 == 0 and self.expired():
                    complete = False
                    break
                for nxt in self.neighbors(current):
                    if nxt not in parents and nxt not in blocked:
                        parents[nxt] = current
                        depths[nxt] = depths[current] + 1
                        queue.append(nxt)
            self._trees[key] = (parents, depths, complete)
        parents, depths, complete = self._trees[key]
        reachable = goals.intersection(parents)
        if not reachable:
            return None, complete
        end = min(reachable, key=lambda p: (depths[p], p))
        steps = []
        while end != start:
            steps.append(end)
            end = parents[end]
        return list(reversed(steps)), complete

    def route(self, role_or_pos, goals, reserved=(), ignore_people=()):
        start = pos(role_or_pos)
        goals = {pos(g) for g in goals if self.in_bounds(g)}
        if start in goals:
            return PathResult("arrived", [], goal=start)
        if self.expired():
            return PathResult("budget_exhausted")
        if not goals or not self.in_bounds(start):
            return PathResult("unreachable")
        extra = frozenset(pos(p) for p in reserved)
        ignored = {str(i) for i in ignore_people}
        cleared = frozenset(pos(p) for p in self.people if str(p["id"]) in ignored)
        blocked = ((self.occupied - set(cleared)) | set(extra)) - {start}
        steps, complete = self._search(start, goals, blocked, (start, extra, cleared, False))
        if steps is not None:
            return PathResult("reachable", steps, goal=steps[-1])
        if not complete or self.expired():
            return PathResult("budget_exhausted")
        # A failed search with current actors is not proof of permanent disconnection.
        steps, complete = self._search(start, goals, self.static - {start}, (start, False, True))
        if steps is not None:
            return PathResult("blocked", distance=len(steps), goal=steps[-1], suggested_steps=steps)
        return PathResult("unreachable" if complete else "budget_exhausted")

    def path(self, role_or_pos, goals, reserved=(), ignore_people=()):
        """Legacy wrapper: [] when arrived, a path when reachable, otherwise None."""
        return self.route(role_or_pos, goals, reserved, ignore_people).steps

    def move_toward(self, role, goals, commands):
        if "move" in getattr(self, "disabled_actions", set()):
            return None
        reserved = set(self.move_avoid.get(str(role.get("id", "")), set()))
        for cmd in commands.values():
            if cmd.get("action") in ("move", "build"):
                reserved.update(pos(p) for p in cmd.get("targetPos", []))
        result = self.route(role, goals, reserved)
        if result.status == "blocked":
            self.blocked_routes.append((str(role["id"]), result.suggested_steps))
        return action("move", result.steps[0]) if result.steps else None

    def return_route(self, role, ignore_people=()):
        """Prefer a reachable gun, then a reachable base; retain temporary blockage."""
        outcomes = []
        for targets in (self.weapons, [self.station] if self.station else []):
            if not targets:
                continue
            goals = {g for t in targets for g in self.adjacent(t)}
            result = self.route(role, goals, ignore_people=ignore_people)
            if result.reachable:
                return result
            outcomes.append(result)
            if result.status == "budget_exhausted":
                return result
        blocked = [r for r in outcomes if r.status == "blocked"]
        if blocked:
            return min(blocked, key=lambda r: r.distance)
        return PathResult("unreachable")

    def return_distance(self, role):
        result = self.return_route(role)
        return result.distance if result.distance is not None else 9999
