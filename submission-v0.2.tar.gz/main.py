#!/usr/bin/env python3
"""Competition HTTP entry point. Uses only the Python standard library."""
import argparse
import json
import logging
import os
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from agent import VERSION
from agent.engine import Engine
from agent.validation import empty_response

MAX_REQUEST_BYTES = 8 * 1024 * 1024


class AgentServer(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True

    def __init__(self, address):
        super().__init__(address, Handler)
        self.engine = Engine()
        self.decision_lock = threading.Lock()


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt, *args):
        # Do not log request bodies, model output, sandbox output, or URLs.
        pass

    def _send(self, payload):
        encoded = json.dumps(payload, ensure_ascii=False, allow_nan=False, separators=(",", ":")).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(encoded)))
        self.send_header("Connection", "close")
        self.end_headers()
        self.close_connection = True
        try:
            self.wfile.write(encoded)
        except (BrokenPipeError, ConnectionResetError, OSError):
            pass

    def do_GET(self):
        self._send({"status": "ok", "version": VERSION})

    def _read_body(self):
        deadline = time.monotonic() + 2.0

        def read(size, line=False):
            parts, received = [], 0
            while received < size:
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    raise ValueError("body_deadline")
                self.connection.settimeout(remaining)
                piece = self.rfile.read1(1 if line else size - received)
                if not piece:
                    break
                parts.append(piece)
                received += len(piece)
                if line and piece == b"\n":
                    break
            return b"".join(parts)

        transfer = self.headers.get("Transfer-Encoding", "").lower().strip()
        lengths = self.headers.get_all("Content-Length", [])
        if transfer:
            if transfer != "chunked" or lengths:
                raise ValueError("unsupported_framing")
            chunks, total, overhead = [], 0, 0
            while True:
                line = read(128, line=True)
                overhead += len(line)
                if not line.endswith(b"\r\n") or overhead > 65536:
                    raise ValueError("chunk_header")
                token = line[:-2].split(b";", 1)[0]
                if not token or any(c not in b"0123456789abcdefABCDEF" for c in token):
                    raise ValueError("chunk_size")
                size = int(token, 16)
                if size == 0:
                    while True:
                        trailer = read(8192, line=True)
                        overhead += len(trailer)
                        if not trailer.endswith(b"\r\n") or overhead > 65536:
                            raise ValueError("chunk_trailer")
                        if trailer == b"\r\n":
                            return b"".join(chunks)
                total += size
                if total > MAX_REQUEST_BYTES:
                    raise ValueError("body_too_large")
                chunk = read(size)
                if len(chunk) != size or read(2) != b"\r\n":
                    raise ValueError("chunk_incomplete")
                chunks.append(chunk)
        if len(lengths) != 1 or not lengths[0].isdigit():
            raise ValueError("content_length_missing_or_invalid")
        length = int(lengths[0])
        if not 0 < length <= MAX_REQUEST_BYTES:
            raise ValueError("content_length_out_of_bounds")
        body = read(length)
        if len(body) != length:
            raise ValueError("body_incomplete")
        return body

    def do_POST(self):
        response = empty_response()
        acquired = False
        phase = "read_body"
        started = time.monotonic()
        try:
            body = self._read_body()
            phase = "parse_json"
            raw = json.loads(body.decode("utf-8-sig"), parse_constant=lambda x: (_ for _ in ()).throw(ValueError("nonfinite")))
            phase = "decision_lock"
            acquired = self.server.decision_lock.acquire(timeout=1.0)
            if acquired:
                phase = "decision"
                response = self.server.engine.handle(raw)
            else:
                logging.getLogger("futurewar").warning("request_fallback phase=decision_lock reason=busy")
        except Exception as exc:
            # _read_body raises only fixed operational labels; JSON exceptions
            # can contain task data and must never be included verbatim.
            reason = str(exc) if phase == "read_body" and type(exc) is ValueError else type(exc).__name__
            logging.getLogger("futurewar").warning("request_fallback phase=%s reason=%s", phase, reason)
        finally:
            if acquired:
                self.server.decision_lock.release()
        if time.monotonic() - started > 4.0:
            logging.getLogger("futurewar").warning("slow_request phase=%s elapsed_ms=%.1f", phase,
                                                   (time.monotonic() - started) * 1000)
        self._send(response)


def configure_logging():
    logger = logging.getLogger("futurewar")
    logger.setLevel(logging.INFO)
    stream = logging.StreamHandler()
    stream.setFormatter(logging.Formatter("%(message)s"))
    logger.addHandler(stream)
    # File logging is opt-in and best effort. Default stderr works in read-only
    # submissions and contains only operational summaries, never task content.
    path = os.environ.get("FUTUREWAR_LOG")
    if path:
        try:
            handler = logging.FileHandler(path, encoding="utf-8")
            handler.setFormatter(logging.Formatter("%(message)s"))
            logger.addHandler(handler)
        except OSError:
            logger.info("file_log_unavailable")
    # Logging failures must not cause a failed round.
    logging.raiseExceptions = False


def main():
    parser = argparse.ArgumentParser(description="Future War Agent " + VERSION)
    parser.add_argument("port", type=int)
    args = parser.parse_args()
    if not 1 <= args.port <= 65535:
        parser.error("port must be between 1 and 65535")
    configure_logging()
    server = AgentServer(("0.0.0.0", args.port))
    logging.getLogger("futurewar").info("ready version=%s host=0.0.0.0 port=%s python=%s", VERSION,
                                       server.server_port, sys.version.split()[0])
    try:
        server.serve_forever(poll_interval=0.25)
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
