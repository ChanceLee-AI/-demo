#!/usr/bin/env bash
set -eu
AGENT_SCRIPT_DIR="${BASH_SOURCE[0]%/*}"
if [ "$AGENT_SCRIPT_DIR" = "${BASH_SOURCE[0]}" ]; then
    AGENT_SCRIPT_DIR=.
fi
cd -- "$AGENT_SCRIPT_DIR"
export PYTHONDONTWRITEBYTECODE=1
if command -v python3 >/dev/null 2>&1; then
    exec python3 -u main.py "$@"
elif command -v python >/dev/null 2>&1; then
    exec python -u main.py "$@"
else
    echo 'Python 3.8 or newer is required.' >&2
    exit 127
fi
