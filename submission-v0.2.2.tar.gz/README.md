# 《未来战争》参赛 Agent v0.2.2

源码、测试、比赛资料与提交包现统一位于工作区的 `agent_demo/`。从此目录运行下列命令，原来的 `Competition-main/` 不再作为开发目录。迁移前 40 个有效文件已逐个核对 SHA-256，记录保存在 `docs/migration-v0.2-baseline.json`；原始对局日志保存在 `docs/logs/v0.2/`。

目标环境为 Python **3.11.10**，程序只使用标准库，无需安装 Flask 或联网下载依赖。运行端口由判题系统传入，监听 `0.0.0.0`；可从其他工作目录启动，支持路径包含空格。

```bash
bash run.sh 8080
```

官方 `main3.py` 示例是 `POST /` 接收 JSON、调用选手逻辑、返回 JSON 的 HTTP 骨架；其中原样回显请求的 `callback` 是待实现部分，没有额外的 LLM 接口。当前服务支持 `POST /` 及其他 POST 路径，接收 Content-Length 或 chunked 传输的 UTF-8 JSON，返回 `roleCommandMap`、`prompt`、`executeCmd`。`GET /health` 可读取版本。LLM 提示与沙盒命令仍通过官方三字段响应提交，结果在下一回合处理。

## 提交与版本

开发目录执行：

```bash
python -B tools/package.py
```

主提交文件是 **`dist/submission-v0.2.2.tar.gz`**，同时生成内容一致的 ZIP 备用包。运行时版本使用 `agent/__init__.py` 中的常量，不再依赖读取根目录版本文件；打包器静态解析 AST，强制常量与根目录 `VERSION` 一致。解压后根目录直接有 `run.sh`、`main.py`、`agent/`、`README.md` 和 `VERSION`，`run.sh` 使用 UTF-8/LF，TAR 权限为 0755。平台接受的格式和入口目录仍以实际上传反馈为准。

包内不含任务书、SDK 样例、测试数据、日志和开发工具。包外 `submission-v0.2.2.manifest.json` 记录内容清单与 SHA-256，`submission-v0.2.2.SHA256SUMS` 记录本版归档校验值。历史 v0.1/v0.2/v0.2.1 包、原校验记录及旧 `SHA256SUMS` 原样保留；打包器拒绝以不同内容覆盖已有发布文件。`python -B tools/package.py --check` 在内存校验版本、Python 3.11 语法、运行文件、UTF-8/LF、权限及两种归档内容一致性，不写压缩包。

## v0.2.2 行为

- 服务绑定端口时跳过标准库 HTTPServer 的主机名解析，避免不必要的解析耗时影响开始监听。启动脚本即使某个日志输出通道不可用，也会继续执行到 Python 入口。后者已通过关闭 stdout/stderr 的本地故障注入复现并修复，尚无证据证明平台触发过该条件。
- 前三次成功 TCP 连接各输出 `connection seq=N stage=accepted`，与前三次 POST 的 `request seq=N stage=received/parsed/decided/written` 独立计数。只连 TCP、不发 HTTP 也会有连接标记；GET 健康检查计入连接数，不占用 POST 计数。不会打印来源地址或请求正文。
- 保留 shell、Python、导入完成和端口监听四阶段标记，以及包内版本常量。这些修改消除了具体启动风险并补充连接诊断，尚不能说明已经定位或修复平台首次异常。

- 开局在存在合法空格时，最多用 3 回合让一名工人优先移动；下一回合用实际位置确认执行，再交由常规策略管理。指令已发出和角色确实移动分别记录。
- 白天使用本地规则寻路、采矿、出售、采购、建造及升级；未知建造区通过合法格式的普通建造动作探测，不读取内网图片。
- 修复炮位被挡导致误返程、矿工往返估计把自己当障碍、不可达升级目标占用工人的问题。连续两次明确移动失败后换路，闲置阻路角色可让位。
- 基础建设目标为两座电磁炮和一座火箭；日落前安排返程，夜间将角色分配至武器邻格操炮。任务与资源决策通过跨回合状态协调。
- 平台 LLM 返回说明文字时可提取唯一 JSON；无效任务输出最多修正一次，等待新证据后恢复，避免重复空转。普通新闻每天最多两次调用，开局移动检查期间仍保存新闻原文。
- 明确的指令错误可定位到动作类型时，本场停止该类动作，其他可用工作继续执行；普通碰撞、建造位置不合法等执行失败不会触发此机制。
- 请求拒绝、缓存冲突、动作过滤和预算不足均输出精简原因，异常时仍返回完整三字段空响应。诊断不包含题面、新闻、完整模型输出或请求正文。
- 本版尚未通过真实官方对局验证。机器人完整行为、真实建造区、部分弹道与直接对人攻击规则仍依赖比赛反馈，当前验证不能证明胜率。

## 本地验证

```bash
python -B -m unittest discover -s tests -v
python -B tools/check_scenarios.py
python -B tools/replay.py --url http://127.0.0.1:8080/ --rounds 1300
python -B tools/replay.py --url http://127.0.0.1:8080/ --input tests/fixtures/request.json
python -B tools/check_scenarios.py --url http://127.0.0.1:8080/
python -B tools/smoke_package.py --archive dist/submission-v0.2.2.tar.gz
```

`check_scenarios.py` 会实际结算一组规则明确的动作：移动与碰撞、采集、出售、建造、购买和升级。双方阵营各有连续 1–75 回合场景，检查前三回合角色移动、经济活动、三座武器建设和首夜攻击；另设双方从第 66 回合返程操炮的场景。建造区域和矿产刷新位置是明确指定的测试数据，机器人是静止靶标，只校验能否发出合法攻击，不模拟伤害、机器人 AI、对手、任务判分或胜率。

`replay.py` 的默认 1300 回合输入会改变昼夜与目标状态，但不根据响应结算游戏；它只检查 HTTP 格式、运行稳定性、动作种类和耗时。`--input` 支持单个 JSON、JSON 数组或 JSONL。脱敏请求夹具由任务书样例整理，原文未修改，不代表官方实测请求。

任务闭环测试通过实际 Engine 验证移动、领取、模型反馈、沙盒反馈、答案提交和成功确认；模型及沙盒反馈使用固定测试数据，不访问平台模型、不在本机执行模型给出的命令。

`smoke_package.py` 必须实际解压 TAR.GZ 至带空格的临时路径，从另一个工作目录经 **`bash run.sh`** 启动随机端口，再执行 1300 回合 HTTP 检查和双方行动结算场景；缺少 Bash 会直接报错，不会用直接运行 `main.py` 替代。还必须依次观察到 `boot stage=shell_enter/python_enter/agent_imported/listening`、前三次 TCP 接受标记，以及前三次 POST 各自的 `request seq=N stage=received/parsed/decided/written`。可用 `--bash` 指定 Bash 路径。报告写入 `dist/smoke-report-v0.2.2.json`，记录实际 Python、系统、启动阶段和已运行的检查。

本机已确认可用环境为 **Windows 11、Python 3.14.6、Git Bash**，尚未安装或实测目标 Python 3.11.10/Linux。当前双方行动场景在此本机环境通过；语法检查与本机通过不能替代目标环境验证，归档启动结果以实际生成的 smoke 报告为准。

## 回放与反馈

用户确认此次失败运行提交的是 v0.2。现有日志表明我方 A（玩家 4306）达到异常上限，却没有首次异常原因；对手 B 已实际移动并成功建造。不能据此断言两队都没动，或把某个未证实的 SDK/环境差异当作根因。具体证据和新诊断阶段含义见 `docs/调度失败排查.md`。

若已看到 `boot stage=listening` 却始终没有 `connection ... accepted`，程序已监听，但该片段中没有记录到成功接受 TCP 连接，优先核对平台启动命令、端口和连接目标；仍需确认日志采集完整。若有 `accepted` 而无 `request ... received`，再检查是否只是健康探测，或 HTTP 请求尚未完整到达。若连 `shell_enter` 都没有，现有输出不能证明提交入口被执行，需先核对入口与日志采集，继续改采矿策略无法定位这个阶段。

若只能查看回放，优先观察：前三回合是否有人移动、回合是否继续推进、白天是否采集/出售/建造、是否进入首夜及出现机器人。无需提供内部任务内容。能够取得日志时，只需转述脱敏的启动失败、请求拒绝或动作过滤原因。可选设置 `FUTUREWAR_LOG` 写入诊断文件，目录不可写不影响运行。
