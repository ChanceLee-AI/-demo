"""Offline competition agent. No third-party dependencies."""
VERSION = "0.2.2"
